import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';
import { getCatalog, getSite } from '@/lib/store';
import { waLink } from '@/lib/format';
import ProductCard from '@/components/ProductCard';
import SortSelect from '@/components/SortSelect';
import { Icon } from '@/components/Icon';

export const dynamic = 'force-dynamic';
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || '';
type P = { params: Promise<{ lang: string; slug: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { lang, slug } = await params; if (!isLang(lang)) return {};
  const site = await getSite(lang), k = site.categories.find((c) => c.slug === slug); if (!k) return {};
  const seo = site.settings.seo?.pages?.['cat-' + slug]?.[lang];
  return { title: seo?.title || k.name, description: (seo?.desc || k.description || '').slice(0, 160), alternates: { canonical: `/${lang}/c/${slug}` } };
}
export default async function Category({ params, searchParams }: P) {
  const { lang, slug } = await params; if (!isLang(lang)) notFound();
  const sp = await searchParams, sort = ['asc', 'desc'].includes(one(sp.sort)) ? one(sp.sort) : '', size = one(sp.size).slice(0, 30);
  const site = await getSite(lang), t = dict(lang, site.translations), k = site.categories.find((c) => c.slug === slug);
  if (!k) notFound();
  const sym = site.settings.store?.currency_symbol || site.settings.store?.currency || '', wa = site.settings.whatsapp || {};
  const all = await getCatalog(lang, { category: slug, sort }), shown = size ? await getCatalog(lang, { category: slug, sort, size }) : all;
  const crumbs = <div className="crumbs"><a href={`/${lang}`}>{t('home')}</a> / {k.name}</div>;
  if (!all.items.length) return (
    <div className="wrap" style={{ paddingBottom: 72 }}>{crumbs}
      <section className="gh"><div><h1>{k.name}</h1><p className="lead">{k.description}</p><p className="note">{t('cat_empty')}</p>
        <div className="acts">{wa.enabled && wa.show_home && wa.number && <a className="btn" href={waLink(wa.number)} target="_blank" rel="noopener noreferrer"><Icon name="wa" /> {t('wa_btn')}</a>}<a className="btn sec2" href={`/${lang}/contact`}>{t('ft_cont')}</a></div></div></section></div>);
  return (
    <div className="wrap">{crumbs}
      <div className="ph1"><h1>{k.name}</h1><p className="lead">{k.description}</p></div>
      <div className="bar2">
        <div className="chips" role="group" aria-label={t('size')}>{all.sizes.map((s) => (
          <a key={s} className="chip" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }} href={`?${new URLSearchParams({ ...(sort ? { sort } : {}), ...(size === s ? {} : { size: s }) })}`} aria-pressed={size === s}>{s}</a>))}</div>
        <SortSelect label={t('sort')} value={sort} options={[['', t('sort_def')], ['asc', t('sort_asc')], ['desc', t('sort_desc')]]} />
      </div>
      {shown.items.length ? <div className="grid" style={{ paddingBottom: 72 }}>{shown.items.map((p) => <ProductCard key={p.id} p={p} lang={lang} t={t} sym={sym} />)}</div>
        : <div className="empty"><p>{t('f_empty')}</p><a className="btn sec2" href="?">{t('f_reset')}</a></div>}
    </div>);
}
