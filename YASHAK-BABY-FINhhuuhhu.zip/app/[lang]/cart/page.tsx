import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';
import { getSite } from '@/lib/store';
import CartView from '@/components/CartView';

export const dynamic = 'force-dynamic';
export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params; return { title: dict(isLang(lang) ? lang : 'fr')('cart'), robots: { index: false, follow: false } };
}
const KEYS = ['n_req', 'n_phone_bad', 'n_fail', 'n_stock', 'n_thanks', 'n_thanks_t', 'n_thanks_s', 'n_bank_b', 'n_bank_h', 'n_bank_i', 'n_bank_c', 'n_total', 'wa_btn', 'cont', 'cart_empty', 'remove', 'n_sub', 'n_del', 'n_free', 'n_del_tbc',
  'n_name', 'n_phone', 'n_city', 'n_address', 'n_email', 'n_note', 'n_pay', 'n_bank', 'n_cod', 'n_nopay', 'n_place'];
export default async function Cart({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params; if (!isLang(lang)) notFound();
  const site = await getSite(lang), t = dict(lang, site.translations);
  const L = Object.fromEntries(KEYS.map((k) => [k, t(k)])); L.sym = site.settings.store?.currency_symbol || site.settings.store?.currency || '';
  return <div className="wrap"><div className="crumbs"><a href={`/${lang}`}>{t('home')}</a> / {t('cart')}</div><div className="doc" style={{ maxWidth: 900 }}><h1>{t('cart')}</h1><CartView lang={lang} L={L} cont={`/${lang}`} /></div></div>;
}
