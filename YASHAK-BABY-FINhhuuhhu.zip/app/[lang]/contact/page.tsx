import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';
import { getSite } from '@/lib/store';
import { waLink } from '@/lib/format';
import { Icon } from '@/components/Icon';

export const dynamic = 'force-dynamic';
export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params; if (!isLang(lang)) return {}; const site = await getSite(lang), t = dict(lang, site.translations);
  return { title: site.settings.seo?.pages?.contact?.[lang]?.title || t('ft_cont'), description: t('c_intro'), alternates: { canonical: `/${lang}/contact` } };
}
export default async function Contact({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params; if (!isLang(lang)) notFound();
  const site = await getSite(lang), t = dict(lang, site.translations), st = site.settings.store || {}, wa = site.settings.whatsapp || {};
  const intl = ((st.intl || []) as { label: string; number: string }[]).filter((x) => x.number);
  return (
    <div className="wrap"><div className="doc"><h1>{t('ft_cont')}</h1><p>{t('c_intro')}</p>
      <dl className="dl">
        <div><dt>{t('c_wa')}</dt><dd><bdi className="lat">{st.phone}</bdi></dd></div>
        <div><dt>{t('c_mail')}</dt><dd><bdi className="lat"><a href={`mailto:${st.email}`}>{st.email}</a></bdi></dd></div>
        <div><dt>{t('c_loc')}</dt><dd><bdi dir="auto">{st.address}</bdi></dd></div>
        {intl.length > 0 && <div><dt>{t('c_intl')}</dt><dd>{intl.map((x, i) => <span key={i}>{x.label}: <bdi className="lat">{x.number}</bdi><br /></span>)}</dd></div>}
      </dl>
      {wa.enabled && wa.show_contact && wa.number && <div className="acts"><a className="btn" href={waLink(wa.number)} target="_blank" rel="noopener noreferrer"><Icon name="wa" /> {t('wa_btn')}</a></div>}
    </div></div>);
}
