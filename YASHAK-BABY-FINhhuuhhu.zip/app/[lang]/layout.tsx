import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import '../styles/store.css';
import { LANGS, RTL, dict, isLang, type Lang } from '@/lib/i18n';
import { getSite, siteBase, imgUrl } from '@/lib/store';
import { Icon } from '@/components/Icon';
import LangMenu from '@/components/LangMenu';
import CartBadge from '@/components/CartBadge';
import Toast from '@/components/Toast';

export const dynamic = 'force-dynamic';   // prices, stock and content come from the database on every request
export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params; if (!isLang(lang)) return {};
  const site = await getSite(lang), t = dict(lang, site.translations), name = site.settings.store?.name || 'YASHAK BABY';
  return {
    metadataBase: new URL(siteBase(site.settings)), title: { default: name, template: `%s · ${name}` }, description: t('hero_s'),
    alternates: { canonical: `/${lang}`, languages: Object.fromEntries(LANGS.map((l) => [l.c, `/${l.c}`])) },
    icons: { icon: site.settings.branding?.logo_header || '/img/logo-h.jpg' },
    openGraph: { type: 'website', siteName: name, images: [site.settings.branding?.og_image || '/img/site/home/hero.jpg'] },
  };
}

export default async function SiteLayout({ children, params }: { children: React.ReactNode; params: Promise<{ lang: string }> }) {
  const { lang: l } = await params; if (!isLang(l)) notFound();
  const lang: Lang = l, site = await getSite(lang), t = dict(lang, site.translations), dir = RTL.has(lang) ? 'rtl' : 'ltr';
  const S = site.settings, st = S.store || {}, br = S.branding || {};
  const cats = site.live ? site.categories : (['gifts', 'clothing', 'mother'] as const).map((k) => ({ slug: k, name: t(k), description: t(`cat_${k}_d`), image: null }));
  const social = Object.entries((S.social || {}) as Record<string, string>).filter(([, v]) => v);
  return (
    <html lang={lang} dir={dir}>
      <body data-lang={lang}>
        <header className="hd"><div className="wrap">
          <a className="logo" href={`/${lang}`} aria-label={st.name}><img src={imgUrl(br.logo_header) || '/img/logo-h.jpg'} width={640} height={242} alt={st.name} /></a>
          <div className="tools">
            <a className="ib" href={`/${lang}/search`} aria-label={t('search')}><Icon name="search" /></a>
            <LangMenu lang={lang} label={t('lang')} />
            <CartBadge lang={lang} label={t('cart')} />
          </div></div></header>
        <nav className="nv"><div className="wrap">{cats.map((k) => <a key={k.slug} href={`/${lang}/c/${k.slug}`}>{k.name}</a>)}</div></nav>
        {lang === 'zgh' && <div className="zn"><div className="wrap tf" lang="zgh">{t('zgh_note')}</div></div>}
        <main id="app">{children}</main>
        <footer className="ft"><div className="wrap">
          <div><a href={`/${lang}`} aria-label={st.name}><img src={imgUrl(br.logo_footer) || '/img/logo-f.jpg'} width={720} height={410} alt={st.name} /></a></div>
          <div><h3>{t('ft_shop')}</h3><ul>{cats.map((k) => <li key={k.slug}><a href={`/${lang}/c/${k.slug}`}>{k.name}</a></li>)}</ul></div>
          <div><h3>{t('ft_help')}</h3><ul>{([['delivery', 'ft_deliv'], ['returns', 'ft_ret'], ['faq', 'ft_faq'], ['about', 'ft_about']] as const).map(([a, b]) => <li key={a}><a href={`/${lang}/page/${a}`}>{t(b)}</a></li>)}<li><a href={`/${lang}/contact`}>{t('ft_cont')}</a></li>
            {social.map(([k, v]) => <li key={k}><a href={v} rel="noopener noreferrer" target="_blank">{k.charAt(0).toUpperCase() + k.slice(1)}</a></li>)}</ul></div>
          <div><h3>{t('ft_contact')}</h3><p><bdi className="lat">{st.phone}</bdi></p><p><bdi className="lat">{st.email}</bdi></p><p><bdi dir="auto">{st.address}</bdi></p></div>
          <div className="fine"><span>{t('ft_trust')}</span><span><a href={`/${lang}/page/privacy`}>{t('ft_priv')}</a> · <a href={`/${lang}/page/terms`}>{t('ft_terms')}</a></span></div>
        </div></footer>
        <Toast />
      </body>
    </html>
  );
}
