'use client';
import { usePathname } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';

export default function NotFound() {
  const seg = (usePathname() || '').split('/')[1], lang = isLang(seg) ? seg : 'fr', t = dict(lang);
  return <div className="wrap"><div className="empty" style={{ paddingBlock: 80 }}><h1>404</h1><p>{t('s_empty')}</p><a className="btn sec2" href={`/${lang}`}>{t('home')}</a></div></div>;
}
