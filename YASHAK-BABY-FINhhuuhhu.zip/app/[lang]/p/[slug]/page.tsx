import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';
import { getCatalog, getProduct, getSite, imgUrl, siteBase } from '@/lib/store';

import ProductBuy from '@/components/ProductBuy';
import ProductCard from '@/components/ProductCard';
import Gallery from '@/components/Gallery';

export const dynamic = 'force-dynamic';
type P = { params: Promise<{ lang: string; slug: string }> };
const cut = (s: string, n = 155) => { s = (s || '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { lang, slug } = await params; if (!isLang(lang)) return {};
  const p = await getProduct(slug, lang); if (!p) return { robots: { index: false } };
  const og = imgUrl(p.og_image) || imgUrl(p.images[0]?.path);
  return { title: p.seo_title || p.name, description: p.seo_desc || cut(p.description || p.name), alternates: { canonical: `/${lang}/p/${slug}`, languages: Object.fromEntries(['ary', 'ar', 'zgh', 'fr', 'en', 'es'].map((c) => [c, `/${c}/p/${slug}`])) }, openGraph: og ? { images: [og] } : undefined };
}
export default async function ProductPage({ params }: P) {
  const { lang, slug } = await params; if (!isLang(lang)) notFound();
  const [site, p] = await Promise.all([getSite(lang), getProduct(slug, lang)]); if (!p) notFound();
  const t = dict(lang, site.translations), S = site.settings, st = S.store || {}, sym = st.currency_symbol || st.currency || '', wa = S.whatsapp || {}, base = siteBase(S);
  const rel = (await getCatalog(lang, { category: p.category, limit: 5 })).items.filter((x) => x.id !== p.id).slice(0, 4);
  const specRows = (p.specs || '').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const i = l.indexOf(':'); return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : ['', l]; });
  const url = `${base}/${lang}/p/${slug}`;
  const labels = wa.labels?.[lang] || wa.labels?.fr, tpl = wa.templates?.[lang] || wa.templates?.fr;
  const images = p.images.map((i) => ({ src: imgUrl(i.path)!, alt: i.alt || p.name })).filter((i) => i.src);
  const jsonld = { '@context': 'https://schema.org', '@type': 'Product', name: p.name, description: cut(p.description || p.name, 300), sku: p.sku || undefined,
    image: images.map((i) => (i.src.startsWith('/') ? base + i.src : i.src)),
    offers: { '@type': 'Offer', priceCurrency: st.currency, price: (p.price_cents / 100).toFixed(2), availability: p.in_stock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', url } };
  return (
    <>
      <div className="wrap"><div className="crumbs"><a href={`/${lang}`}>{t('home')}</a> / {p.category && <a href={`/${lang}/c/${p.category}`}>{p.category_name}</a>}</div>
        <div className="pdp" id="pdp">
          <Gallery images={images} fallbackAlt={p.name} />
          <div>
            <h1 style={{ marginTop: 12 }}>{p.name}</h1>
            <ProductBuy name={p.name} sku={p.sku} baseCents={p.price_cents} oldCents={p.old_cents} available={p.available} sym={sym} url={url}
              variants={p.variants} wa={{ enabled: !!(wa.enabled && wa.show_product && wa.number && tpl && labels), number: wa.number || '', template: tpl || '', labels: labels || {} }}
              i={{ opts: t('n_opts'), out: t('n_out'), added: t('added'), unavail: t('n_unavail'), inn: t('n_in'), color: t('color'), size: t('size'), qty: t('qty'), add: t('add'), wa: t('n_wa') }} />
            <div className="facts">
              {p.description && <div><b>{t('desc_t')}</b><p style={{ whiteSpace: 'pre-line' }}>{p.description}</p></div>}
              {specRows.length > 0 && <div><b>{t('n_specs')}</b><dl className="dl">{specRows.map(([a, b], i) => <div key={i}><dt>{a}</dt><dd>{b}</dd></div>)}</dl></div>}
              {p.sku && <div><b>{t('n_sku')}</b><p className="lat">{p.sku}</p></div>}
            </div>
          </div></div></div>
      {rel.length > 0 && <div className="sec tight" style={{ paddingTop: 0 }}><div className="wrap"><div className="sh"><h2>{t('n_rel')}</h2></div><div className="grid g4" style={{ paddingBottom: 72 }}>{rel.map((x) => <ProductCard key={x.id} p={x} lang={lang} t={t} sym={sym} />)}</div></div></div>}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonld).replace(/</g, '\\u003c') }} />
    </>
  );
}
