import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang, loc } from '@/lib/i18n';
import { getCatalog, getSite, imgUrl } from '@/lib/store';
import { returnsPublished } from '@/lib/legal';
import { waLink } from '@/lib/format';
import ProductCard from '@/components/ProductCard';
import { Placeholder } from '@/components/Placeholder';
import { Icon } from '@/components/Icon';

export const dynamic = 'force-dynamic';
type Img = { src?: string | null; alt: string; cls?: string };
const Pic = ({ src, alt, cls = '' }: Img) => <div className={`ph ${cls}`} style={{ ['--tone' as string]: '#EAE2D6' }}>{src ? <img src={src} alt={alt} loading="lazy" /> : <Placeholder />}</div>;
const DEF_SEC: Record<string, [string, string, string]> = { gifts: ['sec_gift_t', 'sec_gift_s', 'more_gifts'], clothing: ['clothing', 'cat_clothing_d', 'cont'], mother: ['sec_mom_t', 'sec_mom_s', 'cont'] };

export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params; if (!isLang(lang)) return {};
  const site = await getSite(lang), t = dict(lang, site.translations), seo = site.settings.seo?.pages?.home?.[lang];
  return { title: seo?.title || undefined, description: (seo?.desc || t('hero_s')).slice(0, 160), alternates: { canonical: `/${lang}`, languages: Object.fromEntries(['ary', 'ar', 'zgh', 'fr', 'en', 'es'].map((c) => [c, `/${c}`])) } };
}

export default async function Home({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params; if (!isLang(lang)) notFound();
  const site = await getSite(lang), t = dict(lang, site.translations), S = site.settings, home = S.home || {}, wa = S.whatsapp || {};
  const feat = site.live ? (await getCatalog(lang, { featured: true, limit: 8 })).items : [];
  const cats = site.live ? site.categories : (['gifts', 'clothing', 'mother'] as const).map((k) => ({ slug: k, name: t(k), description: t(`cat_${k}_d`), image: null as string | null }));
  const heroT = loc(home.hero?.title, lang) || t('hero_t'), heroS = loc(home.hero?.text, lang) || t('hero_s'), sym = S.store?.currency_symbol || S.store?.currency || '';
  const first = cats[0], second = cats[1];
  return (
    <>
      <div className="wrap"><section className="hero"><div><h1>{heroT}</h1><p className="lead">{heroS}</p>
        <div className="acts">{first && <a className="btn" href={`/${lang}/c/${first.slug}`}>{t('hero_c1')}</a>}{second && <a className="btn sec2" href={`/${lang}/c/${second.slug}`}>{t('hero_c2')}</a>}
          {wa.enabled && wa.show_home && wa.number && <a className="btn sec2" href={waLink(wa.number)} target="_blank" rel="noopener noreferrer"><Icon name="wa" /> {t('wa_btn')}</a>}</div></div>
        <Pic src={imgUrl(home.hero?.image)} alt={heroT} /></section></div>
      <section className="sec tight"><div className="wrap"><div className="sh"><h2>{t('sec_cats')}</h2></div><div className="cats">
        {cats.map((k) => (
          <a className="cat" key={k.slug} href={`/${lang}/c/${k.slug}`}><Pic src={imgUrl(home.category_images?.[k.slug] || k.image)} alt={k.name} /><div><h3>{k.name}</h3><p>{k.description}</p></div></a>))}
      </div></div></section>
      {feat.length > 0 && <section className="sec"><div className="wrap"><div className="sh"><h2>{t('sec_feat')}</h2></div><div className="grid g4">{feat.map((p) => <ProductCard key={p.id} p={p} lang={lang} t={t} sym={sym} />)}</div></div></section>}
      {(home.sections || []).map((s: { key: string; image?: string; link: string; title?: Record<string, string>; text?: Record<string, string> }, i: number) => {
        const d = DEF_SEC[s.key] || [], title = loc(s.title, lang) || (d[0] ? t(d[0]) : ''), text = loc(s.text, lang) || (d[1] ? t(d[1]) : '');
        return (
          <section key={s.key} className={`sec ${i % 2 === 0 ? 'band' : ''}`}><div className="wrap"><div className="split">
            <div><Pic src={imgUrl(s.image)} alt={title} cls="wide" /></div>
            <div><h2>{title}</h2><p className="lead">{text}</p><div className="acts"><a className="btn sec2" href={`/${lang}/c/${s.link}`}>{d[2] ? t(d[2]) : t('cont')}</a></div></div></div></div></section>);
      })}
      <section className="sec tight"><div className="wrap"><div className="sh"><h2>{t('info_t')}</h2></div><div className="trio">
        {([['del', 'page/delivery'], ['pay', 'contact'], ['ret', 'page/returns']] as const).map(([k, to]) => (
          <div key={k}><h3>{t(`i_${k}_t`)}</h3><p>{k === 'ret' && !returnsPublished(S) ? t('ret_hold_s') : t(`i_${k}_s`)}</p><p><a href={`/${lang}/${to}`}>{t('more')}</a></p></div>))}
      </div></div></section>
    </>
  );
}
