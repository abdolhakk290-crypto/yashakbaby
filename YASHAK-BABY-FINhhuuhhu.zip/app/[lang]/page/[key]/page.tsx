import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { defaultPage, dict, isLang, type PageBlock } from '@/lib/i18n';
import { getPageRow, getSite, isPageKey } from '@/lib/store';
import { holdBlocks, returnsPublished } from '@/lib/legal';
import Blocks from '@/components/Blocks';

export const dynamic = 'force-dynamic';
type P = { params: Promise<{ lang: string; key: string }> };

/** Page content: database (edited by the owner) first, then the texts shipped with the code. Applies the legal hold on the returns policy. */
async function load(lang: Parameters<typeof dict>[0], key: string) {
  const site = await getSite(lang), t = dict(lang, site.translations), held = !returnsPublished(site.settings);
  let page: { title: string; blocks: PageBlock[] } | null = null, shipped = false, fromFr = false;
  const row = await getPageRow(key, lang).catch(() => null);
  if (row) page = { title: row.title, blocks: row.blocks as PageBlock[] };
  else { const d = defaultPage(key, lang); if (d) { page = { title: d.t, blocks: d.b }; shipped = true; } else { const f = defaultPage(key, 'fr'); if (f) { page = { title: f.t, blocks: f.b }; shipped = true; fromFr = true; } } }
  if (!page) return null;
  if (held && key === 'returns') page = { title: page.title, blocks: [['n', t('ret_hold')]] };
  else if (held && shipped) page = { title: page.title, blocks: holdBlocks(page.blocks, fromFr ? 'fr' : lang) };
  return { page, site, t, fromFr };
}
export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { lang, key } = await params; if (!isLang(lang) || !isPageKey(key)) return {};
  const r = await load(lang, key); if (!r) return {};
  const first = r.page.blocks.find((b) => b[0] === 'p') as ['p', string] | undefined, seo = r.site.settings.seo?.pages?.['page-' + key]?.[lang];
  return { title: seo?.title || r.page.title, description: (seo?.desc || first?.[1] || '').slice(0, 160), alternates: { canonical: `/${lang}/page/${key}` } };
}
export default async function InfoPage({ params }: P) {
  const { lang, key } = await params; if (!isLang(lang) || !isPageKey(key)) notFound();
  const r = await load(lang, key); if (!r) notFound();
  const st = r.site.settings.store || {};
  return (
    <div className="wrap"><div className="doc">
      <h1>{r.page.title}</h1>
      {r.fromFr && <p className="note">{r.t('pg_pending')} <a href={`/fr/page/${key}`} hrefLang="fr">{r.t('pg_fr')}</a></p>}
      <div lang={r.fromFr || (lang === 'zgh' && key === 'returns' && !returnsPublished(r.site.settings)) ? 'fr' : undefined} dir={r.fromFr || (lang === 'zgh' && key === 'returns' && !returnsPublished(r.site.settings)) ? 'ltr' : undefined}>
        <Blocks blocks={r.page.blocks} vars={{ addr: st.address || '', mail: st.email || '', phone: st.phone || '' }} /></div>
    </div></div>);
}
