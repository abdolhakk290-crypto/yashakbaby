import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { dict, isLang } from '@/lib/i18n';
import { getCatalog, getSite } from '@/lib/store';
import ProductCard from '@/components/ProductCard';
import { Icon } from '@/components/Icon';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { robots: { index: false, follow: false } };
export default async function Search({ params, searchParams }: { params: Promise<{ lang: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { lang } = await params; if (!isLang(lang)) notFound();
  const sp = await searchParams, raw = sp.q, q = (Array.isArray(raw) ? raw[0] : raw || '').trim().slice(0, 60);
  const site = await getSite(lang), t = dict(lang, site.translations), sym = site.settings.store?.currency_symbol || site.settings.store?.currency || '';
  const r = q ? await getCatalog(lang, { q, limit: 60 }) : { items: [], total: 0, sizes: [] };
  return (
    <div className="wrap" style={{ minHeight: '60vh' }}>
      <form className="sbox" method="get" action={`/${lang}/search`}><Icon name="search" /><input name="q" type="search" defaultValue={q} placeholder={t('s_ph')} aria-label={t('s_ph')} autoComplete="off" maxLength={60} /></form>
      <div style={{ paddingBottom: 72 }}>{q ? (r.items.length ? <><p className="small">{t('s_res', { n: r.total })}</p><div className="grid">{r.items.map((p) => <ProductCard key={p.id} p={p} lang={lang} t={t} sym={sym} />)}</div></> : <div className="empty"><p>{t('s_empty')}</p></div>) : null}</div>
    </div>);
}
