'use server';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { needAdmin, arpc, fresh, go, errKeys, toCents, formStr, formId, removeFiles } from '@/lib/admin';
import { norm } from '@/lib/admin-i18n';
import { supabaseServer } from '@/lib/supabase-server';

const L6 = ['ary', 'ar', 'zgh', 'fr', 'en', 'es'];
const i18n = (fd: FormData, prefix: string, max = 5000) => Object.fromEntries(L6.map((l) => [l, formStr(fd, `${prefix}_${l}`, max).trim()]).filter(([, v]) => v));
const safeNext = (n: string, fallback: string) => (/^\/admin(\/[A-Za-z0-9/_-]*)?$/.test(n) ? n : fallback);

export async function logout() {
  const sb = await supabaseServer(); await sb.auth.signOut(); redirect('/admin/login');
}
export async function setAdminLang(fd: FormData) {
  await needAdmin();
  (await cookies()).set('yb_alang', norm(formStr(fd, 'lang', 5)), { path: '/admin', maxAge: 31536000, sameSite: 'lax', httpOnly: true, secure: process.env.NODE_ENV === 'production' });
  redirect(safeNext(formStr(fd, 'next', 120), '/admin'));
}

/* ---------------- products ---------------- */
export async function saveProduct(fd: FormData) {
  await needAdmin();
  const id = formId(fd), back = id ? `/admin/products/${id}` : '/admin/products/new';
  const variants: Record<string, unknown>[] = [];
  const vn = Math.min(Number(fd.get('vn')) || 0, 80);
  for (let i = 0; i < vn; i++) {
    if (fd.get(`v${i}_rm`)) continue;
    const vid = formId(fd, `v${i}_id`), size = formStr(fd, `v${i}_size`, 60).trim(), color = formStr(fd, `v${i}_color`, 60).trim(), stock = formStr(fd, `v${i}_stock`, 12).trim();
    if (!vid && !size && !color && !stock) continue;
    variants.push({ ...(vid ? { id: vid } : {}), size, color, stock: stock === '' ? '0' : stock, active: fd.get(`v${i}_active`) === 'on' });
  }
  const body: Record<string, unknown> = {
    ...(id ? { id } : {}), name: i18n(fd, 'name', 200), description: i18n(fd, 'desc'), specs: i18n(fd, 'specs', 2000), price_cents: toCents(fd.get('price')), sale_price_cents: toCents(fd.get('sale')),
    category_id: formStr(fd, 'category', 12), sku: formStr(fd, 'sku', 60).trim(), status: formStr(fd, 'status', 12) || 'draft',
    available: fd.get('available') === 'on', featured: fd.get('featured') === 'on', track_stock: fd.get('track_stock') === 'on', variants,
  };
  const slug = formStr(fd, 'slug', 80).trim(); if (slug) body.slug = slug;
  let res: { id: number } | undefined;
  try { res = await arpc<{ id: number }>('admin_save_product', { p: body }); } catch (e) { go(back, { err: errKeys(e) }); }
  fresh(); go(`/admin/products/${res!.id}`, { ok: true });
}
export async function patchProduct(fd: FormData) {
  await needAdmin();
  const id = formId(fd), field = formStr(fd, 'field', 12), value = formStr(fd, 'value', 12), back = safeNext(formStr(fd, 'next', 120), '/admin/products');
  if (!['status', 'available', 'featured'].includes(field)) go(back, { err: ['err_generic'] });
  try { await arpc('admin_patch_product', { p_id: id, p: { [field]: field === 'status' ? value : value === 'true' } }); } catch (e) { go(back, { err: errKeys(e) }); }
  fresh(); go(back, { ok: true });
}
export async function deleteProduct(fd: FormData) {
  await needAdmin(); const id = formId(fd);
  let paths: string[] = [];
  try { paths = await arpc<string[]>('admin_delete_product', { p_id: id }); } catch (e) { go('/admin/products', { err: errKeys(e) }); }
  await removeFiles(paths); fresh(); go('/admin/products', { ok: true });
}
export async function duplicateProduct(fd: FormData) {
  await needAdmin(); let nid = 0;
  try { nid = await arpc<number>('admin_duplicate_product', { p_id: formId(fd) }); } catch (e) { go('/admin/products', { err: errKeys(e) }); }
  fresh(); go(`/admin/products/${nid}`, { ok: true });
}
export async function moveProduct(fd: FormData) {
  await needAdmin(); const id = formId(fd), dir = formStr(fd, 'dir', 4);
  try {
    const rows = await arpc<{ id: number }[]>('admin_list_products', {}), ids = rows.map((r) => r.id), i = ids.indexOf(id), j = dir === 'up' ? i - 1 : i + 1;
    if (i >= 0 && j >= 0 && j < ids.length) { [ids[i], ids[j]] = [ids[j], ids[i]]; await arpc('admin_order_products', { p_ids: ids }); }
  } catch (e) { go('/admin/products', { err: errKeys(e) }); }
  fresh(); go('/admin/products');
}
export async function imageOp(fd: FormData) {
  await needAdmin(); const pid = formId(fd, 'product'), iid = formId(fd, 'image'), op = formStr(fd, 'op', 8), back = `/admin/products/${pid}`;
  try {
    if (op === 'remove') { const p = await arpc<string | null>('admin_remove_image', { p_id: iid }); if (p) await removeFiles([p]); }
    else {
      const prod = await arpc<{ images: { id: number }[] }>('admin_get_product', { p_id: pid }), ids = prod.images.map((x) => x.id), i = ids.indexOf(iid);
      if (i >= 0) {
        if (op === 'main') { ids.splice(i, 1); ids.unshift(iid); } else { const j = op === 'up' ? i - 1 : i + 1; if (j >= 0 && j < ids.length) [ids[i], ids[j]] = [ids[j], ids[i]]; }
        await arpc('admin_order_images', { p_product: pid, p_ids: ids });
      }
    }
  } catch (e) { go(back, { err: errKeys(e) }); }
  fresh(); go(back, { ok: true });
}

/* ---------------- categories ---------------- */
export async function saveCategory(fd: FormData) {
  await needAdmin(); const id = formId(fd);
  try {
    await arpc('admin_save_category', { p: { ...(id ? { id } : {}), name: i18n(fd, 'name', 100), description: i18n(fd, 'desc', 500), active: fd.get('active') === 'on' || !id } });
  } catch (e) { go('/admin/categories', { err: errKeys(e) }); }
  fresh(); go('/admin/categories', { ok: true });
}
export async function deleteCategory(fd: FormData) {
  await needAdmin();
  try { await arpc('admin_delete_category', { p_id: formId(fd), p_move_to: formId(fd, 'move') || null }); } catch (e) { go('/admin/categories', { err: errKeys(e) }); }
  fresh(); go('/admin/categories', { ok: true });
}
export async function moveCategory(fd: FormData) {
  await needAdmin(); const id = formId(fd), dir = formStr(fd, 'dir', 4);
  try {
    const rows = await arpc<{ id: number }[]>('admin_list_categories', {}), ids = rows.map((r) => r.id), i = ids.indexOf(id), j = dir === 'up' ? i - 1 : i + 1;
    if (i >= 0 && j >= 0 && j < ids.length) { [ids[i], ids[j]] = [ids[j], ids[i]]; await arpc('admin_order_categories', { p_ids: ids }); }
  } catch (e) { go('/admin/categories', { err: errKeys(e) }); }
  fresh(); go('/admin/categories');
}

/* ---------------- homepage ---------------- */
type Section = { key: string; image?: string | null; link?: string; title?: Record<string, string>; text?: Record<string, string> };
export async function saveHome(fd: FormData) {
  await needAdmin();
  try {
    const all = await arpc<Record<string, any>>('admin_get_settings'), home = (all.home || {}) as Record<string, any>;   // eslint-disable-line @typescript-eslint/no-explicit-any
    const old: Section[] = Array.isArray(home.sections) ? home.sections : [], sections: Section[] = [];
    const n = Math.min(Number(fd.get('sn')) || 0, 12);
    for (let i = 0; i < n; i++) {
      if (fd.get(`s${i}_rm`)) continue;
      const key = formStr(fd, `s${i}_key`, 40).replace(/[^A-Za-z0-9_-]/g, '') || `b${Date.now()}${i}`, prev = old.find((s) => s.key === key);
      sections.push({ key, image: prev?.image ?? null, link: formStr(fd, `s${i}_link`, 60).replace(/[^a-z0-9-]/g, ''), title: i18n(fd, `s${i}_title`, 120), text: i18n(fd, `s${i}_text`, 300) });
    }
    if (fd.get('add_banner')) sections.push({ key: `b${Date.now()}`, image: null, link: '', title: {}, text: {} });
    await arpc('admin_save_setting', { p_key: 'home', p_value: { ...home, hero: { ...(home.hero || {}), title: i18n(fd, 'hero_title', 120), text: i18n(fd, 'hero_text', 300) }, sections } });
  } catch (e) { go('/admin/content', { err: errKeys(e) }); }
  fresh(); go('/admin/content', { ok: true });
}

/* ---------------- settings ---------------- */
export async function saveSettings(fd: FormData) {
  await needAdmin();
  try {
    const all = await arpc<Record<string, any>>('admin_get_settings');   // eslint-disable-line @typescript-eslint/no-explicit-any
    const wa = all.whatsapp || {}, templates = { ...(wa.templates || {}), ...i18n(fd, 'wa_tpl', 1000) };
    const clean = (s: string) => s.trim();
    await arpc('admin_save_setting', { p_key: 'store', p_value: { ...(all.store || {}), name: clean(formStr(fd, 'name', 80)), email: clean(formStr(fd, 'email', 120)), phone: clean(formStr(fd, 'phone', 40)), address: clean(formStr(fd, 'address', 200)), base_url: clean(formStr(fd, 'base_url', 120)).replace(/\/+$/, '') } });
    await arpc('admin_save_setting', { p_key: 'social', p_value: { ...(all.social || {}), instagram: clean(formStr(fd, 'instagram', 200)), facebook: clean(formStr(fd, 'facebook', 200)), tiktok: clean(formStr(fd, 'tiktok', 200)) } });
    await arpc('admin_save_setting', { p_key: 'whatsapp', p_value: { ...wa, number: formStr(fd, 'wa_number', 30), enabled: fd.get('wa_enabled') === 'on', show_product: fd.get('wa_product') === 'on', show_home: fd.get('wa_home') === 'on', show_contact: fd.get('wa_contact') === 'on', templates } });
    await arpc('admin_save_setting', { p_key: 'legal', p_value: { ...(all.legal || {}), returns_published: fd.get('returns_published') === 'on' } });
  } catch (e) { go('/admin/settings', { err: errKeys(e) }); }
  fresh(); go('/admin/settings', { ok: true });
}

/* ---------------- orders ---------------- */
export async function setOrderStatus(fd: FormData) {
  await needAdmin(); const id = formId(fd), back = `/admin/orders/${id}`;
  try { await arpc('set_order_status', { p_id: id, p_status: formStr(fd, 'status', 12), p_restock: fd.get('restock') === 'on' }); } catch (e) { go(back, { err: errKeys(e) }); }
  go(back, { ok: true });
}
