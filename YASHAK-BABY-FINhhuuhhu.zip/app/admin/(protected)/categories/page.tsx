import { adminLang, makeT, L6 } from '@/lib/admin-i18n';
import { arpc, pick } from '@/lib/admin';
import { imgUrl } from '@/lib/store';
import { Flash, Confirm } from '@/components/AdminFlash';
import { saveCategory, deleteCategory, moveCategory } from '../actions';

type Cat = { id: number; slug: string; name: Record<string, string>; description: Record<string, string> | null; image: string | null; active: boolean; products: number };
export default async function Categories({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  const sp = await searchParams, lang = await adminLang(), t = makeT(lang), cats = await arpc<Cat[]>('admin_list_categories');
  const fields = (c: Cat | null) => L6.map((l) => (
    <label className="a-f" key={l.c}><span>{t('f_name')} ({l.n})</span><input name={`name_${l.c}`} maxLength={100} defaultValue={c?.name?.[l.c] || ''} dir={l.c === 'ar' || l.c === 'ary' ? 'rtl' : 'ltr'} /></label>));
  return (<>
    <h1 className="a-h">{t('categories')}</h1><Flash sp={sp} t={t} />
    {cats.map((c, i) => { const img = imgUrl(c.image); return (
      <section className="a-card" key={c.id}>
        <div className="a-row" style={{ justifyContent: 'space-between' }}>
          <h2 style={{ margin: 0 }}>{pick(c.name, lang)} <span className="a-chip">{c.products} {t('cat_products')}</span> {!c.active && <span className="a-chip off">{t('hidden_note')}</span>}</h2>
          <div className="a-acts">{(['up', 'down'] as const).map((d) => <form key={d} action={moveCategory}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="dir" value={d} /><button className="a-btn2 a-sm" disabled={(d === 'up' && i === 0) || (d === 'down' && i === cats.length - 1)} aria-label={t(d)} title={t(d)}>{d === 'up' ? '↑' : '↓'}</button></form>)}</div></div>
        <details style={{ marginTop: 10 }}><summary className="a-btn2 a-sm" style={{ display: 'inline-flex', cursor: 'pointer' }}>{t('edit')}</summary>
          <form action={saveCategory} style={{ marginTop: 12 }}><input type="hidden" name="id" value={c.id} />{fields(c)}
            <label className="a-chk"><input type="checkbox" name="active" defaultChecked={c.active} /> {t('cat_visible')}</label><button className="a-btn">{t('save')}</button></form>
          <form action="/api/admin/upload" method="post" encType="multipart/form-data" className="a-row" style={{ marginTop: 14 }}><input type="hidden" name="target" value="category" /><input type="hidden" name="category" value={c.id} />
            {img && <img src={img} alt="" width={64} height={64} style={{ borderRadius: 8, objectFit: 'cover' }} />}
            <label className="a-lab">{t('cat_image')} <input type="file" name="file" accept="image/jpeg,image/png,image/webp,image/gif" required /></label><button className="a-btn2 a-sm">{t('upload')}</button></form>
          <div style={{ marginTop: 14 }}><Confirm label={t('del')} question={t('del_cat_q')} warn={c.products ? t('del_cat_move') : t('del_cat_none')} yes={t('yes_delete')}>
            <form action={deleteCategory} className="a-grid"><input type="hidden" name="id" value={c.id} />
              {c.products > 0 && <select className="a-sel" name="move" required aria-label={t('del_cat_move')}>{cats.filter((x) => x.id !== c.id).map((x) => <option key={x.id} value={x.id}>{pick(x.name, lang)}</option>)}</select>}
              <button className="a-btn3 a-sm">{c.products ? t('move_and_delete') : t('yes_delete')}</button></form></Confirm></div>
        </details></section>); })}
    <section className="a-card"><h2>+ {t('new_category')}</h2><form action={saveCategory}>{fields(null)}<button className="a-btn">{t('add')}</button></form></section>
  </>);
}
