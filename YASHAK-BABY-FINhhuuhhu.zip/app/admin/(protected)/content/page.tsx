import { adminLang, makeT, L6 } from '@/lib/admin-i18n';
import { arpc, pick } from '@/lib/admin';
import { imgUrl } from '@/lib/store';
import { Flash } from '@/components/AdminFlash';
import { saveHome } from '../actions';

type Section = { key: string; image?: string | null; link?: string; title?: Record<string, string>; text?: Record<string, string> };
export default async function Content({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  const sp = await searchParams, lang = await adminLang(), t = makeT(lang);
  const [all, cats] = await Promise.all([arpc<Record<string, any>>('admin_get_settings'), arpc<{ slug: string; name: Record<string, string> }[]>('admin_list_categories')]);   // eslint-disable-line @typescript-eslint/no-explicit-any
  const home = all.home || {}, secs: Section[] = Array.isArray(home.sections) ? home.sections : [], hero = home.hero || {};
  const acc = 'image/jpeg,image/png,image/webp,image/gif';
  const upload = (target: string, key: string | null, current: string | null | undefined, label: string) => { const u = imgUrl(current); return (
    <form action="/api/admin/upload" method="post" encType="multipart/form-data" className="a-row" style={{ margin: '8px 0 14px' }}>
      <input type="hidden" name="target" value={target} />{key && <input type="hidden" name="key" value={key} />}
      {u && <img src={u} alt="" width={96} height={64} style={{ borderRadius: 8, objectFit: 'cover' }} />}
      <label className="a-lab">{label} <input type="file" name="file" accept={acc} required /></label><button className="a-btn2 a-sm">{t('upload')}</button></form>); };
  const texts = (prefix: string, titles: Record<string, string> | undefined, body: Record<string, string> | undefined) => (
    <div>{L6.map((l) => (<details className="a-lang" key={l.c} open={l.c === lang || !!(titles?.[l.c] || body?.[l.c])}><summary>{l.n}</summary><div dir={l.c === 'ar' || l.c === 'ary' ? 'rtl' : 'ltr'}>
      <label className="a-f"><span>{t('f_title')}</span><input name={`${prefix}_title_${l.c}`} maxLength={120} defaultValue={titles?.[l.c] || ''} /></label>
      <label className="a-f"><span>{t('f_text')}</span><textarea name={`${prefix}_text_${l.c}`} maxLength={300} defaultValue={body?.[l.c] || ''} style={{ minHeight: 60 }} /></label></div></details>))}</div>);
  return (<>
    <h1 className="a-h">{t('content')}</h1><p className="a-sub">{t('home_hint')}</p><Flash sp={sp} t={t} />
    <section className="a-card"><h2>{t('hero')}</h2>{upload('hero', null, hero.image, t('f_image'))}</section>
    <form action={saveHome}>
      <section className="a-card"><h2>{t('hero')} — {t('f_text')}</h2>{texts('hero', hero.title, hero.text)}</section>
      <section className="a-card"><h2>{t('banners')}</h2><input type="hidden" name="sn" value={secs.length} />
        {secs.map((s, i) => (<div key={s.key} className="a-card" style={{ background: 'var(--sand)' }}>
          <input type="hidden" name={`s${i}_key`} value={s.key} /><h3 style={{ marginTop: 0 }}>{t('banner')} {i + 1}{s.title && pick(s.title, lang) ? ` — ${pick(s.title, lang)}` : ''}</h3>
          {texts(`s${i}`, s.title, s.text)}
          <label className="a-f"><span>{t('f_link')}</span><select name={`s${i}_link`} defaultValue={s.link || ''}><option value="">{t('f_nocat')}</option>{cats.map((c) => <option key={c.slug} value={c.slug}>{pick(c.name, lang)}</option>)}</select></label>
          <label className="a-chk"><input type="checkbox" name={`s${i}_rm`} /> {t('f_remove')}</label>
          <p className="a-sub" style={{ margin: 0 }}>{t('f_image')}: {s.image ? <a className="a-link" href={imgUrl(s.image) || '#'} target="_blank" rel="noopener">✓</a> : '—'} <small>({t('save')} → {t('upload')} ↓)</small></p></div>))}
        <label className="a-chk"><input type="checkbox" name="add_banner" /> {t('add_banner')}</label></section>
      <div className="a-sticky"><button className="a-btn">{t('save')}</button></div>
    </form>
    {secs.length > 0 && <section className="a-card"><h2>{t('banners')} — {t('f_image')}</h2>{secs.map((s, i) => <div key={s.key}><b>{t('banner')} {i + 1}</b>{upload('section', s.key, s.image, t('f_image'))}</div>)}</section>}
    <p className="a-sub">{t('featured_hint')} <a className="a-link" href="/admin/products">{t('products')}</a></p>
  </>);
}
