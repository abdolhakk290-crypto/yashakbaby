// The dashboard lives at /admin/dashboard (and /admin shows the same page).
export { default } from '../page';
