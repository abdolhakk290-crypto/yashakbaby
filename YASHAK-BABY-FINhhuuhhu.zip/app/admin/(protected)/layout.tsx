import { redirect } from 'next/navigation';
import { currentAdmin } from '@/lib/supabase-server';
import { adminLang, makeT, ALANGS } from '@/lib/admin-i18n';
import { AdminNav, LangSelect } from '@/components/AdminBits';
import { logout, setAdminLang } from './actions';

// Every page under /admin (except /admin/login) is checked on the SERVER: must be signed in AND listed in the `admins` table.
export const dynamic = 'force-dynamic';
export default async function Protected({ children }: { children: React.ReactNode }) {
  const admin = await currentAdmin();
  if (!admin) redirect('/admin/login?e=denied');   // reaching here without a verified session means a signed-in account that is not an authorised admin
  const lang = await adminLang(), t = makeT(lang);
  return (<>
    <header className="a-top"><div className="a-in">
      <a href="/admin"><img src="/img/logo-h.jpg" alt="YASHAK BABY" /></a>
      <div className="a-tools">
        <LangSelect action={setAdminLang} current={lang} options={ALANGS} label={t('language')} />
        <a className="a-link" href="/" target="_blank" rel="noopener">{t('viewsite')}</a>
        <span title={admin.email} style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis' }}>{admin.email}</span>
        <form action={logout}><button className="a-btn2 a-sm">{t('logout')}</button></form>
      </div></div></header>
    <AdminNav items={[{ href: '/admin/dashboard', label: t('dash') }, { href: '/admin/products', label: t('products') }, { href: '/admin/categories', label: t('categories') }, { href: '/admin/content', label: t('content') }, { href: '/admin/orders', label: t('orders') }, { href: '/admin/settings', label: t('settings') }, { href: '/admin/security', label: t('security') }]} />
    <main className="a-in a-main">{children}</main>
  </>);
}
