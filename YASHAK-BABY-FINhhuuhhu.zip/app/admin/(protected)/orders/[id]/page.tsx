import { notFound } from 'next/navigation';
import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc, fromCents } from '@/lib/admin';
import { DbError } from '@/lib/db';
import { Flash } from '@/components/AdminFlash';
import { setOrderStatus } from '../../actions';

type Order = { id: number; number: string; status: string; name: string; phone: string; email: string | null; city: string | null; address: string | null; total_cents: number; delivery_cents: number; created_at: string; items: { id: number; name: string; qty: number; unit_cents: number; size?: string | null; color?: string | null }[] };
const STATUSES = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'returned'] as const;
export default async function OrderPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; err?: string }> }) {
  const { id } = await params, sp = await searchParams, t = makeT(await adminLang()), oid = Number(id);
  if (!Number.isSafeInteger(oid) || oid < 1) notFound();
  let o: Order | null = null;
  try { o = await arpc<Order>('admin_get_order', { p_id: oid }); } catch (e) { if (e instanceof DbError && e.code === 'YB404') notFound(); throw e; }
  const ord = o!;
  return (<><a className="a-link" href="/admin/orders">← {t('orders')}</a><h1 className="a-h">{ord.number}</h1><Flash sp={sp} t={t} />
    <section className="a-card"><p><b>{ord.name}</b> · <span className="lat">{ord.phone}</span>{ord.email ? ` · ${ord.email}` : ''}<br />{[ord.address, ord.city].filter(Boolean).join(', ')}</p>
      <ul>{ord.items.map((i) => <li key={i.id}>{i.qty} × {i.name}{i.size ? ` · ${i.size}` : ''}{i.color ? ` · ${i.color}` : ''} — {fromCents(i.unit_cents)} DH</li>)}</ul>
      <p><b>{t('o_total')}: <span className="lat">{fromCents(ord.total_cents)} DH</span></b></p></section>
    <form action={setOrderStatus} className="a-card a-row"><input type="hidden" name="id" value={ord.id} />
      <label className="a-lab">{t('f_status')} <select className="a-sel" name="status" defaultValue={ord.status}>{STATUSES.map((s) => <option key={s} value={s}>{t(('s_' + s) as 's_pending')}</option>)}</select></label><button className="a-btn">{t('save')}</button></form></>);
}
