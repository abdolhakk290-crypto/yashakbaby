import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc, fromCents } from '@/lib/admin';
type O = { id: number; number: string; status: string; name: string; phone: string; city: string | null; total_cents: number; created_at: string; items: number };
export default async function Orders() {
  const t = makeT(await adminLang()), rows = await arpc<O[]>('admin_list_orders', { p_limit: 100, p_offset: 0 });
  return (<><h1 className="a-h">{t('orders')}</h1><p className="a-sub">{t('orders_hint')}</p>
    {rows.length === 0 ? <p>{t('o_none')}</p> : <div className="a-scroll"><table className="a-tbl"><thead><tr><th>{t('o_number')}</th><th>{t('o_date')}</th><th>{t('o_customer')}</th><th>{t('o_city')}</th><th>{t('o_items')}</th><th>{t('o_total')}</th><th>{t('f_status')}</th></tr></thead><tbody>
      {rows.map((o) => <tr key={o.id}><td><a className="a-link" href={`/admin/orders/${o.id}`}>{o.number}</a></td><td>{new Date(o.created_at).toISOString().slice(0, 10)}</td><td>{o.name}<br /><small className="lat">{o.phone}</small></td><td>{o.city}</td><td>{o.items}</td><td className="lat">{fromCents(o.total_cents)} DH</td><td><span className="a-chip">{t(('s_' + o.status) as 's_pending')}</span></td></tr>)}</tbody></table></div>}</>);
}
