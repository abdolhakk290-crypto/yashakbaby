import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc } from '@/lib/admin';

export default async function Dashboard() {
  const t = makeT(await adminLang());
  const d = await arpc<{ published: number; drafts: number; unavailable: number; categories: number; orders_pending: number; whatsapp_ok: boolean }>('admin_dashboard');
  const stats: [string, number][] = [[t('dash_published'), d.published], [t('dash_drafts'), d.drafts], [t('dash_unavail'), d.unavailable], [t('categories'), d.categories], [t('dash_orders'), d.orders_pending]];
  const tiles: [string, string, string][] = [['/admin/products', t('products'), t('tile_prod_h')], ['/admin/products', t('photos'), t('tile_photos_h')], ['/admin/products', t('tile_prices'), t('tile_prices_h')], ['/admin/categories', t('categories'), t('tile_cat_h')], ['/admin/content', t('content'), t('tile_home_h')], ['/admin/settings#whatsapp', t('whatsapp'), t('tile_wa_h')], ['/admin/settings', t('settings'), t('tile_set_h')]];
  return (<>
    <h1 className="a-h">{t('dash')}</h1><p className="a-sub">{t('dash_welcome')}</p>
    <p className={d.whatsapp_ok ? 'a-ok' : 'a-er'} role="status">{d.whatsapp_ok ? t('wa_ok') : <>{t('wa_missing')} <a className="a-link" href="/admin/settings">{t('settings')}</a></>}</p>
    <div className="a-grid a-g2" style={{ marginBottom: 20 }}>{stats.map(([l, n]) => <div className="a-stat" key={l}><b>{n}</b><span>{l}</span></div>)}</div>
    <a className="a-btn3" href="/admin/products/new" style={{ marginBottom: 16, minHeight: 56, fontSize: '1.0625rem' }}>+ {t('new_product')}</a>
    <div className="a-grid a-g2">{tiles.map(([href, label, hint]) => <a key={label} href={href} className="a-card" style={{ textDecoration: 'none', color: 'inherit', display: 'block', marginBottom: 0, minHeight: 88 }}><b style={{ fontSize: '1.125rem' }}>{label}</b><br /><span className="a-sub" style={{ margin: 0 }}>{hint}</span></a>)}</div>
  </>);
}
