import { notFound } from 'next/navigation';
import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc, pick } from '@/lib/admin';
import { DbError } from '@/lib/db';
import { imgUrl } from '@/lib/store';
import { Flash, Confirm } from '@/components/AdminFlash';
import { ProductForm, type AdminProduct } from '@/components/ProductForm';
import { deleteProduct, imageOp, duplicateProduct } from '../../actions';

export default async function EditProduct({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; err?: string }> }) {
  const { id } = await params, sp = await searchParams, lang = await adminLang(), t = makeT(lang), pid = Number(id);
  if (!Number.isSafeInteger(pid) || pid < 1) notFound();
  let p: (AdminProduct & { images: { id: number; path: string }[] }) | null = null;
  try { p = await arpc('admin_get_product', { p_id: pid }); } catch (e) { if (e instanceof DbError && e.code === 'YB404') notFound(); throw e; }
  const cats = await arpc<{ id: number; name: Record<string, string> }[]>('admin_list_categories');
  const prod = p!, pub = prod.status === 'published';
  return (<>
    <a className="a-link" href="/admin/products">← {t('products')}</a>
    <div className="a-row" style={{ justifyContent: 'space-between', margin: '8px 0' }}><h1 className="a-h">{pick(prod.name, lang)}</h1>
      <div className="a-row">{pub && <a className="a-btn2 a-sm" href={`/fr/p/${prod.slug}`} target="_blank" rel="noopener">{t('view_public')}</a>}
        <form action={duplicateProduct}><input type="hidden" name="id" value={prod.id} /><button className="a-btn2 a-sm">{t('duplicate')}</button></form></div></div>
    <Flash sp={sp} t={t} />
    <ProductForm product={prod} cats={cats} lang={lang} />

    <section className="a-card" aria-labelledby="ph"><h2 id="ph">{t('photos')}</h2><p className="a-sub" style={{ marginBottom: 12 }}>{t('photos_hint')}</p>
      {prod.images.length === 0 && <p>{t('no_photos')}</p>}
      <div className="a-pics">{prod.images.map((im, i) => { const u = imgUrl(im.path); return (
        <div className="a-pic" key={im.id}>
          {u && <img src={u} alt="" loading="lazy" />}
          {i === 0 ? <span className="a-chip on">★ {t('main_photo')}</span> : <form action={imageOp}><input type="hidden" name="product" value={prod.id} /><input type="hidden" name="image" value={im.id} /><input type="hidden" name="op" value="main" /><button className="a-btn2 a-sm" style={{ width: '100%' }}>{t('make_main')}</button></form>}
          <div className="a-acts">
            {(['up', 'down'] as const).map((op) => <form key={op} action={imageOp}><input type="hidden" name="product" value={prod.id} /><input type="hidden" name="image" value={im.id} /><input type="hidden" name="op" value={op} /><button className="a-btn2 a-sm" disabled={(op === 'up' && i === 0) || (op === 'down' && i === prod.images.length - 1)} aria-label={op === 'up' ? t('move_earlier') : t('move_later')} title={op === 'up' ? t('move_earlier') : t('move_later')}>{op === 'up' ? '←' : '→'}</button></form>)}
          </div>
          <details className="a-conf" style={{ borderColor: 'var(--line)' }}><summary style={{ color: 'var(--ink)' }}>{t('replace')}</summary>
            <form action="/api/admin/upload" method="post" encType="multipart/form-data" className="a-grid"><input type="hidden" name="target" value="replace" /><input type="hidden" name="product" value={prod.id} /><input type="hidden" name="image" value={im.id} />
              <input type="file" name="file" accept="image/jpeg,image/png,image/webp,image/gif" required aria-label={t('replace')} /><button className="a-btn a-sm">{t('upload')}</button></form></details>
          <Confirm label={t('del')} question={t('sure')} yes={t('yes_delete')}><form action={imageOp}><input type="hidden" name="product" value={prod.id} /><input type="hidden" name="image" value={im.id} /><input type="hidden" name="op" value="remove" /><button className="a-btn3 a-sm">{t('yes_delete')}</button></form></Confirm>
        </div>); })}</div>
      <form action="/api/admin/upload" method="post" encType="multipart/form-data" className="a-row" style={{ marginTop: 16 }}>
        <input type="hidden" name="target" value="product" /><input type="hidden" name="product" value={prod.id} />
        <input type="file" name="file" multiple accept="image/jpeg,image/png,image/webp,image/gif" required aria-label={t('choose_files')} /><button className="a-btn">{t('upload')}</button></form>
    </section>

    <section className="a-card"><h2>{t('del_product_q')}</h2>
      <Confirm label={t('del')} question={t('del_product_q')} warn={t('del_product_w')} yes={t('yes_delete')}><form action={deleteProduct}><input type="hidden" name="id" value={prod.id} /><button className="a-btn3">{t('yes_delete')}</button></form></Confirm></section>
  </>);
}
