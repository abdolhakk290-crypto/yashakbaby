import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc } from '@/lib/admin';
import { Flash } from '@/components/AdminFlash';
import { ProductForm } from '@/components/ProductForm';
export default async function NewProduct({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  const sp = await searchParams, lang = await adminLang(), t = makeT(lang);
  const cats = await arpc<{ id: number; name: Record<string, string> }[]>('admin_list_categories');
  return (<><a className="a-link" href="/admin/products">← {t('products')}</a><h1 className="a-h">{t('new_product')}</h1><Flash sp={sp} t={t} />
    <ProductForm product={null} cats={cats} lang={lang} /><p className="a-sub" style={{ marginTop: 16 }}>{t('photos_save_first')}</p></>);
}
