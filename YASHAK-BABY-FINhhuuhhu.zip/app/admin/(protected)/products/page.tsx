import { adminLang, makeT } from '@/lib/admin-i18n';
import { arpc, pick, fromCents } from '@/lib/admin';
import { imgUrl } from '@/lib/store';
import { Flash } from '@/components/AdminFlash';
import { patchProduct, moveProduct, duplicateProduct } from '../actions';

type Row = { id: number; slug: string; name: Record<string, string>; price_cents: number; sale_price_cents: number | null; status: string; available: boolean; featured: boolean; category: Record<string, string> | null; image: string | null; stock_total: number; track_stock: boolean; variants: number };
export default async function Products({ searchParams }: { searchParams: Promise<{ q?: string; status?: string; cat?: string; ok?: string; err?: string }> }) {
  const sp = await searchParams, lang = await adminLang(), t = makeT(lang);
  const q = (sp.q || '').slice(0, 60), status = ['draft', 'published', 'archived'].includes(sp.status || '') ? sp.status! : '', cat = Number(sp.cat) || 0;
  const [rows, cats] = await Promise.all([arpc<Row[]>('admin_list_products', { p_q: q || null, p_status: status || null, p_category: cat || null }), arpc<{ id: number; name: Record<string, string> }[]>('admin_list_categories')]);
  const filtered = !!(q || status || cat), here = '/admin/products';
  const toggle = (id: number, field: string, value: string, label: string, cls = 'a-btn2 a-sm') => (
    <form action={patchProduct}><input type="hidden" name="id" value={id} /><input type="hidden" name="field" value={field} /><input type="hidden" name="value" value={value} /><input type="hidden" name="next" value={here} /><button className={cls}>{label}</button></form>);
  return (<>
    <div className="a-row" style={{ justifyContent: 'space-between' }}><h1 className="a-h">{t('products')}</h1><a className="a-btn3" href="/admin/products/new">+ {t('new_product')}</a></div>
    <p className="a-sub">{t('order_mgmt')}</p>
    <Flash sp={sp} t={t} />
    <form className="a-card a-row" method="get" role="search">
      <input className="a-in-t" style={{ flex: '2 1 180px' }} name="q" defaultValue={q} placeholder={t('search')} aria-label={t('search')} />
      <select className="a-sel" style={{ flex: '1 1 140px' }} name="status" defaultValue={status} aria-label={t('f_status')}><option value="">{t('all')}</option><option value="published">{t('st_published')}</option><option value="draft">{t('st_draft')}</option><option value="archived">{t('st_archived')}</option></select>
      <select className="a-sel" style={{ flex: '1 1 140px' }} name="cat" defaultValue={cat || ''} aria-label={t('f_cat')}><option value="">{t('all')}</option>{cats.map((c) => <option key={c.id} value={c.id}>{pick(c.name, lang)}</option>)}</select>
      <button className="a-btn2">{t('filter')}</button></form>
    {rows.length === 0 && <p>{t('no_products')}</p>}
    {rows.map((r, i) => {
      const img = imgUrl(r.image), pub = r.status === 'published';
      return (<article className="a-item" key={r.id}>
        <div className="a-th">{img ? <img src={img} alt="" width={72} height={72} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : '—'}</div>
        <div>
          <h3><a className="a-link" href={`/admin/products/${r.id}`}>{pick(r.name, lang)}</a></h3>
          <div className="a-meta">
            <b>{fromCents(r.sale_price_cents ?? r.price_cents)} DH</b>{r.sale_price_cents != null && <s>{fromCents(r.price_cents)}</s>}
            {r.category && <span>· {pick(r.category, lang)}</span>}
            <span className={`a-chip ${pub ? 'on' : 'off'}`}>{pub ? t('st_published') : r.status === 'draft' ? t('st_draft') : t('st_archived')}</span>
            <span className={`a-chip ${r.available ? 'on' : 'warn'}`}>{r.available ? t('available') : t('unavailable')}</span>
            {r.featured && <span className="a-chip">★ {t('featured')}</span>}
            {r.track_stock && <span title={t('stock_private')}>{t('stock_total')}: {r.stock_total}</span>}
          </div>
          <div className="a-acts">
            <a className="a-btn2 a-sm" href={`/admin/products/${r.id}`}>{t('edit')}</a>
            {toggle(r.id, 'status', pub ? 'draft' : 'published', pub ? t('unpublish') : t('publish'))}
            {toggle(r.id, 'available', r.available ? 'false' : 'true', r.available ? t('mark_unavailable') : t('mark_available'))}
            {toggle(r.id, 'featured', r.featured ? 'false' : 'true', r.featured ? '★' : '☆', 'a-btn2 a-sm')}
            {!filtered && <>
              <form action={moveProduct}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="dir" value="up" /><button className="a-btn2 a-sm" disabled={i === 0} aria-label={t('up')} title={t('up')}>↑</button></form>
              <form action={moveProduct}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="dir" value="down" /><button className="a-btn2 a-sm" disabled={i === rows.length - 1} aria-label={t('down')} title={t('down')}>↓</button></form></>}
            <form action={duplicateProduct}><input type="hidden" name="id" value={r.id} /><button className="a-btn2 a-sm">{t('duplicate')}</button></form>
          </div></div></article>);
    })}
  </>);
}
