import { adminLang, makeT } from '@/lib/admin-i18n';
import MfaSetup from '@/components/MfaSetup';
import PasswordChange from '@/components/PasswordChange';
export default async function Security() {
  const t = makeT(await adminLang());
  return (<><h1 className="a-h">{t('mfa_title')}</h1><p className="a-sub">{t('mfa_intro')}</p>
    <section className="a-card"><MfaSetup l={{ on: t('mfa_on'), off: t('mfa_off'), start: t('mfa_start'), scan: t('mfa_scan'), code: t('mfa_code'), verify: t('mfa_verify'), bad: t('mfa_bad') }} /><p className="a-sub" style={{ marginTop: 12 }}>{t('mfa_keep')}</p></section>
    <section className="a-card"><h2>{t('pw_title')}</h2><PasswordChange l={{ n: t('pw_new'), again: t('pw_again'), save: t('pw_save'), ok: t('pw_ok'), short: t('pw_short'), diff: t('pw_diff'), fail: t('pw_fail') }} /></section></>);
}
