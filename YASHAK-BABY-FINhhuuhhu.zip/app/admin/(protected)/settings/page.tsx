import { adminLang, makeT, L6 } from '@/lib/admin-i18n';
import { arpc } from '@/lib/admin';
import { Flash } from '@/components/AdminFlash';
import { saveSettings } from '../actions';

export default async function Settings({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  const sp = await searchParams, lang = await adminLang(), t = makeT(lang);
  const all = await arpc<Record<string, any>>('admin_get_settings'), st = all.store || {}, so = all.social || {}, wa = all.whatsapp || {}, lg = all.legal || {};   // eslint-disable-line @typescript-eslint/no-explicit-any
  return (<>
    <h1 className="a-h">{t('settings')}</h1><Flash sp={sp} t={t} />
    <form action={saveSettings}>
      <section className="a-card"><h2>{t('contact')}</h2><div className="a-grid a-g2">
        <label className="a-f"><span>{t('s_name')}</span><input name="name" maxLength={80} defaultValue={st.name || ''} /></label>
        <label className="a-f"><span>{t('s_email')}</span><input name="email" type="email" required maxLength={120} defaultValue={st.email || ''} /></label>
        <label className="a-f"><span>{t('s_phone')}</span><input name="phone" maxLength={40} defaultValue={st.phone || ''} dir="ltr" /></label>
        <label className="a-f"><span>{t('s_address')}</span><input name="address" maxLength={200} defaultValue={st.address || ''} /></label>
        <label className="a-f"><span>{t('s_site')}</span><input name="base_url" maxLength={120} defaultValue={st.base_url || ''} dir="ltr" placeholder="https://" /></label></div></section>
      <section className="a-card" id="whatsapp"><h2>{t('whatsapp')}</h2>
        <label className="a-f"><span>{t('wa_number')}</span><input name="wa_number" inputMode="numeric" maxLength={20} defaultValue={wa.number || ''} dir="ltr" placeholder="212601668146" /></label>
        <label className="a-chk"><input type="checkbox" name="wa_enabled" defaultChecked={!!wa.enabled} /> {t('wa_enabled')}</label>
        <label className="a-chk"><input type="checkbox" name="wa_product" defaultChecked={!!wa.show_product} /> {t('wa_product')}</label>
        <label className="a-chk"><input type="checkbox" name="wa_home" defaultChecked={!!wa.show_home} /> {t('wa_home')}</label>
        <label className="a-chk"><input type="checkbox" name="wa_contact" defaultChecked={!!wa.show_contact} /> {t('wa_contact')}</label>
        <h3>{t('wa_template')}</h3><p className="a-sub" style={{ marginBottom: 8 }}>{t('wa_template_hint')}</p>
        {L6.map((l) => <label className="a-f" key={l.c}><span>{l.n}</span><textarea name={`wa_tpl_${l.c}`} maxLength={1000} defaultValue={wa.templates?.[l.c] || ''} dir={l.c === 'ar' || l.c === 'ary' ? 'rtl' : 'ltr'} /></label>)}</section>
      <section className="a-card"><h2>{t('social')}</h2><div className="a-grid a-g2">
        {(['instagram', 'facebook', 'tiktok'] as const).map((k) => <label className="a-f" key={k}><span>{k[0].toUpperCase() + k.slice(1)} (https://…)</span><input name={k} maxLength={200} defaultValue={so[k] || ''} dir="ltr" /></label>)}</div></section>
      <section className="a-card"><h2>{t('returns')}</h2><p className="a-er" role="note">{t('returns_warn')}</p>
        <label className="a-chk"><input type="checkbox" name="returns_published" defaultChecked={!!lg.returns_published} /> {t('returns_pub')}</label></section>
      <div className="a-sticky"><button className="a-btn">{t('save')}</button></div>
    </form></>);
}
