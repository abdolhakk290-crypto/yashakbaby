'use client';
import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';
import { siteOrigin, RESET_PATH } from '@/lib/site-url';

/** Step 1 of the password reset: ask Supabase Auth to email a one-time link to the address. The answer shown never reveals whether the address has an account. */
export default function Forgot() {
  const [email, setEmail] = useState(''), [done, setDone] = useState(false), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const { error } = await supabaseBrowser().auth.resetPasswordForEmail(email.trim(), { redirectTo: siteOrigin() + RESET_PATH });
      // "no such user" is deliberately not reported (no account enumeration); only rate-limit / service errors are shown
      if (error && (error.status === 429 || (error.status ?? 0) >= 500)) throw new Error(error.status === 429 ? 'Too many requests. Please wait a few minutes and try again.' : 'The sign-in service is unavailable. Please try again shortly.');
      setDone(true);
    } catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  }
  const input = { width: '100%', minHeight: 40, padding: '8px 12px', border: '1px solid #e4dfe8', borderRadius: 8, boxSizing: 'border-box' as const };
  const card = { maxWidth: 380, margin: '12vh auto', padding: 28, background: '#fff', border: '1px solid #e4dfe8', borderRadius: 14, display: 'grid', gap: 12 };
  return (
    <form onSubmit={submit} style={card}>
      <img src="/img/logo-h.jpg" alt="YASHAK BABY" style={{ height: 48, justifySelf: 'center' }} />
      <h1 style={{ fontSize: 22, margin: 0, textAlign: 'center' }}>Reset password</h1>
      {done ? (
        <p role="status" style={{ margin: 0 }}>If this address belongs to an administrator account, a reset link has been sent. Open it in <strong>this same browser</strong>. The link is valid for a limited time and works once.</p>
      ) : (<>
        <label>Email<input style={input} type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <p role="alert" style={{ color: '#b3261e', margin: 0 }}>{err}</p>
        <button disabled={busy} style={{ minHeight: 40, border: 0, borderRadius: 8, background: '#5b3f8c', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>{busy ? '…' : 'Send reset link'}</button>
      </>)}
      <a href="/admin/login" style={{ textAlign: 'center', color: '#5b3f8c' }}>Back to sign in</a>
    </form>
  );
}
