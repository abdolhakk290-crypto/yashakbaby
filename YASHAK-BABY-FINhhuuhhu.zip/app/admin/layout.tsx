import type { Metadata } from 'next';
import '../styles/store.css';
import './admin.css';
import { adminLang, ARTL } from '@/lib/admin-i18n';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'YASHAK BABY · Admin', robots: { index: false, follow: false } };
export default async function AdminRoot({ children }: { children: React.ReactNode }) {
  const lang = await adminLang();
  return (<html lang={lang === 'zgh' ? 'fr' : lang} dir={ARTL.has(lang) ? 'rtl' : 'ltr'}><body className="a-body">{children}</body></html>);
}
