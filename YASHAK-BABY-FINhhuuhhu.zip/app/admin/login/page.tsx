'use client';
import { useEffect, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';

export default function Login() {
  const DENIED = 'Access denied: this account is not an authorised administrator (or two-step verification is not completed).';
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [code, setCode] = useState(''), [factor, setFactor] = useState<string | null>(null), [err, setErr] = useState(''), [ok, setOk] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => { const q = new URLSearchParams(window.location.search); if (q.get('e') === 'denied') setErr(DENIED); if (q.get('reset') === 'ok') setOk('Password changed. Please sign in with your new password.'); }, [DENIED]);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const sb = supabaseBrowser();
      if (!factor) {
        const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw new Error(error.status === 400 ? 'Incorrect email or password.' : 'Sign-in service error: ' + error.message + ' (check the Supabase address and key in the website settings).');
        const { data: aal } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
        if (aal?.nextLevel === 'aal2' && aal.currentLevel !== 'aal2') {
          const { data: f } = await sb.auth.mfa.listFactors(); const totp = f?.totp?.[0];
          if (!totp) throw new Error('Two-step verification is not set up correctly.');
          setFactor(totp.id); return;
        }
      } else {
        const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: factor, code });
        if (error) throw new Error('Incorrect verification code.');
      }
      // Signed in with Supabase Auth. Now confirm this user is an administrator (public.admins, via is_admin(), which also requires the 2-step code when one is set up).
      const { data: isAdmin, error: adminErr } = await sb.rpc('is_admin');
      if (adminErr) throw new Error('Could not verify administrator access. Please try again.');
      if (isAdmin !== true) { await sb.auth.signOut(); throw new Error(DENIED); }
      window.location.href = '/admin/dashboard';
    } catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  }
  const input = { width: '100%', minHeight: 40, padding: '8px 12px', border: '1px solid #e4dfe8', borderRadius: 8, boxSizing: 'border-box' as const };
  return (
    <form onSubmit={submit} style={{ maxWidth: 380, margin: '12vh auto', padding: 28, background: '#fff', border: '1px solid #e4dfe8', borderRadius: 14, display: 'grid', gap: 12 }}>
      <img src="/img/logo-h.jpg" alt="YASHAK BABY" style={{ height: 48, justifySelf: 'center' }} />
      <h1 style={{ fontSize: 22, margin: 0, textAlign: 'center' }}>Administration</h1>
      {!factor ? (<>
        <label>Email<input style={input} type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Password<input style={input} type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label></>
      ) : (<label>Verification code<input style={input} inputMode="numeric" autoComplete="one-time-code" maxLength={6} required value={code} onChange={(e) => setCode(e.target.value)} /></label>)}
      {ok && <p role="status" style={{ color: '#1b6e3c', margin: 0 }}>{ok}</p>}
      <p role="alert" style={{ color: '#b3261e', margin: 0 }}>{err}</p>
      <button disabled={busy} style={{ minHeight: 40, border: 0, borderRadius: 8, background: '#5b3f8c', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>{busy ? '…' : 'Sign in'}</button>
      {!factor && <a href="/admin/forgot" style={{ textAlign: 'center', color: '#5b3f8c' }}>Forgot password?</a>}
    </form>
  );
}
