'use client';
import { useEffect, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';

const MIN = 10;
/** Step 2: the emailed link lands here. Supabase's browser client exchanges the one-time code for a short recovery session (PKCE),
 *  then the person chooses a new password. Nothing is stored or logged; afterwards the session is closed and they sign in normally. */
export default function Reset() {
  const [state, setState] = useState<'checking' | 'ready' | 'invalid'>('checking');
  const [pw, setPw] = useState(''), [pw2, setPw2] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => {
    const sb = supabaseBrowser();
    const q = new URLSearchParams(window.location.search), h = new URLSearchParams(window.location.hash.replace(/^#/, ''));
    if (q.get('error') || q.get('error_code') || h.get('error') || h.get('error_code')) { setState('invalid'); return; }   // e.g. otp_expired
    let alive = true;
    const { data: sub } = sb.auth.onAuthStateChange((ev, session) => { if (alive && session && (ev === 'PASSWORD_RECOVERY' || ev === 'SIGNED_IN' || ev === 'INITIAL_SESSION')) setState('ready'); });
    // the client picks the code up from the URL by itself; give it a moment, then check for a session
    const t = setTimeout(async () => { const { data } = await sb.auth.getSession(); if (alive) setState(data.session ? 'ready' : 'invalid'); }, 2500);
    return () => { alive = false; clearTimeout(t); sub.subscription.unsubscribe(); };
  }, []);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    if (pw.length < MIN) return setErr(`Use at least ${MIN} characters.`);
    if (pw !== pw2) return setErr('The two passwords do not match.');
    setBusy(true);
    try {
      const sb = supabaseBrowser();
      const { error } = await sb.auth.updateUser({ password: pw });
      if (error) throw new Error(/same/i.test(error.message) ? 'Choose a password different from the previous one.' : /weak|short|least|pwned|compromised/i.test(error.message) ? 'That password is too weak. Choose a longer, less common one.' : 'Could not change the password: ' + error.message);
      await sb.auth.signOut();
      window.location.href = '/admin/login?reset=ok';
    } catch (x) { setErr((x as Error).message); setBusy(false); }
  }
  const input = { width: '100%', minHeight: 40, padding: '8px 12px', border: '1px solid #e4dfe8', borderRadius: 8, boxSizing: 'border-box' as const };
  const card = { maxWidth: 380, margin: '12vh auto', padding: 28, background: '#fff', border: '1px solid #e4dfe8', borderRadius: 14, display: 'grid', gap: 12 };
  if (state !== 'ready') return (
    <div style={card}>
      <img src="/img/logo-h.jpg" alt="YASHAK BABY" style={{ height: 48, justifySelf: 'center' }} />
      <h1 style={{ fontSize: 22, margin: 0, textAlign: 'center' }}>Reset password</h1>
      {state === 'checking' ? <p role="status" style={{ margin: 0 }}>Checking your reset link…</p>
        : <p role="alert" style={{ color: '#b3261e', margin: 0 }}>This reset link is invalid, expired or already used. Open the link in the same browser where you requested it, or request a new one.</p>}
      {state === 'invalid' && <a href="/admin/forgot" style={{ textAlign: 'center', color: '#5b3f8c' }}>Request a new link</a>}
    </div>);
  return (
    <form onSubmit={submit} style={card}>
      <img src="/img/logo-h.jpg" alt="YASHAK BABY" style={{ height: 48, justifySelf: 'center' }} />
      <h1 style={{ fontSize: 22, margin: 0, textAlign: 'center' }}>Choose a new password</h1>
      <label>New password<input style={input} type="password" autoComplete="new-password" minLength={MIN} required value={pw} onChange={(e) => setPw(e.target.value)} /></label>
      <label>Repeat password<input style={input} type="password" autoComplete="new-password" minLength={MIN} required value={pw2} onChange={(e) => setPw2(e.target.value)} /></label>
      <p role="alert" style={{ color: '#b3261e', margin: 0 }}>{err}</p>
      <button disabled={busy} style={{ minHeight: 40, border: 0, borderRadius: 8, background: '#5b3f8c', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>{busy ? '…' : 'Save new password'}</button>
    </form>
  );
}
