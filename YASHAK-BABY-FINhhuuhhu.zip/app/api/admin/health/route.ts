import { NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';

/** Self-check for "I cannot sign in". Returns ONLY yes/no facts about the website's Supabase settings. Never returns a key, a password or any user data. */
export async function GET() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '', key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
  let host = ''; try { host = new URL(url).host; } catch { /* not a URL */ }
  let kind = key ? 'unknown' : 'missing', keyRef: string | null = null;
  if (key.startsWith('sb_publishable_')) kind = 'publishable (correct type)';
  else if (key.startsWith('sb_secret_')) kind = 'SECRET key (WRONG: must be the publishable/anon key)';
  else if (key.split('.').length === 3) {
    try { const c = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()); kind = c.role === 'anon' ? 'anon (correct type)' : c.role === 'service_role' ? 'service_role (WRONG: must be the anon key)' : `jwt role ${String(c.role).slice(0, 20)}`; keyRef = typeof c.ref === 'string' ? c.ref : null; } catch { kind = 'unreadable'; }
  }
  const out: Record<string, unknown> = {
    url_set: !!url, url_looks_valid: /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url) || /^http:\/\/localhost/.test(url), project_host: host || null,
    key_set: !!key, key_type: kind, key_belongs_to_this_url: keyRef && host ? host.startsWith(keyRef + '.') : null,
    service_key_set_on_server: !!process.env.SUPABASE_SERVICE_ROLE_KEY, whitespace_in_settings: url !== url.trim() || key !== key.trim() || /["'\s]/.test(url) || /["'\s]/.test(key),
  };
  try {
    const r = await fetch(`${url}/auth/v1/settings`, { headers: { apikey: key }, signal: AbortSignal.timeout(6000), cache: 'no-store' });
    out.auth_reachable = r.ok; out.auth_http_status = r.status;
    if (r.ok) { const s = await r.json().catch(() => ({})); out.email_password_login_enabled = s?.external?.email ?? null; out.new_signups_disabled = s?.disable_signup ?? null; }
  } catch { out.auth_reachable = false; out.auth_http_status = null; }
  return NextResponse.json(out, { headers: { 'Cache-Control': 'no-store' } });
}
