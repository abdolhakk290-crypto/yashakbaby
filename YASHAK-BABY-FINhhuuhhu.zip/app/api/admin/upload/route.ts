import { NextResponse, type NextRequest } from 'next/server';
import { currentAdmin, supabaseServer } from '@/lib/supabase-server';
import { arpc, errKeys, fresh, removeFiles } from '@/lib/admin';
import type { AKey } from '@/lib/admin-i18n';

export const dynamic = 'force-dynamic';
const MAX = 8 * 1024 * 1024, MAX_FILES = 8;

/** The real type of an image is read from its first bytes. The file name and the browser's "content type" are never trusted. SVG (can carry scripts) is not accepted. */
function sniff(b: Uint8Array): { ext: string; type: string } | null {
  const s = (i: number, str: string) => str.split('').every((c, k) => b[i + k] === c.charCodeAt(0));
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: 'jpg', type: 'image/jpeg' };
  if (b[0] === 0x89 && s(1, 'PNG') && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) return { ext: 'png', type: 'image/png' };
  if (s(0, 'GIF87a') || s(0, 'GIF89a')) return { ext: 'gif', type: 'image/gif' };
  if (s(0, 'RIFF') && s(8, 'WEBP')) return { ext: 'webp', type: 'image/webp' };
  return null;
}
const back = (path: string, ok: boolean, err: AKey[] = []) => {
  const u = new URLSearchParams(); if (ok) u.set('ok', '1'); if (err.length) u.set('err', err.join(','));
  return new NextResponse(null, { status: 303, headers: { Location: `${path}${u.size ? '?' + u : ''}`, 'Cache-Control': 'no-store' } });
};
const deny = (status: number, msg: string) => NextResponse.json({ error: msg }, { status, headers: { 'Cache-Control': 'no-store' } });
const num = (v: FormDataEntryValue | null) => { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : 0; };

export async function POST(req: NextRequest) {
  // 1. the request must come from this very website (blocks forms hosted on other sites)
  const host = req.headers.get('host') || '', origin = req.headers.get('origin');
  if (origin) { let h = ''; try { h = new URL(origin).host; } catch { /* invalid */ } if (!h || h !== host) return deny(403, 'Forbidden'); }
  else if (req.headers.get('sec-fetch-site') !== 'same-origin') return deny(403, 'Forbidden');
  // 2. a signed-in administrator (checked against the admins table)
  if (!(await currentAdmin())) return deny(401, 'Unauthorized');
  if (!(req.headers.get('content-type') || '').toLowerCase().startsWith('multipart/form-data')) return deny(415, 'Unsupported media type');
  if (Number(req.headers.get('content-length') || 0) > MAX * MAX_FILES + 65536) return deny(413, 'Too large');

  let fd: FormData; try { fd = await req.formData(); } catch { return deny(400, 'Bad request'); }
  const target = String(fd.get('target') || ''), pid = num(fd.get('product')), iid = num(fd.get('image')), cid = num(fd.get('category')), key = String(fd.get('key') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
  const page = target === 'product' || target === 'replace' ? `/admin/products/${pid}` : target === 'category' ? '/admin/categories' : '/admin/content';
  if (!['product', 'replace', 'category', 'hero', 'section'].includes(target)) return deny(400, 'Bad request');
  const files = fd.getAll('file').filter((f): f is File => f instanceof File && f.size > 0).slice(0, target === 'product' ? MAX_FILES : 1);
  if (!files.length) return back(page, false, ['err_upload_none']);

  const sb = await supabaseServer(), uploaded: string[] = [], dir = target === 'product' || target === 'replace' ? 'products' : 'site';
  const cleanup = () => removeFiles(uploaded);
  try {
    for (const f of files) {
      if (f.size > MAX) { await cleanup(); return back(page, false, ['err_upload_size']); }
      const bytes = new Uint8Array(await f.arrayBuffer()), kind = sniff(bytes);
      if (!kind) { await cleanup(); return back(page, false, ['err_upload_type']); }
      const name = `${dir}/${crypto.randomUUID()}.${kind.ext}`;       // server-chosen name: the visitor's file name is never used
      const { error } = await sb.storage.from('store-media').upload(name, bytes, { contentType: kind.type, upsert: false, cacheControl: '31536000' });
      if (error) { await cleanup(); return back(page, false, ['err_generic']); }
      uploaded.push(name);
    }
    let toDelete: string[] = [];
    if (target === 'product') { for (const p of uploaded) await arpc('admin_add_image', { p_product: pid, p_path: p }); }
    else if (target === 'replace') {
      const prod = await arpc<{ images: { id: number; path: string }[] }>('admin_get_product', { p_id: pid }), ids = prod.images.map((x) => x.id), at = ids.indexOf(iid);
      if (at < 0) { await cleanup(); return back(page, false, ['err_image']); }
      const nid = await arpc<number>('admin_add_image', { p_product: pid, p_path: uploaded[0] });
      ids.splice(at, 1, nid); await arpc('admin_order_images', { p_product: pid, p_ids: ids });
      const old = await arpc<string | null>('admin_remove_image', { p_id: iid }); if (old) toDelete = [old];
    } else if (target === 'category') {
      const cats = await arpc<{ id: number; image: string | null }[]>('admin_list_categories'), cur = cats.find((c) => c.id === cid);
      if (!cur) { await cleanup(); return back(page, false, ['err_category']); }
      await arpc('admin_save_category', { p: { id: cid, image: uploaded[0] } }); if (cur.image) toDelete = [cur.image];
    } else {
      const all = await arpc<Record<string, any>>('admin_get_settings'), home = { ...(all.home || {}) } as Record<string, any>;   // eslint-disable-line @typescript-eslint/no-explicit-any
      if (target === 'hero') { toDelete = [home.hero?.image].filter(Boolean); home.hero = { ...(home.hero || {}), image: uploaded[0] }; }
      else {
        const secs = (Array.isArray(home.sections) ? home.sections : []).map((s: any) => ({ ...s })), s = secs.find((x: any) => x.key === key);   // eslint-disable-line @typescript-eslint/no-explicit-any
        if (!s) { await cleanup(); return back(page, false, ['err_image']); }
        if (s.image) toDelete = [s.image]; s.image = uploaded[0]; home.sections = secs;
      }
      await arpc('admin_save_setting', { p_key: 'home', p_value: home });
    }
    await removeFiles(toDelete); fresh();
    return back(page, true);
  } catch (e) {
    await cleanup();
    try { return back(page, false, errKeys(e)); } catch { return deny(500, 'Server error'); }
  }
}
