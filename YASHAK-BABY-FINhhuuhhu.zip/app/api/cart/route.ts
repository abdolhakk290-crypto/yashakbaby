import type { NextRequest } from 'next/server';
import { rpc, DbError } from '@/lib/db';
import { allow, checkRequest, clientIp, json, readJson } from '@/lib/guard';
import { LANG_CODES, loc, type Lang } from '@/lib/i18n';
import { getCheckout, getSite, imgUrl } from '@/lib/store';

export const dynamic = 'force-dynamic';
type Line = { v: number; gone?: true; asked?: number; ok?: boolean; in_stock?: boolean; unit?: number; slug?: string; name?: Record<string, string>; size?: string | null; color?: string | null; image?: string | null };

export async function POST(req: NextRequest) {
  const bad = checkRequest(req); if (bad) return bad;
  const body = await readJson(req); if (!body) return json({ error: 'Invalid request' }, 400);
  const lang = (LANG_CODES.includes(String(body.lang)) ? body.lang : 'fr') as Lang;
  try {
    if (!(await allow('cart:' + clientIp(req), 240, 600))) return json({ error: 'Too many requests' }, 429);
    const items = Array.isArray(body.items) ? body.items.slice(0, 100) : [];
    const cart = await rpc<{ subtotal: number; lines: Line[] }>('get_cart', { p_items: items });
    const [delivery, site, co] = await Promise.all([rpc<number>('_delivery_for', { p_subtotal: cart.subtotal }, 'service'), getSite(lang), getCheckout(lang)]);
    const lines = cart.lines.map((l) => l.gone ? { v: l.v, gone: true } : { v: l.v, q: l.asked, ok: l.ok, in_stock: l.in_stock, unit: l.unit, slug: l.slug, name: loc(l.name, lang), size: l.size, color: l.color, image: imgUrl(l.image) });
    const st = site.settings.store || {};
    return json({ lines, subtotal: cart.subtotal, delivery, total: cart.subtotal + delivery, deliverySet: (co.delivery?.fee_cents ?? 0) > 0, sym: st.currency_symbol || st.currency || '', methods: co.methods });
  } catch (e) {
    console.error('cart error', e instanceof DbError ? e.code + ' ' + e.message : e);
    return json({ error: 'Server error' }, 500);
  }
}
