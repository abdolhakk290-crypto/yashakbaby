import type { NextRequest } from 'next/server';
import { rpc, DbError } from '@/lib/db';
import { allow, checkRequest, clientIp, json, readJson } from '@/lib/guard';
import { LANG_CODES, loc, type Lang } from '@/lib/i18n';
import { getSite } from '@/lib/store';

export const dynamic = 'force-dynamic';
// text fields only: cut to length and strip control characters (a NUL byte would make PostgreSQL refuse the whole JSON)
const str = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').slice(0, max) : '');
type Placed = { id: number; number: string; subtotal: number; delivery: number; total: number; method: string | null; bank?: Record<string, unknown>; cod?: Record<string, string> };

export async function POST(req: NextRequest) {
  const bad = checkRequest(req); if (bad) return bad;
  const body = await readJson(req); if (!body) return json({ error: 'Invalid request' }, 400);
  const lang = (LANG_CODES.includes(String(body.lang)) ? body.lang : 'fr') as Lang;
  // only the known fields are passed on; prices and totals sent by the browser are never read
  const order = { name: str(body.name, 200), phone: str(body.phone, 40), city: str(body.city, 200), address: str(body.address, 600), email: str(body.email, 200), note: str(body.note, 1200),
    payment: str(body.payment, 10), items: Array.isArray(body.items) ? body.items.slice(0, 100).map((i: { v?: unknown; q?: unknown }) => ({ v: i?.v, q: i?.q })) : [] };
  try {
    if (!(await allow('orders:' + clientIp(req), +(process.env.ORDER_RATE_LIMIT || 20), 3600))) return json({ error: 'Too many orders. Please try again later.' }, 429);
    const o = await rpc<Placed>('place_order', { p: order, p_lang: lang }, 'service');
    const site = await getSite(lang), w = site.settings.whatsapp || {};
    const out: Record<string, unknown> = { number: o.number, total: o.total, delivery: o.delivery, method: o.method, wa: w.enabled ? String(w.number || '') : '' };
    if (o.method === 'bank' && o.bank) { const b = o.bank as Record<string, unknown>; out.bank = { bank_name: b.bank_name, holder: b.holder, iban: b.iban, bic: b.bic, instructions: loc(b.instructions as Record<string, string>, lang) }; }
    if (o.method === 'cod') out.instructions = loc(o.cod, lang);
    return json(out, 201);
  } catch (e) {
    if (e instanceof DbError && e.code === 'YB422') { let fields = {}; try { fields = JSON.parse(e.detail || '{}'); } catch { /* none */ } return json({ error: e.message, fields }, 422); }
    if (e instanceof DbError && e.code === 'YB409') { let d: { lines?: unknown } = {}; try { d = JSON.parse(e.detail || '{}'); } catch { /* none */ } return json({ error: e.message, lines: d.lines || [] }, 409); }
    console.error('order error', e instanceof DbError ? e.code + ' ' + e.message : e);
    return json({ error: 'Server error' }, 500);
  }
}
