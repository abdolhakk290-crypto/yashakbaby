'use client';
import { usePathname } from 'next/navigation';
import { useRef } from 'react';

export function AdminNav({ items }: { items: { href: string; label: string }[] }) {
  const path = usePathname();
  return (<nav className="a-nav" aria-label="Admin"><div className="a-in">{items.map((i) => {
    const on = i.href === '/admin/dashboard' ? path === '/admin' || path === '/admin/dashboard' : path === i.href || path.startsWith(i.href + '/');
    return <a key={i.href} href={i.href} aria-current={on ? 'page' : undefined}>{i.label}</a>;
  })}</div></nav>);
}
export function LangSelect({ action, current, options, label }: { action: (fd: FormData) => void | Promise<void>; current: string; options: readonly { c: string; n: string }[]; label: string }) {
  const f = useRef<HTMLFormElement>(null), path = usePathname();
  return (<form ref={f} action={action} className="a-row"><input type="hidden" name="next" value={path} />
    <select name="lang" aria-label={label} defaultValue={current} className="a-sel" style={{ minHeight: 36, width: 'auto', padding: '4px 8px' }} onChange={() => f.current?.requestSubmit()}>{options.map((o) => <option key={o.c} value={o.c}>{o.n}</option>)}</select>
    <noscript><button className="a-btn2 a-sm">OK</button></noscript></form>);
}
