import { flashKeys } from '@/lib/admin';
import type { AKey } from '@/lib/admin-i18n';
export function Flash({ sp, t }: { sp: { ok?: string; err?: string }; t: (k: AKey) => string }) {
  const f = flashKeys(sp);
  return (<>{f.ok && <p className="a-ok" role="status">{t('saved')}</p>}
    {f.err.length > 0 && <div className="a-er" role="alert"><ul>{f.err.map((k) => <li key={k}>{t(k)}</li>)}</ul></div>}</>);
}
export function Confirm({ label, question, warn, yes, children }: { label: string; question: string; warn?: string; yes: string; children: React.ReactNode }) {
  // A pure-HTML confirmation (no JavaScript needed): opening it reveals the real delete button.
  void yes; return (<details className="a-conf"><summary>{label}</summary><p><b>{question}</b></p>{warn && <p>{warn}</p>}{children}</details>);
}
