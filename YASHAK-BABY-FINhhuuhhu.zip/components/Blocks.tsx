import type { ReactNode } from 'react';
import type { PageBlock } from '@/lib/i18n';

/** Renders the structured information-page blocks (paragraph, heading, list, notice, question). Text is rendered as text, never as HTML. */
export default function Blocks({ blocks, vars }: { blocks: PageBlock[]; vars: { addr: string; mail: string; phone: string } }) {
  const sub = (s: string): ReactNode[] => s.split(/(\{addr\}|\{mail\}|\{phone\})/).map((part, i) =>
    part === '{addr}' ? <bdi key={i} dir="auto">{vars.addr}</bdi> : part === '{mail}' ? <bdi key={i} className="lat">{vars.mail}</bdi> : part === '{phone}' ? <bdi key={i} className="lat">{vars.phone}</bdi> : part);
  return <>{blocks.map((b, i) => {
    if (b[0] === 'p') return <p key={i}>{sub(b[1])}</p>;
    if (b[0] === 'h') return <h2 key={i}>{b[1]}</h2>;
    if (b[0] === 'l') return <ul key={i}>{b[1].map((x, j) => <li key={j}>{sub(x)}</li>)}</ul>;
    if (b[0] === 'n') return <div key={i} className="callout"><b>{b[1]}</b></div>;
    if (b[0] === 'q') return <details key={i} className="q"><summary>{b[1]}</summary><p>{sub(b[2])}</p></details>;
    return null;
  })}</>;
}
