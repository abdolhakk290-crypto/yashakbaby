'use client';
import { useEffect, useState } from 'react';
import { loadCart } from '@/lib/cart-client';
import { Icon } from './Icon';

export default function CartBadge({ lang, label }: { lang: string; label: string }) {
  const [n, setN] = useState(0);
  useEffect(() => { const f = () => setN(loadCart().reduce((s, x) => s + x.q, 0)); f(); window.addEventListener('yb-cart', f); window.addEventListener('storage', f); return () => { window.removeEventListener('yb-cart', f); window.removeEventListener('storage', f); }; }, []);
  return <a className="ib" id="cbtn" href={`/${lang}/cart`} aria-label={label}><Icon name="bag" /><span className="cnt lat" id="ccount" hidden={!n}>{n}</span></a>;
}
