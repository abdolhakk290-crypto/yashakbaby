'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { loadCart, saveCart, type CartItem } from '@/lib/cart-client';
import { fmtMoney, waLink } from '@/lib/format';

type Line = { v: number; gone?: boolean; q: number; ok: boolean; in_stock: boolean; unit: number; slug: string; name: string; size: string | null; color: string | null; image: string | null };
type State = { lines: Line[]; subtotal: number; delivery: number; total: number; deliverySet: boolean; sym: string; methods: { key: 'bank' | 'cod'; instructions: string }[] };
type Done = { number: string; total: number; method: string | null; bank?: { bank_name?: string; holder?: string; iban?: string; bic?: string; instructions?: string }; instructions?: string; wa?: string };
export type CartStrings = Record<string, string>;
const FIELDS = [['name', 'text', 'name'], ['phone', 'tel', 'tel'], ['city', 'text', 'address-level2'], ['address', 'text', 'street-address'], ['email', 'email', 'email'], ['note', 'text', 'off']] as const;

export default function CartView({ lang, L, cont }: { lang: string; L: CartStrings; cont: string }) {
  const [state, setState] = useState<State | null>(null), [empty, setEmpty] = useState(false), [failed, setFailed] = useState(false), [done, setDone] = useState<Done | null>(null);
  const [form, setForm] = useState<Record<string, string>>({ name: '', phone: '', city: '', address: '', email: '', note: '' }), [errs, setErrs] = useState<Record<string, string>>({}), [top, setTop] = useState(''), [busy, setBusy] = useState(false), [pay, setPay] = useState('');
  const refs = useRef<Record<string, HTMLInputElement | null>>({});

  const refresh = useCallback(async () => {
    const cart = loadCart(); if (!cart.length) { setEmpty(true); setState(null); return; }
    try {
      const r = await fetch('/api/cart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: cart, lang }) });
      if (!r.ok) throw new Error(String(r.status)); const s: State = await r.json();
      const keep: CartItem[] = s.lines.filter((l) => !l.gone).map((l) => ({ v: l.v, q: Math.max(1, l.q) }));   // forget products that no longer exist
      if (JSON.stringify(keep) !== JSON.stringify(cart)) saveCart(keep);
      if (!keep.length) { setEmpty(true); setState(null); return; }
      setEmpty(false); setFailed(false); setState({ ...s, lines: s.lines.filter((l) => !l.gone) }); setPay((p) => p || s.methods[0]?.key || '');
    } catch { setFailed(true); }
  }, [lang]);
  useEffect(() => { refresh(); }, [refresh]);

  const setQty = (v: number, q: number) => { const c = loadCart(); c.forEach((x) => { if (x.v === v) x.q = Math.max(1, Math.min(50, q)); }); saveCart(c); refresh(); };
  const remove = (v: number) => { saveCart(loadCart().filter((x) => x.v !== v)); refresh(); };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setTop(''); const er: Record<string, string> = {}; const body: Record<string, unknown> = { items: loadCart(), lang };
    for (const [k] of FIELDS) body[k] = form[k].trim();
    for (const k of ['name', 'phone', 'city', 'address']) if (!form[k].trim()) er[k] = L.n_req;
    if (form.phone.trim() && !/^\+?\d{8,15}$/.test(form.phone.replace(/[\s().-]/g, ''))) er.phone = L.n_phone_bad;
    setErrs(er); if (Object.keys(er).length) { refs.current[Object.keys(er)[0]]?.focus(); return; }
    if (state?.methods.length) body.payment = pay;
    setBusy(true);
    try {
      const r = await fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); const j = await r.json();
      if (r.ok) { saveCart([]); setDone(j); window.scrollTo(0, 0); return; }
      setBusy(false);
      if (j.fields) setErrs(Object.fromEntries(Object.keys(j.fields).map((k) => [k, k === 'phone' ? L.n_phone_bad : L.n_req])));
      setTop(r.status === 409 ? L.n_stock : L.n_fail); if (r.status === 409) refresh();
    } catch { setBusy(false); setTop(L.n_fail); }
  };

  if (done) return (
    <div className="thanks"><h2>{L.n_thanks}</h2><p><span>{L.n_thanks_t}: </span><b className="lat">{done.number}</b></p><p>{L.n_thanks_s}</p>
      {done.method === 'bank' && done.bank && <><dl className="dl">{([[L.n_bank_b, done.bank.bank_name], [L.n_bank_h, done.bank.holder], [L.n_bank_i, done.bank.iban], [L.n_bank_c, done.bank.bic]] as const).filter((r) => r[1]).map(([a, b]) => <div key={a}><dt>{a}</dt><dd className="lat" dir="auto">{b}</dd></div>)}</dl>
        {done.bank.instructions && <p>{done.bank.instructions}</p>}<p><b>{L.n_total}: </b><span className="lat">{fmtMoney(done.total, state?.sym || L.sym)}</span></p></>}
      {done.method === 'cod' && done.instructions && <p>{done.instructions}</p>}
      {done.wa && <p><a className="btn sec2" target="_blank" rel="noopener noreferrer" href={waLink(done.wa, `${L.n_thanks_t}: ${done.number}`)}>{L.wa_btn}</a></p>}
      <a className="btn" href={cont}>{L.cont}</a></div>);
  if (empty) return <div className="empty"><p>{L.cart_empty}</p><a className="btn sec2" href={cont}>{L.cont}</a></div>;
  if (failed) return <p role="alert">{L.n_fail}</p>;
  if (!state) return <p className="small">…</p>;
  const s = state, allOk = s.lines.every((l) => l.ok);
  return (
    <>
      <div>{s.lines.map((l) => (
        <div className="ci" key={l.v}>
          <div className="ph">{l.image && <img src={l.image} alt="" />}</div>
          <div>
            <a className="nm" href={`/${lang}/p/${l.slug}`}>{l.name}</a>
            {(l.size || l.color) && <div className="meta">{[l.size, l.color].filter(Boolean).join(' · ')}</div>}
            {!l.ok && <div className="err">{L.n_stock}</div>}
            <div className="row">
              <div className="qr"><button type="button" aria-label="−" onClick={() => l.q > 1 && setQty(l.v, l.q - 1)}>−</button><span className="lat">{l.q}</span><button type="button" aria-label="+" onClick={() => l.q < 50 && setQty(l.v, l.q + 1)}>+</button></div>
              <b className="lat">{fmtMoney(l.unit * l.q, s.sym)}</b>
              <button type="button" className="lnk" onClick={() => remove(l.v)}>{L.remove}</button>
            </div>
          </div>
        </div>))}</div>
      <dl className="dl sumr">
        <div><dt>{L.n_sub}</dt><dd className="lat">{fmtMoney(s.subtotal, s.sym)}</dd></div>
        <div><dt>{L.n_del}</dt><dd className="lat">{s.delivery > 0 ? fmtMoney(s.delivery, s.sym) : s.deliverySet ? L.n_free : L.n_del_tbc}</dd></div>
        <div><dt>{L.n_total}</dt><dd className="lat">{fmtMoney(s.total, s.sym)}</dd></div>
      </dl>
      <form className="cform" noValidate onSubmit={submit}>
        {FIELDS.map(([k, type, ac]) => (
          <label className="fld" htmlFor={`f-${k}`} key={k}><span>{L['n_' + (k === 'phone' ? 'phone' : k)]}</span>
            <input id={`f-${k}`} name={k} type={type} autoComplete={ac} maxLength={k === 'note' ? 500 : 300} dir={k === 'phone' || k === 'email' ? 'ltr' : undefined} inputMode={k === 'phone' ? 'tel' : undefined}
              ref={(el) => { refs.current[k] = el; }} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} aria-invalid={!!errs[k]} />
            <span className="ferr" role="alert">{errs[k] || ''}</span></label>))}
        {s.methods.length > 0 ? (
          <fieldset className="pays"><legend>{L.n_pay}</legend>{s.methods.map((m) => (
            <label className="pay" key={m.key}><input type="radio" name="payment" value={m.key} checked={pay === m.key} onChange={() => setPay(m.key)} />
              <span><b>{m.key === 'bank' ? L.n_bank : L.n_cod}</b>{m.instructions && <small>{m.instructions}</small>}</span></label>))}</fieldset>
        ) : <p className="small">{L.n_nopay}</p>}
        <p className="err" role="alert">{top}</p>
        <button type="submit" className="btn" disabled={!allOk || busy}>{L.n_place}</button>
      </form>
    </>
  );
}
