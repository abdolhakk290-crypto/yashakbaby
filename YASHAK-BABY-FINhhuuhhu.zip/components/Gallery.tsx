'use client';
import { useState } from 'react';
import { Placeholder } from './Placeholder';

export default function Gallery({ images, fallbackAlt }: { images: { src: string; alt: string }[]; fallbackAlt: string }) {
  const [n, setN] = useState(0), cur = images[n];
  if (!images.length) return <div className="gal"><div className="ph main" style={{ ['--tone' as string]: '#EAE2D6' }}><Placeholder /></div></div>;
  return (
    <div className="gal"><div className="ph main" id="gmain" style={{ ['--tone' as string]: '#EAE2D6' }}><img id="gimg" src={cur.src} alt={cur.alt || fallbackAlt} /></div>
      {images.length > 1 && <div className="thumbs">{images.map((im, i) => <button key={im.src} type="button" className="th" aria-label={String(i + 1)} aria-current={i === n} onClick={() => setN(i)}><img src={im.src} alt="" loading="lazy" /></button>)}</div>}</div>
  );
}
