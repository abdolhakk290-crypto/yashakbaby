'use client';
import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { LANGS } from '@/lib/i18n';
import { Icon } from './Icon';

export default function LangMenu({ lang, label }: { lang: string; label: string }) {
  const [open, setOpen] = useState(false); const ref = useRef<HTMLDivElement>(null); const path = usePathname() || '/';
  const rest = path.replace(/^\/[^/]+/, '') || '/';
  useEffect(() => {
    const click = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('click', click); document.addEventListener('keydown', key);
    return () => { document.removeEventListener('click', click); document.removeEventListener('keydown', key); };
  }, []);
  const cur = LANGS.find((l) => l.c === lang)!;
  return (
    <div className="lw" ref={ref}>
      <button className="ib lang-b" id="lbtn" type="button" aria-haspopup="true" aria-expanded={open} aria-controls="lmenu" aria-label={`${label}: ${cur.n}`} onClick={() => setOpen(!open)}>
        <Icon name="globe" /><span lang={lang} className={lang === 'zgh' ? 'tf' : ''}>{cur.s}</span>
      </button>
      <div className="lm" id="lmenu" hidden={!open}>
        {LANGS.map((l, i) => (
          <span key={l.c}>{i === 2 && <div className="sep" />}
            <a href={`/${l.c}${rest === '/' ? '' : rest}`} lang={l.c} hrefLang={l.c} className={`lopt ${l.c === 'zgh' ? 'tf' : ''}`} aria-current={l.c === lang}
               style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 44, padding: '0 12px', textDecoration: 'none', borderRadius: 4 }}
               onClick={() => { document.cookie = `yb_lang=${l.c};path=/;max-age=31536000;SameSite=Lax`; }}>{l.n}</a></span>
        ))}
      </div>
    </div>
  );
}
