'use client';
import { useEffect, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';

type L = { on: string; off: string; start: string; scan: string; code: string; verify: string; bad: string };
/** Enrol an authenticator app (TOTP) using Supabase Auth's own MFA calls. Everything secret stays between the browser and Supabase. */
export default function MfaSetup({ l }: { l: L }) {
  const [verified, setVerified] = useState<boolean | null>(null), [enr, setEnr] = useState<{ id: string; qr: string; secret: string } | null>(null), [code, setCode] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => { supabaseBrowser().auth.mfa.listFactors().then(({ data }) => setVerified(!!data?.totp?.length)).catch(() => setVerified(false)); }, []);
  async function start() {
    setMsg(''); setBusy(true);
    try {
      const { data, error } = await supabaseBrowser().auth.mfa.enroll({ factorType: 'totp', friendlyName: 'YASHAK admin ' + new Date().toISOString().slice(0, 10) });
      if (error || !data) throw new Error('enroll'); setEnr({ id: data.id, qr: data.totp.qr_code, secret: data.totp.secret });
    } catch { setMsg(l.bad); } finally { setBusy(false); }
  }
  async function verify(e: React.FormEvent) {
    e.preventDefault(); if (!enr) return; setMsg(''); setBusy(true);
    try { const { error } = await supabaseBrowser().auth.mfa.challengeAndVerify({ factorId: enr.id, code: code.trim() }); if (error) throw error; setEnr(null); setCode(''); setVerified(true); }
    catch { setMsg(l.bad); } finally { setBusy(false); }
  }
  return (<div>
    {verified !== null && <p className={verified ? 'a-ok' : 'a-er'} role="status">{verified ? l.on : l.off}</p>}
    {!verified && !enr && <button className="a-btn" onClick={start} disabled={busy}>{l.start}</button>}
    {enr && <form onSubmit={verify} className="a-grid" style={{ maxWidth: 360 }}>
      <p>{l.scan}</p><img src={enr.qr} alt="QR" width={200} height={200} style={{ background: '#fff', padding: 8, borderRadius: 8 }} /><code className="lat" style={{ wordBreak: 'break-all' }}>{enr.secret}</code>
      <label className="a-f"><span>{l.code}</span><input inputMode="numeric" autoComplete="one-time-code" maxLength={6} pattern="[0-9]{6}" required value={code} onChange={(e) => setCode(e.target.value)} dir="ltr" /></label>
      <button className="a-btn" disabled={busy}>{l.verify}</button></form>}
    {msg && <p className="a-er" role="alert">{msg}</p>}
  </div>);
}
