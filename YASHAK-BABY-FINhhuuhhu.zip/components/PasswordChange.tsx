'use client';
import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase-browser';
type L = { n: string; again: string; save: string; ok: string; short: string; diff: string; fail: string };
/** Changes the signed-in admin's password through Supabase Auth itself. The password is never stored by this website or in the admins table. */
export default function PasswordChange({ l }: { l: L }) {
  const [a, setA] = useState(''), [b, setB] = useState(''), [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null), [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setMsg(null);
    if (a.length < 10) return setMsg({ ok: false, t: l.short }); if (a !== b) return setMsg({ ok: false, t: l.diff });
    setBusy(true);
    try { const { error } = await supabaseBrowser().auth.updateUser({ password: a }); if (error) throw error; setA(''); setB(''); setMsg({ ok: true, t: l.ok }); }
    catch { setMsg({ ok: false, t: l.fail }); } finally { setBusy(false); }
  }
  return (<form onSubmit={go} className="a-grid" style={{ maxWidth: 360 }} autoComplete="off">
    <label className="a-f"><span>{l.n}</span><input type="password" name="new_password" autoComplete="new-password" minLength={10} required value={a} onChange={(e) => setA(e.target.value)} /></label>
    <label className="a-f"><span>{l.again}</span><input type="password" name="new_password2" autoComplete="new-password" minLength={10} required value={b} onChange={(e) => setB(e.target.value)} /></label>
    <button className="a-btn" disabled={busy}>{l.save}</button>
    {msg && <p className={msg.ok ? 'a-ok' : 'a-er'} role={msg.ok ? 'status' : 'alert'}>{msg.t}</p>}</form>);
}
