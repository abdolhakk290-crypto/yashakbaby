export function Placeholder() {
  return <svg viewBox="0 0 100 100" aria-hidden="true"><path d="M34 40V30a16 16 0 0 1 32 0v10" fill="none" stroke="#B9A98C" strokeWidth="3" strokeLinecap="round" /><path d="M18 40h64l4 48H14z" fill="#E7D9C3" stroke="#CDBB9C" strokeWidth="2" /></svg>;
}
