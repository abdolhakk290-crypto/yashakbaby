'use client';
import { useMemo, useState } from 'react';
import { loadCart, saveCart, toast } from '@/lib/cart-client';
import { fmtMoney, waLink, waProductMessage, type WaLabels } from '@/lib/format';
import { Icon } from './Icon';

type V = { id: number; sku: string | null; size: string | null; color: string | null; price_cents: number; in_stock: boolean };
export type BuyProps = {
  name: string; sku: string | null; baseCents: number; oldCents: number | null; available: boolean; variants: V[]; sym: string; url: string;
  wa: { enabled: boolean; number: string; template: string; labels: WaLabels };
  i: { opts: string; out: string; added: string; unavail: string; inn: string; color: string; size: string; qty: string; add: string; wa: string };
};

export default function ProductBuy(p: BuyProps) {
  const sizes = useMemo(() => [...new Set(p.variants.map((v) => v.size).filter(Boolean) as string[])], [p.variants]);
  const colors = useMemo(() => [...new Set(p.variants.map((v) => v.color).filter(Boolean) as string[])], [p.variants]);
  const [size, setSize] = useState<string | null>(null), [color, setColor] = useState<string | null>(null), [qty, setQty] = useState(1), [err, setErr] = useState('');
  const only = p.variants.length === 1 && !sizes.length && !colors.length ? p.variants[0] : null;
  const match = only || p.variants.find((v) => (!sizes.length || v.size === size) && (!colors.length || v.color === color)) || null;
  const need = (sizes.length > 0 && !size) || (colors.length > 0 && !color);
  const optionAvail = (s: string | null, c: string | null) => p.variants.some((v) => (s == null || v.size === s) && (c == null || v.color === c) && v.in_stock);
  const price = match && !need ? match.price_cents : p.baseCents;
  const out = p.available && !need && (!match || !match.in_stock);
  const canAdd = p.available && !out;
  const status = !p.available ? p.i.unavail : out ? p.i.out : !need && match ? p.i.inn : '';
  const msg = p.wa.enabled ? waProductMessage({ template: p.wa.template, labels: p.wa.labels, name: p.name, priceCents: price, sym: p.sym, sku: match?.sku || p.sku, size, color, qty, url: p.url }) : '';
  const add = () => {
    if (!match || need) { setErr(p.i.opts); return; }
    if (!match.in_stock) { setErr(p.i.out); return; }
    const c = loadCart(), ex = c.find((x) => x.v === match.id);
    if (ex) ex.q = Math.min(50, ex.q + qty); else c.push({ v: match.id, q: qty });
    saveCart(c); setErr(''); toast(p.i.added);
  };
  return (
    <>
      <div className="price" id="pprice"><bdi className="lat">{fmtMoney(price, p.sym)}</bdi>{p.oldCents != null && !need && price === p.baseCents && <> <s className="small"><bdi className="lat">{fmtMoney(p.oldCents, p.sym)}</bdi></s></>}</div>
      <p className={out || !p.available ? 'err' : 'ok'} id="pstock">{status}</p>
      {colors.length > 0 && <><div className="lab">{p.i.color}</div><div className="chips" id="cols" role="group">{colors.map((x) => (
        <button key={x} type="button" className="chip" aria-pressed={color === x} aria-disabled={!optionAvail(sizes.length ? size : null, x)} onClick={() => { if (optionAvail(sizes.length ? size : null, x)) { setColor(color === x ? null : x); setErr(''); } }}>{x}</button>))}</div></>}
      {sizes.length > 0 && <><div className="lab">{p.i.size}</div><div className="chips" id="szs" role="group">{sizes.map((x) => (
        <button key={x} type="button" className="chip" aria-pressed={size === x} aria-disabled={!optionAvail(x, colors.length ? color : null)} onClick={() => { if (optionAvail(x, colors.length ? color : null)) { setSize(size === x ? null : x); setErr(''); } }}>{x}</button>))}</div></>}
      <div className="lab">{p.i.qty}</div>
      <div className="qr"><button type="button" aria-label="−" onClick={() => setQty(Math.max(1, qty - 1))}><Icon name="minus" /></button><span id="qv" className="lat">{qty}</span><button type="button" aria-label="+" onClick={() => setQty(Math.min(20, qty + 1))}><Icon name="plus" /></button></div>
      <p className="err" id="err" role="alert">{err}</p>
      <div className="buyrow">
        <button className="btn" type="button" id="addb" disabled={!canAdd} onClick={add}>{p.i.add}</button>
        {p.wa.enabled && <a className="btn sec2" id="wab" href={waLink(p.wa.number, msg)} target="_blank" rel="noopener noreferrer"><Icon name="wa" /> {p.i.wa}</a>}
      </div>
    </>
  );
}
