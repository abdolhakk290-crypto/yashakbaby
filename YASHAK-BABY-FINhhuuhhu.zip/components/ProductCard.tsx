import type { Card } from '@/lib/store';
import { imgUrl } from '@/lib/store';
import { fmtMoney } from '@/lib/format';
import { Placeholder } from './Placeholder';

export default function ProductCard({ p, lang, t, sym }: { p: Card; lang: string; t: (k: string) => string; sym: string }) {
  const img = imgUrl(p.image), sale = p.old_cents != null;
  const tag = !p.in_stock ? t(p.available ? 'n_out' : 'n_unavail') : sale ? t('n_sale') : '';
  return (
    <a className="card" href={`/${lang}/p/${p.slug}`}>
      <div className="ph sq" style={{ ['--tone' as string]: '#EAE2D6' }}>{img ? <img src={img} alt={p.image_alt || p.name} loading="lazy" /> : <Placeholder />}{tag && <span className="tag">{tag}</span>}</div>
      <h3>{p.name}</h3>
      <div className="pr"><bdi className="lat">{fmtMoney(p.price_cents, sym)}</bdi>{sale && <> <s className="small"><bdi className="lat">{fmtMoney(p.old_cents!, sym)}</bdi></s></>}</div>
    </a>
  );
}
