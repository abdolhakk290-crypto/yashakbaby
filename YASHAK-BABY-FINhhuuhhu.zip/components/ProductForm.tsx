import { makeT, L6, type ALang } from '@/lib/admin-i18n';
import { fromCents, pick } from '@/lib/admin';
import { saveProduct } from '@/app/admin/(protected)/actions';

export type AdminProduct = { id: number; slug: string; name: Record<string, string>; description: Record<string, string> | null; specs: Record<string, string> | null; price_cents: number; sale_price_cents: number | null; sku: string | null; status: string; available: boolean; featured: boolean; track_stock: boolean; category_id: number | null; variants: { id: number; size: string | null; color: string | null; stock: number; active: boolean }[] };

export function ProductForm({ product: p, cats, lang }: { product: AdminProduct | null; cats: { id: number; name: Record<string, string> }[]; lang: ALang }) {
  const t = makeT(lang), vs = p ? p.variants : [], blank = Math.max(3, 6 - vs.length), rows = [...vs.map((v) => ({ ...v })), ...Array.from({ length: p && vs.length ? 3 : blank }, () => null)];
  const open = (l: string) => l === lang || l === 'fr' || !!(p?.name?.[l] || p?.description?.[l]);
  return (
    <form action={saveProduct} className="a-card" autoComplete="off">
      {p && <input type="hidden" name="id" value={p.id} />}
      <h2>{t('lang_fields')}</h2><p className="a-sub" style={{ marginBottom: 8 }}>{t('lang_fields_hint')}</p>
      {L6.map((l) => (
        <details className="a-lang" key={l.c} open={open(l.c)} lang={l.c === 'zgh' ? 'zgh' : l.c} dir={l.c === 'ar' || l.c === 'ary' ? 'rtl' : 'ltr'}>
          <summary>{l.n}</summary>
          <div>
            <label className="a-f"><span>{t('f_name')} ({l.n})</span><input name={`name_${l.c}`} maxLength={200} defaultValue={p?.name?.[l.c] || ''} /></label>
            <label className="a-f"><span>{t('f_desc')} ({l.n})</span><textarea name={`desc_${l.c}`} maxLength={5000} defaultValue={p?.description?.[l.c] || ''} /></label>
            <label className="a-f"><span>{t('f_specs')} ({l.n})</span><textarea name={`specs_${l.c}`} maxLength={2000} defaultValue={p?.specs?.[l.c] || ''} style={{ minHeight: 60 }} /></label>
          </div></details>))}
      <div className="a-grid a-g2" style={{ marginTop: 16 }}>
        <label className="a-f"><span>{t('f_price')} (DH)</span><input name="price" inputMode="decimal" required pattern="[0-9]+([.,][0-9]{1,2})?" defaultValue={fromCents(p?.price_cents)} placeholder="150" /></label>
        <label className="a-f"><span>{t('f_sale')} (DH)</span><input name="sale" inputMode="decimal" pattern="([0-9]+([.,][0-9]{1,2})?)?" defaultValue={fromCents(p?.sale_price_cents)} /><small>{t('f_sale_hint')}</small></label>
        <label className="a-f"><span>{t('f_cat')}</span><select name="category" defaultValue={p?.category_id ?? ''}><option value="">{t('f_nocat')}</option>{cats.map((c) => <option key={c.id} value={c.id}>{pick(c.name, lang)}</option>)}</select></label>
        <label className="a-f"><span>{t('f_sku')}</span><input name="sku" maxLength={60} defaultValue={p?.sku || ''} /></label>
        <label className="a-f"><span>{t('f_status')}</span><select name="status" defaultValue={p?.status || 'draft'}><option value="draft">{t('st_draft')}</option><option value="published">{t('st_published')}</option><option value="archived">{t('st_archived')}</option></select></label>
        {p && <label className="a-f"><span>URL</span><input name="slug" className="lat" maxLength={80} defaultValue={p.slug} pattern="[a-z0-9]+(-[a-z0-9]+)*" dir="ltr" /></label>}
      </div>
      <label className="a-chk"><input type="checkbox" name="available" defaultChecked={p ? p.available : true} /> {t('available')}</label>
      <label className="a-chk"><input type="checkbox" name="featured" defaultChecked={p?.featured} /> {t('featured')}</label>
      <label className="a-chk"><input type="checkbox" name="track_stock" defaultChecked={p ? p.track_stock : true} /> {t('track_stock')}</label>
      <h2 style={{ marginTop: 20 }}>{t('sizes_colors')}</h2><p className="a-sub" style={{ marginBottom: 8 }}>{t('sizes_hint')}</p>
      <input type="hidden" name="vn" value={rows.length} />
      {rows.map((v, i) => (
        <div className="a-vrow" key={i}>
          {v && <input type="hidden" name={`v${i}_id`} value={v.id} />}
          <label>{t('f_size')}<input type="text" name={`v${i}_size`} maxLength={40} defaultValue={v?.size || ''} /></label>
          <label>{t('f_color')}<input type="text" name={`v${i}_color`} maxLength={40} defaultValue={v?.color || ''} /></label>
          <label>{t('f_stock')}<input type="text" inputMode="numeric" pattern="[0-9]*" name={`v${i}_stock`} defaultValue={v ? String(v.stock) : ''} /></label>
          <label className="a-chk"><input type="checkbox" name={`v${i}_active`} defaultChecked={v ? v.active : true} /> {t('f_active')}</label>
          {v && <label className="a-chk"><input type="checkbox" name={`v${i}_rm`} /> {t('f_remove')}</label>}
        </div>))}
      <div className="a-sticky"><button className="a-btn">{t('save')}</button><a className="a-btn2" href="/admin/products">{t('cancel')}</a></div>
    </form>
  );
}
