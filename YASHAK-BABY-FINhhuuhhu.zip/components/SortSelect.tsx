'use client';
import { useRouter, usePathname, useSearchParams } from 'next/navigation';

export default function SortSelect({ label, options, value }: { label: string; options: [string, string][]; value: string }) {
  const r = useRouter(), path = usePathname(), sp = useSearchParams();
  return (
    <label className="small">{label} <select className="sel" value={value} onChange={(e) => { const q = new URLSearchParams(sp.toString()); if (e.target.value) q.set('sort', e.target.value); else q.delete('sort'); r.push(`${path}${q.toString() ? '?' + q : ''}`); }}>
      {options.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></label>
  );
}
