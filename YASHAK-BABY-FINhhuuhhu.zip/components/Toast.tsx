'use client';
import { useEffect, useRef, useState } from 'react';

export default function Toast() {
  const [m, setM] = useState(''); const h = useRef<ReturnType<typeof setTimeout>>(undefined);
  useEffect(() => { const f = (e: Event) => { setM(String((e as CustomEvent).detail || '')); clearTimeout(h.current); h.current = setTimeout(() => setM(''), 2600); }; window.addEventListener('yb-toast', f); return () => window.removeEventListener('yb-toast', f); }, []);
  return <div className="toast" id="toast" role="status" hidden={!m}>{m}</div>;
}
