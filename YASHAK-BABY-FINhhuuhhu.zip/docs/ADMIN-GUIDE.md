# Admin guide (simple language)

Open **/admin** on your website and sign in. Every change you save appears on the public site immediately.
The top bar has: the language of the dashboard (6 languages; Amazigh shows French for now), "View website", your email and **Sign out**.

## Products
- **Add**: Products → "+ New product". Write the name (at least one language; empty languages use the website default), price in DH, pick a category, choose *Draft* (hidden) or *Published* (visible). Save, then add photos.
- **Sizes and colours**: fill the rows (size, colour, stock). Leave empty if the product has one version (use the first row only for its stock). Tick "Remove" to delete a size. **Only you see the exact stock**; visitors see "in stock / out of stock".
- **Sale price**: optional, must be lower than the price.
- **Photos**: choose one or several images (JPG, PNG, WebP or GIF, 8 MB max, 12 per product). The first photo is the main one: use "Make main", the arrows to reorder, "Replace" or "Delete" (asks to confirm).
- **Publish / Unpublish**, **Mark unavailable** (shows "unavailable" and blocks adding to cart), **★ Featured** (shown on the homepage): buttons in the product list.
- **Order on the website**: arrows ↑ ↓ in the product list (when no search/filter is active). First = first on the site.
- **Delete**: opens a confirmation. It also deletes the photos. To only hide a product, use Unpublish.

## Categories
Add, rename (all six languages), hide, reorder, change the picture. **A category with products cannot be deleted until you choose where to move them** — nothing is lost by accident.

## Homepage
Main banner text, promotional banners (title, text, picture, link to a category). Featured products are chosen with ★ in the product list.

## Settings
- **Contact**: shop name, email, phone, address, website address.
- **WhatsApp**: your number in international format **without + or 0** (e.g. 212601668146), on/off, where the button shows, and the pre-written message per language (write `{details}` where the product name, price, size, colour and link should go). Every product page uses it at once; no code change needed.
- **Social links**.
- **Returns policy (24 h)**: stays OFF (the site says "being finalised") until the rules are checked against Moroccan consumer law. Switch it on only after that review.

## Orders
A simple list of requests sent through the website form (most customers will use WhatsApp). Open one to see customer and items, and set its status.

## Good habits
Sign out on shared computers. Back up your data regularly (free Supabase has no automatic backups). Never send the service key to anyone.
