# Admin login fix

**Flow now:** `/admin/login` → Supabase Auth email+password → (6-digit code if two-step verification is set up) → the page asks the database `is_admin()` (reads `public.admins`: columns `user_id`, `role`, `created_at`; no passwords are stored there) → success: `/admin/dashboard`; not an admin: the session is closed and "Access denied…" is shown; wrong credentials: "Incorrect email or password."
**Server side:** proxy (no session → login), `(protected)/layout.tsx` and every action/upload re-check `currentAdmin()`; every `admin_*` database function re-checks `is_admin()`. RLS unchanged.
**Most common real-world cause of "login does not work":** the Auth user exists but has no row in `public.admins` (e.g. `make-owner.sql` printed `INSERT 0 0` because the email differed). Run `supabase/check-admin.sql` (read-only) to see.
