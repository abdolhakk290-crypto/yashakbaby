# Audit of the earlier Node + SQLite version, and what is genuinely reusable

Location audited: `yashak-store/` (about 2,400 dense lines; its own tests: 102 API + 44 browser, all passing, project left untouched).

| Part | Reusable? | How it was used in Phase 1 |
|---|---|---|
| `public/css/store.css` (design: colors, type, layout, RTL, dark mode, mobile) | **Yes, as is** | Copied to `app/styles/store.css` with self-hosted `@font-face`. Side-by-side screenshots (mobile + desktop, light + dark, French + Darija) show the same layout. |
| Logos, photos, fonts | **Yes, as is** | `public/img/…`, `app/styles/fonts/` (no Google Fonts requests) |
| `lib/defaults.json` (UI texts ×6 languages, 6 information pages ×6, business info) | **Yes, as is** | `content/defaults.json`; `lib/i18n.ts` serves them; admin overrides go in the `translations` / `pages` tables |
| `lib/db.js` settings defaults | **Yes (data)** | Exported to `supabase/seed.sql` (settings + 3 empty categories; no products, no invented data) |
| `lib/orders.js` (cart pricing, validation, stock reservation, status rules) | **Logic yes, code no** | Re-implemented as PostgreSQL functions (`place_order`, `set_order_status`, `adjust_stock`…) with identical rules, now enforced inside the database transaction |
| `lib/catalog.js`, `routes/store.js`, `lib/view.js` (server-rendered pages) | **Markup yes, code no** | Header/nav/footer/home ported to React components with the same class names. Remaining pages are ported in Phase 2 |
| `routes/api-admin.js`, `admin/*.js` (admin API + UI) | **Behaviour/UX yes, code no** | Rewritten as Next.js server code + React in Phase 3. The admin screens and their workflow are the specification |
| `lib/auth.js` (own password hashing, sessions, TOTP, CSRF, rate limiter) | **No** | Replaced by Supabase Auth (passwords, sessions, MFA) + database rate limiter. Writing our own auth on Supabase would be less safe |
| SQLite file storage, `/uploads` folder | **No** | Replaced by PostgreSQL and Supabase Storage |
| `tests/api.js`, `tests/ui.js` (146 checks) | **Specification yes** | Kept untouched. Every check is mapped to the new stack in `docs/TEST-TRACEABILITY.md` |

Not reusable and not needed any more: Express server, better-sqlite3, multer, hand-made session table.
