# Go-live checklist (NOT started — needs your decisions and accounts)

1. Decide plans: Supabase Pro (daily backups) and Vercel Pro (the free plan is non-commercial only). Nothing has been purchased.
2. Create the Supabase project; run `supabase/migrations/*` in order, then `supabase/seed.sql`.
3. Create your own login in Authentication → Users, run `supabase/make-owner.sql` with your email, sign in and enrol two-step verification on the dashboard's **Security** page. Turn OFF public sign-ups. (See `docs/SUPABASE-SETUP.md`.)
4. Put the keys in Vercel environment variables (`.env.example` lists them). Never commit them.
5. Connect the repository to Vercel; add `yashakbaby.online`; set `NEXT_PUBLIC_SITE_URL`.
6. On the live project, re-run the checks that cannot run locally: Supabase Auth login/MFA/sessions, real Storage uploads (reject SVG/PHP), RLS via the REST API with the anon key, backups enabled.
7. Enter real data in the dashboard: products, photos, prices, stock, bank details, delivery fee, WhatsApp number.
8. Legal review of the 24-hour return text and privacy/terms; native review of Amazigh and Darija.

9. Phase 3 live checks (docs/SUPABASE-SETUP.md §6): real sign-in/out, MFA enrolment and enforcement, real photo upload/delete in Storage, anon key cannot read stock or call admin functions.
10. Decide the free-plan limits: Supabase Free has no automatic backups and pauses after a week of inactivity; Vercel Hobby is for non-commercial use only (your decision, not made).
