# Phase 1 report

## Completed
- Audit of the Node + SQLite version and reuse decisions (`AUDIT-NODE-SQLITE.md`).
- Next.js 16 project (TypeScript, App Router): design CSS, logos, photos and fonts copied unchanged; six languages with RTL (Darija, Arabic); header, category nav, footer, language menu, home page; security headers/CSP; robots; `/admin` gated on the server by Supabase session **and** the `admins` table; admin login page with two-step verification step (written, not yet runnable without Supabase).
- PostgreSQL schema for the whole store, six migrations, seed without any invented data.
- Row Level Security, column/function permissions, validation triggers, audit log, automatic stock log, atomic order placement, stock rules, rate limiter, Storage bucket policies.
- Backup `yashak-BACKUP-v7-before-nextjs.zip` untouched (SHA-256 verified after all work; made read-only).

## Test results
| Suite | Result |
|---|---|
| New PostgreSQL suite (RLS, permissions, orders/stock, concurrency, payments, settings, storage policies) | **69 passed, 0 failed** |
| Mutation check (6 deliberate security breakages) | all 6 detected |
| Legacy suites on the old Node version (102 API + 44 browser) | 146/146 still pass (re-run at the start of Phase 1) |
| 146-test traceability | 62 covered by passing new tests, 11 database-half verified, 73 pending with a named phase and reason, **0 dropped** |
| `tsc --noEmit`, `next build` | pass |
| Visual parity (mobile + desktop, light + dark, French + Darija) | same layout; only text rendering differs because the real DM Sans now loads |

## Remaining problems / limits (honest list)
1. **Not tested against real Supabase.** Tests run on real PostgreSQL 16 with a stand-in for Supabase's `auth`/`storage` schemas. Supabase Auth (login, sessions, MFA) and the Storage service (real uploads, content-type checks, magic-byte checks) are untested until a real project exists.
2. 73 legacy checks are pending: HTTP/Next.js behaviour (Phase 2), admin UI (Phase 3), auth (Phase 2 integration), backups (go-live).
3. MFA is checked in the login flow but not enforced by the database (`is_admin()` ignores the `aal` claim) so the first owner can enrol; to enforce it after enrolment.
4. The storefront shell still uses built-in default texts and static home content; products, categories, settings, WhatsApp button and cart come from the database in Phase 2 (so the home page currently has no WhatsApp button; the old version shows it).
5. CSP allows inline scripts (Next bootstrap); to tighten with nonces in Phase 2.
6. `robots.txt` points to `/sitemap.xml`, which is built in Phase 2.
7. Amazigh texts are machine-drafted; the 24-hour returns text needs legal review (unchanged from before).
8. Anyone can see exact stock numbers of published products (needed for "only 3 left"); can be reduced to an in-stock flag if preferred.

## Next steps (Phase 2, needs your approval)
Data layer for the storefront from Supabase; product, category, cart, checkout (`place_order` through a rate-limited server route), WhatsApp inquiry button, search, pages, sitemap; port the pending HTTP tests; try a local Supabase stack if tooling allows.
