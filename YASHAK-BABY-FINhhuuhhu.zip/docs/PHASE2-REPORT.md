# Phase 2 report (local only)

Everything below was run in this session; numbers are from the final runs.

## Test results
| Suite | Result |
|---|---|
| Database (RLS, permissions, orders, stock, concurrency, storefront functions, stock privacy) | **84 passed, 0 failed** (was 69 in Phase 1) |
| Web layer on the real production build (pages, languages, sitemap, SEO, CSP nonce, origin checks, cart, orders, validation, rate limit, legal hold, WhatsApp, 12 parallel orders) | **32 passed, 0 failed** |
| Browser, real Chromium, phone + desktop (options, quantity, WhatsApp message, cart, checkout, order, RTL, dark mode, overflow in 6 languages, keyboard, console errors) | **16 passed, 0 failed** |
| Old Node version, untouched | API 102/102, UI 44/44 |
| 146-test traceability | **95 covered, 4 partly (database half), 47 pending, 0 dropped** (Phase 1: 62 / 11 / 73) |
| Mutation check on stock privacy | granting `stock` to anonymous visitors makes a test fail (detected) |
| `tsc --noEmit`, `next build` | pass |

Tests changed (not weakened): `get_cart` test used to assert an exact `avail` count — now asserts the count is absent and `in_stock` is true (your decision: customers see only in/out of stock). The admin "direct stock edit is logged" test now writes a literal value, because admins (like everyone) can no longer read the stock column directly; they use `adjust_stock` / `admin_variants`. Both are recorded in the test source. The old "wrong CSRF token" check is covered by the new origin + JSON protection (the public site has no session token).

## Real problems found by the new tests and fixed
- Cart badge showed "0" after an order (the `hidden` attribute lost to the stylesheet) — fixed with one CSS rule.
- A NUL character in a name made PostgreSQL refuse the order (HTTP 500) — control characters are now stripped.
- Sitemap/canonical addresses were frozen at build time — now read at run time (`SITE_URL` or the owner's setting).
- Client code was importing server-only code (build error) — split.
- `/admin/login` was pre-rendered, so strict-nonce scripts would have been blocked — now rendered per request.

## Not verified / limits (honest)
1. Still no real Supabase: the same SQL functions are called straight on PostgreSQL in tests (`YB_LOCAL_PG_URL`). The code path through `supabase-js` `.rpc()` (production) is a few lines but has **not been run**.
2. Admin login/2FA, real image upload/serve, backups: pending (Phase 3/5).
3. Test products in `tests/fixtures.sql` are fake and only exist in the test databases. **The real store has no products yet**; the storefront shows the "coming soon" empty states until you add products (Phase 3 dashboard).
4. Payment methods are both OFF in the seed. With none enabled the checkout takes the order and says "we will contact you to confirm and agree payment". Turn on Cash on Delivery / bank transfer once you decide (bank details are not invented).
5. Delivery fee is 0 = "confirmed before shipping" until you set it.
6. Pages are rendered on every request (always-fresh prices/stock); caching is a later optimisation.
7. Amazigh texts still machine-drafted; the returns-hold sentence is shown in French on the Amazigh site.
8. Rate limiting trusts `x-forwarded-for` as set by Vercel; locally it can be spoofed.
9. A visitor can still probe quantity by raising it in the cart (see SECURITY-MODEL).
10. Returns policy is **not published** (legal hold) — the 24-hour rule is stored unchanged.
