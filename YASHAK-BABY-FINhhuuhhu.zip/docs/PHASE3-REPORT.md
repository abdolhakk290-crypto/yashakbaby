# Phase 3 report — Admin dashboard (local only)

Nothing was deployed, no domain was connected, nothing was purchased. The backup zip is untouched (SHA-256 `c289a8e4…f334d` verified at the end).

## What was built (all inside the existing Next.js + Supabase project; no new tables for products, categories, photos or settings — one new column `products.sort`)
| Area | What you can do | Where |
|---|---|---|
| Access | Private `/admin`, real Supabase sign-in, sign-out, only users listed in `admins`; two-step verification enforced when enrolled; enrolment screen | `/admin/login`, `/admin/security` |
| Products | Add, edit, delete (confirmation), publish/unpublish, available/unavailable, featured ★, duplicate, search/filter, order with ↑↓, name/description/details in 6 languages, price, sale price, category, sizes + colours + private stock | `/admin/products` |
| Photos | Upload several, replace, remove (confirmation), choose main, reorder; stored in Supabase Storage, shown on the public pages; files deleted from Storage when removed | product edit page, `/api/admin/upload` |
| Categories | Add, rename (6 languages), hide, reorder, picture, **safe delete** (must move products first) | `/admin/categories` |
| Homepage | Main banner text + image, promotional banners (text, image, link to category) | `/admin/content` |
| Settings | Shop contact details, WhatsApp number + on/off + where shown + pre-written message in 6 languages, social links, returns-policy switch (stays OFF) | `/admin/settings` |
| WhatsApp | Product page button opens `wa.me/<number from settings>` with the message (product name, price, reference, size, colour, quantity, link) — number/message editable in the dashboard | public product page |
| Orders | Minimal: list, detail, change status (no exports, notes, invoices) | `/admin/orders` |
| Languages | Dashboard in French, English, Spanish, Arabic, Darija (RTL). Amazigh shows French for now | top bar |

Not built, on purpose (as you asked): online payments, complex checkout, order-management platform.

## Test results (actual, final run)
| Suite | Result |
|---|---|
| Database (real PostgreSQL 16): permissions, RLS, admin functions, validation, MFA enforcement, stock/orders/concurrency | **98 passed, 0 failed** |
| Web (production build + real PostgREST): storefront, API, cart, orders, security headers | **32 passed** |
| Storefront in a real browser (Chromium) | **16 passed** |
| **Admin in a real browser (Chromium)** | **39 passed** |
| TypeScript + production build | no errors |
| 146 legacy tests | old Node suites still pass (102 + 44); on the new stack **113 mapped to passing tests**, 33 still listed as pending with reasons (2 with their database part verified) — none unaccounted. See `docs/TEST-TRACEABILITY.md` |
| Mutation checks | making `_require_admin()` a no-op, or granting an admin function to `anon`, is caught by the tests |

What the 39 admin tests cover: anonymous visitors redirected from every admin page and refused on actions/upload; wrong password; a signed-in **non-admin** customer refused everywhere; login/logout; creating, editing, pricing (sale price), publishing/unpublishing, availability, sizes/colours, duplicating, deleting with confirmation — each checked on the **public website**; stock never in public pages; photo upload/main/replace/remove with real image decoding in the browser and stored files checked; unsafe uploads (SVG, text, fake PNG, 9 MB) refused; hostile file names; Storage policy (customer/traversal/other folder/SVG name refused); product order; categories incl. safe delete; homepage text/image; WhatsApp number normalisation, message contents, disable/enable; contact details; all six languages and RTL; phone-width overflow (French and Arabic); orders; no secrets in browser files; cross-site writes refused.

## What is NOT tested / remains incomplete (please read)
1. **Real Supabase Auth** (sign-in, sessions) and the **real Storage service** were not available: my tests use a small emulation of both (clearly labelled in the test code). Database rules, REST layer (real PostgREST) and storage *policies* are real. Must be checked on your Supabase project — checklist in `docs/SUPABASE-SETUP.md` §6.
2. **Two-step verification enrolment screen** (`/admin/security`) is built but **untested** (needs real Auth). The database/server enforcement of two-step verification is tested with simulated sessions. `is_admin()` reads Supabase's `auth.mfa_factors`; if the real project refuses that read, admin access fails closed (safe) and I will adjust.
3. Amazigh is not translated in the dashboard (French fallback); the Amazigh public texts remain machine-drafted and need native review.
4. Homepage "banner order" arrows and a live-preview are not included (banners keep their saved order; remove/add works).
5. Orders are deliberately minimal (no notes/exports/stock restock screen). The restock option is wired in the database function but not shown in the screen.
6. If a form has an error you must re-enter it (the page shows what is wrong); no draft auto-save.
7. The 24-hour returns policy remains hidden ("being finalised") until you switch it on after legal review.
8. Free-plan limits (decision for you): Supabase Free has no automatic backups and pauses after a week of inactivity; Vercel Hobby is non-commercial only. Nothing was bought.

## Required external setup
See `docs/SUPABASE-SETUP.md` (project, run 8 migrations + seed, bucket check, create your user, make-owner, MFA, env vars, disable public sign-ups, live checks).

## Next steps (after your approval)
Run the live checks on your Supabase project; native review of texts; legal review of returns; then deployment decisions (hosting plan, domain) — not started.
