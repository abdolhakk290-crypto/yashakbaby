# Security model (Phase 1)

**Principle: the database is the last line of defence.** Even if the website code had a bug, Row Level Security (RLS) and permissions in PostgreSQL still decide who can read or write what.

| Who | Can | Cannot |
|---|---|---|
| Public visitor (`anon`) | read published products, active variants/images, categories, translations, pages, public settings; price a cart (`get_cart`) | read orders, customers, bank details, drafts, audit/stock logs; write anything; list or change files |
| Logged-in customer | same as visitor | everything admin-only (being logged in is not enough) |
| Admin (row in `admins`) | manage catalogue, content, settings, orders (status only via `set_order_status`), stock, notes, customers | delete orders/customers/logs, change order totals or numbers, enable online payment, manage other admins |
| Owner | all admin rights + add/remove admins | — |
| Server code with the **service key** | place orders (`place_order`), rate limiting | — (key lives only in server environment variables; `import 'server-only'` stops it reaching the browser) |

Key mechanisms (all covered by tests in `tests/db.test.mjs`):
- Default-deny: `revoke all` then explicit grants per table/column; RLS on every table.
- Orders can only be created by `place_order`, which validates input, prices from the database, locks rows, checks stock and writes everything in one transaction (12 parallel orders for 1 unit: exactly 1 succeeds).
- Stock can never be negative (constraint) and every change is logged automatically.
- Settings are validated in the database: WhatsApp number format, store email, currency, links must be `https://` or `/` (no `javascript:`), bank transfer needs holder + IBAN, **online payment cannot be enabled**.
- Storage bucket: public read of files by URL only; listing/uploading/changing/deleting only for admins; only `products/` and `site/` folders; only image extensions; 8 MB; allowed MIME types set on the bucket.
- All `SECURITY DEFINER` functions pin `search_path`; the exact list of who may execute each function is asserted by a test.
- Audit log of admin changes; admins cannot edit or delete it.
- Mutation check: six deliberate security breakages were each detected by the tests.

Known gaps (see report): MFA is not yet enforced at the database level; Storage service behaviour (real uploads, MIME sniffing) and Supabase Auth are verified only on the live project.

## Phase 2 additions
- **Exact stock is private.** `variants.stock` can no longer be read by `anon` or any logged-in non-admin user (column privileges). Admins read it only through the `admin_variants` view. Every storefront function returns only `in_stock` true/false. A 409 order conflict reports in-stock yes/no, never a number. Tested by key-name scan, by direct `select stock` attempts, and by a mutation check (granting the column back makes the tests fail).
  Limit: a determined visitor could still discover a quantity by trying larger and larger amounts in the cart (the cart says "not enough"). Quantities per line are capped at 50.
- **Storefront = SQL functions** (`store_site`, `store_catalog`, `store_product`, `store_page`, `store_sitemap`, `store_checkout`, `get_cart`): `SECURITY DEFINER`, pinned `search_path`, executable by `anon`; they never return drafts, hidden variants, private settings or bank details.
- **Orders** go through `/api/orders` (server) → `place_order` with the secret key. The route forwards only known text fields (control characters stripped), ignores any price/total/status sent by the browser, requires a same-site `Origin` (or `Sec-Fetch-Site: same-origin`) and `application/json`, limits body size (50 KB) and rate-limits per address through the database counter.
- **Script security**: `proxy.ts` sets a new random nonce per request; the CSP has `script-src 'self' 'nonce-…' 'strict-dynamic'`, no `unsafe-inline`, no `unsafe-eval`. Every executable script carries the nonce (tested). Styles still allow inline `style=""` attributes (image tones).
- **Legal hold**: `settings.legal.returns_published` (default `false`) hides the return window (returns page, FAQ answer, delivery sentence, home card). The owner flips it in the admin after legal review (Phase 3). The 24-hour rule text is unchanged in the stored content.

## Phase 3 additions (admin dashboard)
- **Three layers on every admin request.** (1) `proxy.ts` sends visitors without a verified session to the login page; (2) every admin page, server action and the upload route calls `needAdmin()` / `currentAdmin()` on the server (verifies the token with Supabase Auth, checks the `admins` table, and that two-step verification is complete when enrolled); (3) every `admin_*` database function calls `_require_admin()` itself, so even a bug in the website cannot let a non-admin write. Admin calls use the admin's own session — the service key is never used for admin work and never reaches the browser (tested: not present in any browser file).
- **Two-step verification enforced in the database.** `is_admin()` / `is_owner()` require `aal2` when the user has a verified factor, so a stolen password cannot call the REST API directly.
- **Functions**: 19 `admin_*` functions + `_require_admin`, `_clean_i18n`, `_slugify`, `_unique_slug`; all `SECURITY DEFINER`, pinned `search_path`, executable by `authenticated` only (helpers by `service_role` only). The permission test lists every function and who can run it. Mutation checks (making `_require_admin` a no-op; granting a delete function to `anon`) are caught.
- **Uploads** (`/api/admin/upload`): same-origin check, admin check, `multipart/form-data` only, ≤ 8 MB per file, ≤ 8 files; the real type is read from the first bytes (JPEG/PNG/GIF/WebP only; SVG and anything else refused); file names are server-made UUIDs (the visitor's name is never used); stored with the admin's session so the Storage policy (`is_admin()`, folder `products/` or `site/`, image extensions, no `..`) applies again; a failed database step removes the just-uploaded file; deleting a photo/product deletes the stored file. Files shipped with the site are never deleted.
- **Server actions** are same-origin by Next.js design; tested with a foreign `Origin`.
- **Only fixed message keys travel in URLs** (`?ok=1&err=err_price`), never free text. All text is rendered through React (escaped).
- **Safe deletes**: categories with products cannot be deleted without moving the products; product deletion needs an explicit confirmation panel.
- **Validation lives in the database** (name, price ≥ 0, sale < price, slug format and uniqueness, category exists, ≤ 12 photos, photo path pattern, stock numbers, WhatsApp number digits only/international, URLs).
- **Known limits**: real Supabase Auth, MFA enrolment and the real Storage service are not covered by my tests (emulated). Orders and statuses reuse Phase 1/2 functions. No per-admin audit view in the dashboard (the database audit log exists).
