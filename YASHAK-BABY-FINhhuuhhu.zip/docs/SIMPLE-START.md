# Simple start (no coding)

## A. Put this update on your EXISTING Vercel project (nothing new is created)
1. Unzip the file. If your site is connected to GitHub: replace the files of your repository with the unzipped ones (keep your repository), commit, push. Vercel redeploys by itself.
   No GitHub? In Vercel → your project → Deployments → "Redeploy" is not enough for new files; use GitHub, or the Vercel CLI (`npx vercel --prod` inside the folder, once logged in).
2. Do NOT change your Vercel settings or domain. Environment Variables stay as they are, but check these three exist for **Production**, then press **Redeploy** after any change (they are built into the site):
   `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` (the *anon/public* key), `SUPABASE_SERVICE_ROLE_KEY` (secret).
3. The database is NOT touched by this update: no migration is needed for this version. Products, categories and settings stay as they are.

## B. If login still says an error
The login page now shows the real reason. "Incorrect email or password" = Supabase says the password is wrong. "Sign-in service error…" = the Supabase address or key on Vercel is wrong (fix, then Redeploy). "Access denied" = the account is not in `public.admins`.
Run `supabase/check-admin.sql` in the Supabase SQL editor (it only reads) and send me the result without any password.
To set a password you know: Supabase → Authentication → Users → your user → send a password reset / or use the SQL in the chat. Then sign in and change it yourself on the **Security** page.

## C. Every day
Sign in at `/admin/login` → Dashboard buttons: Products (add, edit, publish, delete), Photos and Prices (inside each product), Categories, Homepage, WhatsApp, Store settings. Press **Save**; the website updates immediately; no deployment needed.

## D. Login self-check (no secrets shown)
Open `https://YOUR-SITE/api/admin/health`. It answers only yes/no: are the Supabase address and key set, is the key the right type (anon/publishable, NOT service_role), does the key belong to that address, can the site reach Supabase Auth, is email+password login enabled. If anything says false / WRONG, fix that variable in Vercel and press Redeploy.
