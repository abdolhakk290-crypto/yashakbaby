# Supabase setup (what YOU must do outside the code)

Everything here is free (Supabase **Free** plan). Nothing is purchased. Do this when you are ready to try the dashboard for real; the code does not need it to be tested locally (the tests use a local database).

> Free-plan facts to know: no automatic backups (export your data regularly), and a project with no activity for a week is paused (you can un-pause it). Daily backups need the paid plan, which has NOT been approved.

## 1. Create the project
1. Go to supabase.com → New project (free). Choose a region close to Morocco (e.g. Frankfurt or Paris). Save the database password in a password manager — it is not used by the website.
2. Project Settings → API: copy **Project URL**, the **anon (public) key** and the **service_role key**.

## 2. Create the database
In **SQL Editor**, run these files **in this order** (paste each, click Run):
`supabase/migrations/20261031000001…` → `…0002` → `…0003` → `…0004` → `…0005` → `…0006` → `…0007` → `…0008`, then `supabase/seed.sql`.
(The seed has your real WhatsApp number, store settings and 3 empty categories — **no products**.)

## 3. Storage
The migration `…0004` creates the public bucket **store-media** (8 MB limit; JPEG/PNG/WebP/GIF only; only admins can write). Check it exists under Storage. Do not create other buckets.

## 4. Your admin login (no default account exists)
1. Authentication → Users → **Add user** → your email + a long password (tick "Auto confirm").
2. Authentication → Providers → Email: **turn OFF "Allow new users to sign up"** (otherwise strangers could create accounts; they would still not be admins, but there is no reason to allow it).
3. Run `supabase/make-owner.sql` (next step) first, sign in at `/admin/login`, open **Security** in the dashboard menu and turn on two-step verification with an authenticator app (scan the QR code, type the 6-digit code). From then on the code is asked at every sign-in.
4. SQL Editor → run `supabase/make-owner.sql` after replacing the email with yours (do this BEFORE step 3 above).

**Two-step verification is enforced in the database**: once your user has a verified factor, a password alone gives no admin access, not even through the REST API. Enrol it **before** you rely on the dashboard. (If you enrol it, you must have it for every login — keep your recovery options safe.)

## 5. Website settings (`.env.local`, later Vercel → Environment Variables)
```
NEXT_PUBLIC_SUPABASE_URL=...           # Project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=...      # anon key (safe in the browser)
SUPABASE_SERVICE_ROLE_KEY=...          # SECRET. Server only. Never share, never commit.
SITE_URL=https://yashakbaby.online     # only when the domain is approved
```
Auth → URL configuration: add your site address(es) (http://localhost:3000 for local tests).

## 6. Checks that can ONLY be done on the real project (not covered by my tests)
- [ ] Sign-in and sign-out at `/admin/login` with your real user; wrong password refused.
- [ ] Two-step verification page (Security menu): QR code appears, a correct code activates it. **This enrolment screen has NOT been tested against real Supabase Auth.**
- [ ] Two-step verification: password only → still sent back to the login page; with the code → in.
- [ ] `select public.is_admin()` works for you after login (the function reads `auth.mfa_factors`; if Supabase refused that, admin access fails closed — tell me and it will be adjusted).
- [ ] Upload a JPG/PNG/WebP photo to a product → it appears on the public product page (image address `…/storage/v1/object/public/store-media/products/…`). Try an SVG → refused.
- [ ] Delete that product → the file disappears from Storage → store-media.
- [ ] With the anon key only (curl or the API docs): `/rest/v1/variants?select=stock` is refused; `/rest/v1/rpc/admin_dashboard` is refused.
- [ ] Place a test order from the website, then see it under Orders.
