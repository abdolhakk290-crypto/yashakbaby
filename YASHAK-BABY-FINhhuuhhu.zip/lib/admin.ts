import 'server-only';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { currentAdmin, supabaseServer } from './supabase-server';
import { DbError } from './db';
import { hasKey, type AKey } from './admin-i18n';

/** Every admin page, action and upload starts here: signed in AND listed in `admins`. The database functions check it again. */
export async function needAdmin() { const a = await currentAdmin(); if (!a) redirect('/admin/login'); return a; }

/** Calls an admin_* database function AS THE SIGNED-IN ADMIN (their own session, never the service key). */
export async function arpc<T = unknown>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const sb = await supabaseServer();
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw new DbError(error.code || 'XX000', error.message, error.details || undefined);
  return data as T;
}

export const fresh = () => { revalidatePath('/', 'layout'); };   // make sure the public website shows the change immediately

export const toCents = (v: FormDataEntryValue | null): string => {
  const s = String(v ?? '').trim().replace(/\s/g, '').replace(',', '.'); if (s === '') return '';
  return /^\d{1,9}(\.\d{1,2})?$/.test(s) ? String(Math.round(Number(s) * 100)) : 'x';
};
export const fromCents = (c: number | null | undefined) => (c == null ? '' : (c / 100).toFixed(2).replace(/\.00$/, ''));
export const formStr = (fd: FormData, k: string, max = 5000) => String(fd.get(k) ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max);
export const formId = (fd: FormData, k = 'id') => { const n = Number(fd.get(k)); return Number.isSafeInteger(n) && n > 0 ? n : 0; };

/** Redirect back to a page with a flash message (only fixed message keys travel in the URL, never free text). */
export function go(path: string, flash: { ok?: boolean; err?: AKey[] } = {}): never {
  const u = new URLSearchParams(); if (flash.ok) u.set('ok', '1'); if (flash.err?.length) u.set('err', flash.err.join(','));
  redirect(path + (u.size ? (path.includes('?') ? '&' : '?') + u.toString() : ''));
}
export function flashKeys(sp: { ok?: string; err?: string }): { ok: boolean; err: AKey[] } {
  return { ok: sp.ok === '1', err: (sp.err || '').split(',').filter(hasKey).slice(0, 6) };
}
const FIELD: Record<string, AKey> = { name: 'err_name', price: 'err_price', sale_price: 'err_sale_price', category: 'err_category', variants: 'err_variants', slug: 'err_slug', sku: 'err_sku', image: 'err_image', images: 'err_images', number: 'err_number' };
/** Turns a database error into message keys for the form. Unknown/unsafe errors become a generic message; nothing technical is shown. */
export function errKeys(e: unknown): AKey[] {
  if (e instanceof DbError) {
    if (e.code === 'YB403') return ['err_denied'];
    if (e.code === 'YB409') return ['err_delete_cat'];
    if (e.code === 'YB422') {
      let fields: string[] = []; try { fields = Object.keys(JSON.parse(e.detail || '{}')); } catch { /* no detail */ }
      const ks = fields.map((f) => FIELD[f]).filter(Boolean); if (ks.length) return ks;
      if (/WhatsApp/i.test(e.message)) return ['err_number'];
    }
    return ['err_generic'];
  }
  throw e;   // redirect() and real bugs must not be swallowed
}
/** Remove uploaded files from Storage (admin session; the storage policy checks is_admin() too). Never touches files shipped with the site. */
export async function removeFiles(paths: string[]) {
  const list = paths.filter((p) => /^(products|site)\/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp|gif)$/.test(p)); if (!list.length) return;
  const sb = await supabaseServer(); await sb.storage.from('store-media').remove(list);
}
export function pick(o: Record<string, string> | null | undefined, lang: string) {
  if (!o) return ''; for (const l of [lang, 'fr', 'ary', 'en', 'ar', 'es', 'zgh']) if (o[l]) return o[l]; return Object.values(o)[0] || '';
}
