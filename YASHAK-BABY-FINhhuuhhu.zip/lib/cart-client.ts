'use client';
/** Browser-side cart: only {variant id, quantity}. Prices and availability are always re-read from the server. */
export type CartItem = { v: number; q: number };
const KEY = 'yb-cart2';
export const loadCart = (): CartItem[] => {
  try { const a = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(a) ? a.filter((x) => x && Number.isInteger(x.v) && x.v > 0 && Number.isInteger(x.q) && x.q > 0).map((x) => ({ v: x.v, q: Math.min(50, x.q) })) : []; } catch { return []; }
};
export const saveCart = (a: CartItem[]) => { try { localStorage.setItem(KEY, JSON.stringify(a)); } catch { /* private mode: cart lives until reload */ } window.dispatchEvent(new Event('yb-cart')); };
export const toast = (m: string) => window.dispatchEvent(new CustomEvent('yb-toast', { detail: m }));
