import 'server-only';
/**
 * The ONLY place where server code talks to the database for public pages. Everything the storefront needs is a SQL function
 * (see supabase/migrations/…0007), called through Supabase's REST layer with `rpc(name, args)`:
 *   role 'anon'    -> the public anon key (reads only what Row Level Security and function grants allow)
 *   role 'service' -> the secret service key (placing orders, rate limiting). Server only.
 */
export class DbError extends Error {
  constructor(public code: string, message: string, public detail?: string) { super(message); }
}
export const dbConfigured = () => !!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
type Role = 'anon' | 'service';

export async function rpc<T = unknown>(fn: string, args: Record<string, unknown> = {}, role: Role = 'anon'): Promise<T> {
  const { createClient } = await import('@supabase/supabase-js');
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = role === 'service' ? process.env.SUPABASE_SERVICE_ROLE_KEY : process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new DbError('YB500', 'Database is not configured');
  const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw new DbError(error.code || 'XX000', error.message, error.details || undefined);
  return data as T;
}
