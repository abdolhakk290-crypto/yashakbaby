/** Money is stored as integer cents (centimes). Display: 150 DH, or 150.50 DH. Used by server and browser code alike. */
export const fmtNum = (c: number) => (c % 100 === 0 ? String(c / 100) : (c / 100).toFixed(2));
export const fmtMoney = (c: number, sym: string) => `${fmtNum(c)} ${sym}`.trim();
export const waLink = (number: string, msg?: string) => `https://wa.me/${number.replace(/\D/g, '')}${msg ? '?text=' + encodeURIComponent(msg) : ''}`;
export type WaLabels = { product: string; price: string; sku: string; size: string; color: string; qty: string; link: string };
/** Prefilled WhatsApp inquiry for one product, built from the owner's template + labels (Settings → WhatsApp). */
export function waProductMessage(o: { template: string; labels: WaLabels; name: string; priceCents: number; sym: string; sku?: string | null; size?: string | null; color?: string | null; qty: number; url: string }) {
  const L = o.labels, lines = [`${L.product}: ${o.name}`, `${L.price}: ${fmtMoney(o.priceCents, o.sym)}`];
  if (o.sku) lines.push(`${L.sku}: ${o.sku}`); if (o.size) lines.push(`${L.size}: ${o.size}`); if (o.color) lines.push(`${L.color}: ${o.color}`);
  lines.push(`${L.qty}: ${o.qty}`, `${L.link}: ${o.url}`);
  return o.template.replace('{details}', lines.join('\n'));
}
