import 'server-only';
import { NextResponse, type NextRequest } from 'next/server';
import { rpc } from './db';

export const json = (body: unknown, status = 200, headers: Record<string, string> = {}) =>
  NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store', ...headers } });

/** Cross-site request protection for POST routes: the browser must say the request comes from this very site, and must send JSON (a plain cross-site <form> cannot). */
export function checkRequest(req: NextRequest, maxChars = 50_000): NextResponse | null {
  const host = req.headers.get('host') || '', origin = req.headers.get('origin');
  if (origin) { let h = ''; try { h = new URL(origin).host; } catch { /* invalid */ } if (!h || h !== host) return json({ error: 'Forbidden' }, 403); }
  else if (req.headers.get('sec-fetch-site') !== 'same-origin') return json({ error: 'Forbidden' }, 403);
  if (!(req.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) return json({ error: 'Unsupported media type' }, 415);
  const len = Number(req.headers.get('content-length') || 0); if (len > maxChars) return json({ error: 'Too large' }, 413);
  return null;
}
export async function readJson(req: NextRequest, maxChars = 50_000): Promise<Record<string, unknown> | null> {
  const text = await req.text(); if (text.length > maxChars) return null;
  try { const b = JSON.parse(text); return b && typeof b === 'object' && !Array.isArray(b) ? b : null; } catch { return null; }
}
/** Client address as set by the hosting platform (Vercel overwrites x-forwarded-for, so it cannot be forged there). */
export const clientIp = (req: NextRequest) => (req.headers.get('x-forwarded-for') || '').split(',')[0].trim().slice(0, 45) || 'local';
/** Atomic counter in the database: true = allowed. */
export async function allow(key: string, max: number, windowSeconds: number): Promise<boolean> {
  return rpc<boolean>('rate_hit', { p_key: key, p_max: max, p_window_seconds: windowSeconds }, 'service');
}
