import defaults from '@/content/defaults.json';
import ui from '@/content/ui.json';

export const LANGS = [
  { c: 'ary', n: 'الدارجة', s: 'دارجة' }, { c: 'ar', n: 'العربية', s: 'عربية' }, { c: 'zgh', n: 'ⵜⴰⵎⴰⵣⵉⵖⵜ', s: 'ⵜⵎⵣ' },
  { c: 'fr', n: 'Français', s: 'FR' }, { c: 'en', n: 'English', s: 'EN' }, { c: 'es', n: 'Español', s: 'ES' },
] as const;
export type Lang = (typeof LANGS)[number]['c'];
export const LANG_CODES: string[] = LANGS.map((l) => l.c);
export const RTL = new Set<string>(['ary', 'ar']);
export const isLang = (x: string): x is Lang => LANG_CODES.includes(x);
export const DEFAULT_LANG: Lang = 'ary';

type Dict = Record<string, string>;
const S = defaults.S as Record<string, Dict>;
const UI = ui as Record<string, Dict>;
/** Default texts shipped with the code. Phase 2 merges the admin-edited overrides from the `translations` table on top. */
export function dict(lang: Lang, overrides: Dict = {}): (key: string, vars?: Record<string, string | number>) => string {
  const base = { ...(UI[lang] || {}), ...(S[lang] || {}) }, fr = { ...(UI.fr || {}), ...(S.fr || {}) };
  return (key, vars) => {
    let s = overrides[key] ?? base[key] ?? fr[key] ?? key;
    if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
    return s;
  };
}
export const BIZ = defaults.BIZ as { addr: string; phone: string; mail: string };

/** Localised value from a {lang: text} object, with fallback to French, then to any language. */
export function loc(o: Record<string, string> | string | null | undefined, lang: string): string {
  if (!o) return ''; if (typeof o === 'string') return o;
  return o[lang] || o.fr || Object.values(o).find((v) => v) || '';
}
export type PageBlock = ['p', string] | ['h', string] | ['l', string[]] | ['n', string] | ['q', string, string];
export const PAGE_KEYS = ['about', 'delivery', 'returns', 'faq', 'privacy', 'terms'] as const;
const PAGES = defaults.PAGES as unknown as Record<string, Record<string, { t: string; b: PageBlock[] }>>;
export const defaultPage = (key: string, lang: string) => PAGES[lang]?.[key] || null;
