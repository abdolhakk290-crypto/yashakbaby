import type { PageBlock } from './i18n';
import type { Settings } from './store';

/**
 * LEGAL HOLD. The 24-hour returns/refunds rule is the owner's business rule, but its compliance with Moroccan consumer law has NOT been reviewed yet.
 * Until the owner switches settings.legal.returns_published to true (admin, Phase 3), no page, FAQ answer or card shows the return window.
 * The rule itself is kept unchanged in the stored texts (strictly 24 hours); only its publication is held back.
 */
export const returnsPublished = (s: Settings | undefined) => s?.legal?.returns_published === true;

// the "…because return requests must be sent within 24 hours" clause that follows the separator in the shipped delivery text, per language
const CLAUSE: Record<string, string> = { fr: ', car ', en: ', because ', es: ', ya que ', ar: '، لأن ', ary: '، حيث ', zgh: ', ⵅⴼ ' };
const MENTIONS_WINDOW = /\b24\b|٢٤/;

/** Removes the sentences that state the return window from the texts shipped with the code. */
export function holdBlocks(blocks: PageBlock[], lang: string): PageBlock[] {
  const out: PageBlock[] = [];
  for (const b of blocks) {
    if (b[0] === 'q' && MENTIONS_WINDOW.test(b[1] + b[2])) continue;                       // FAQ answer about returning an item
    if (b[0] === 'p' && MENTIONS_WINDOW.test(b[1])) {
      const sep = CLAUSE[lang] || CLAUSE.fr, i = b[1].lastIndexOf(sep);
      if (i > 0) out.push(['p', b[1].slice(0, i) + '.']);                                   // keep "contact us the same day", drop the window
      continue;
    }
    out.push(b);
  }
  return out;
}
