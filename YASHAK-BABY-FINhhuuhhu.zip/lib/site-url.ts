/** Public address used in password-reset emails. Set NEXT_PUBLIC_SITE_URL=https://yashakbaby.store in Vercel (Production). Falls back to the current origin. */
export function siteOrigin(): string {
  const env = (process.env.NEXT_PUBLIC_SITE_URL || '').trim().replace(/\/+$/, '');
  if (env) return env;
  return typeof window !== 'undefined' ? window.location.origin : 'https://yashakbaby.store';
}
export const RESET_PATH = '/admin/reset';
