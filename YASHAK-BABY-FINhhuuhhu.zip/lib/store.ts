import 'server-only';
import { cache } from 'react';
import { rpc, dbConfigured } from './db';
import allDefaults from '@/content/settings-defaults.json';
// payment settings are private (never part of the public site data)
const { payments: _private, ...defaultSettings } = allDefaults as Record<string, unknown>; void _private;
import { LANGS, DEFAULT_LANG, PAGE_KEYS, type Lang } from './i18n';

export type Card = { id: number; slug: string; name: string; sku: string | null; price_cents: number; old_cents: number | null; available: boolean; in_stock: boolean; category: string | null; image: string | null; image_alt: string | null };
export type Variant = { id: number; sku: string | null; size: string | null; color: string | null; price_cents: number; in_stock: boolean };
export type Product = Card & { description: string; specs: string; category_name: string | null; seo_title: string; seo_desc: string; og_image: string | null; images: { path: string; alt: string }[]; variants: Variant[] };
export type Category = { slug: string; name: string; description: string; image: string | null };
export type Settings = Record<string, any>;   // eslint-disable-line @typescript-eslint/no-explicit-any
export type Site = { settings: Settings; categories: Category[]; translations: Record<string, string>; live: boolean };

/** Where a stored image path points: `/…` = file shipped with the site, anything else = Supabase Storage bucket "store-media". */
export function imgUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  if (path.startsWith('/')) return path;
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  return base ? `${base}/storage/v1/object/public/store-media/${path}` : null;
}
/** Public address of the website: the owner's setting (Admin → Settings), else the SITE_URL environment variable (read when the server runs, not at build time), else localhost. */
export const siteBase = (s?: Settings) => (s?.store?.base_url || process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/+$/, '');

const DEFAULT_CATS: Category[] = [];
/** Whole-site data for one language. Falls back to the built-in defaults if the database cannot be reached, so the site never shows a blank page. */
export const getSite = cache(async (lang: Lang): Promise<Site> => {
  if (dbConfigured()) {
    try {
      const r = await rpc<{ settings: Settings; categories: Category[]; translations: Record<string, string> }>('store_site', { p_lang: lang });
      return { settings: { ...(defaultSettings as Settings), ...r.settings }, categories: r.categories, translations: r.translations, live: true };
    } catch (e) { console.error('store_site failed', (e as Error).message); }
  }
  return { settings: defaultSettings as Settings, categories: DEFAULT_CATS, translations: {}, live: false };
});

export type CatalogQuery = { category?: string | null; q?: string | null; featured?: boolean; size?: string | null; sort?: string | null; limit?: number; offset?: number };
export async function getCatalog(lang: Lang, o: CatalogQuery = {}) {
  if (!dbConfigured()) return { items: [] as Card[], total: 0, sizes: [] as string[] };
  return rpc<{ items: Card[]; total: number; sizes: string[] }>('store_catalog', {
    p_lang: lang, p_category: o.category ?? null, p_q: o.q ?? null, p_featured: !!o.featured, p_size: o.size ?? null,
    p_sort: o.sort === 'asc' || o.sort === 'desc' ? o.sort : null, p_limit: o.limit ?? 48, p_offset: o.offset ?? 0 });
}
export const getProduct = cache(async (slug: string, lang: Lang) => dbConfigured() ? rpc<Product | null>('store_product', { p_slug: slug, p_lang: lang }) : null);
export const getPageRow = async (key: string, lang: Lang) => dbConfigured() ? rpc<{ title: string; blocks: unknown[] } | null>('store_page', { p_key: key, p_lang: lang }) : null;
export const getSitemapData = async () => dbConfigured() ? rpc<{ categories: string[]; products: { slug: string; updated: string }[] }>('store_sitemap') : { categories: [], products: [] };
export const getCheckout = async (lang: Lang) => rpc<{ methods: { key: 'bank' | 'cod'; instructions: string }[]; delivery: { fee_cents: number; free_over_cents: number | null; note: string } }>('store_checkout', { p_lang: lang });

export const isPageKey = (k: string): k is (typeof PAGE_KEYS)[number] => (PAGE_KEYS as readonly string[]).includes(k);
export { LANGS, DEFAULT_LANG };
