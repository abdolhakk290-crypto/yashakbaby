import { createBrowserClient } from '@supabase/ssr';
/** Browser client: anon key only. Everything it can do is limited by Row Level Security. */
export const supabaseBrowser = () => createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
