import 'server-only';
import { createServerClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';

/** Supabase client acting as the logged-in visitor (anon or admin). RLS applies. Use this for everything except privileged server jobs. */
export async function supabaseServer() {
  const store = await cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list) => { try { list.forEach(({ name, value, options }) => store.set(name, value, options)); } catch { /* called from a Server Component: the proxy refreshes the session */ } },
    },
  });
}

/** Privileged client (bypasses RLS). SERVER ONLY — used for place_order and rate limiting. Never import from client code (the 'server-only' import enforces it). */
export function supabaseService() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set');
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

/** Returns the signed-in admin (or null). Checks the database table `admins`, not just that someone is logged in. */
export async function currentAdmin() {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();            // verifies the token with Supabase Auth (not just reading the cookie)
  if (!user) return null;
  const { data: aal } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();      // password only, but two-step verification is set up → not an admin session yet
  if (aal && aal.nextLevel === 'aal2' && aal.currentLevel !== 'aal2') return null;
  const { data } = await sb.from('admins').select('role').eq('user_id', user.id).maybeSingle();
  return data ? { id: user.id, email: user.email ?? '', role: data.role as 'owner' | 'admin' } : null;
}
