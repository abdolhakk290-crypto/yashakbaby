-- READ-ONLY diagnosis for "I cannot log in to /admin". Run in the Supabase SQL editor; replace the email. Changes nothing.
-- 1) Does the Auth user exist and is the email confirmed?
select id, email, email_confirmed_at is not null as confirmed from auth.users where email = 'YOUR-EMAIL@example.com';
-- 2) Is that user listed in public.admins (columns: user_id, role, created_at)? No row = "Access denied" at login.
select a.user_id, a.role, a.created_at from public.admins a join auth.users u on u.id = a.user_id where u.email = 'YOUR-EMAIL@example.com';
-- 3) If (1) returned a row but (2) is empty, run supabase/make-owner.sql (it prints "INSERT 0 0" when the email did not match any Auth user).

-- 4) Which columns does YOUR public.admins really have? (This project expects: user_id uuid, role text, created_at.)
select column_name, data_type from information_schema.columns where table_schema = 'public' and table_name = 'admins' order by ordinal_position;
-- 5) Is your account active (not banned) and does it have a password set? (shows only yes/no, never the password)
select email, banned_until, encrypted_password is not null as has_password from auth.users where email = 'YOUR-EMAIL@example.com';
