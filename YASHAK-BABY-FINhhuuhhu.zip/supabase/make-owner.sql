-- Run ONCE in the Supabase SQL editor after you create your own login (Authentication → Users → Add user, then enable two-step verification).
-- There is no default admin account. Replace the email with yours.
-- After running, "INSERT 0 1" = done. "INSERT 0 0" = the email matches no Auth user (check spelling, or create the user first).
insert into public.admins (user_id, role) select id, 'owner' from auth.users where email = 'YOUR-EMAIL@example.com';
