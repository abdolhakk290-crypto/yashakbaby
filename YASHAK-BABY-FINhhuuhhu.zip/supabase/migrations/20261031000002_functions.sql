-- Helper + business functions. All SECURITY DEFINER functions pin search_path and are NOT executable by PUBLIC.
-- An admin is a listed user. If that user has two-step verification set up (a verified factor), the session must ALSO be two-step verified (aal2):
-- a stolen password alone (aal1) is not enough, not even when calling the database API directly.
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public, pg_temp as
$$ select exists (select 1 from public.admins where user_id = auth.uid())
      and (coalesce(auth.jwt() ->> 'aal', '') = 'aal2' or not exists (select 1 from auth.mfa_factors where user_id = auth.uid() and status = 'verified')) $$;
create or replace function public.is_owner() returns boolean language sql stable security definer set search_path = public, pg_temp as
$$ select exists (select 1 from public.admins where user_id = auth.uid() and role = 'owner')
      and (coalesce(auth.jwt() ->> 'aal', '') = 'aal2' or not exists (select 1 from auth.mfa_factors where user_id = auth.uid() and status = 'verified')) $$;

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at := now(); return new; end $$;
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();
create trigger orders_touch before update on public.orders for each row execute function public.touch_updated_at();

-- Every stock change is logged automatically, whoever makes it (customer order, admin edit, function).
create or replace function public.log_stock_change() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if tg_op = 'INSERT' then
    if new.stock <> 0 then insert into stock_log(variant_id, delta, reason, user_id) values (new.id, new.stock, 'initial', auth.uid()); end if;
  elsif new.stock <> old.stock then
    insert into stock_log(variant_id, delta, reason, order_id, user_id)
    values (new.id, new.stock - old.stock, coalesce(nullif(current_setting('yb.reason', true), ''), 'manual_edit'), nullif(current_setting('yb.order_id', true), '')::bigint, auth.uid());
  end if; return new;
end $$;
create trigger variants_stock_log after insert or update of stock on public.variants for each row execute function public.log_stock_change();

-- Audit trail for admin changes.
create or replace function public.audit_change() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare r jsonb := to_jsonb(coalesce(new, old));
begin
  insert into audit_log(user_id, action, detail) values (auth.uid(), lower(tg_op) || ':' || tg_table_name, coalesce(r->>'id', r->>'key', r->>'user_id'));
  return coalesce(new, old);
end $$;
do $$ declare t text; begin
  foreach t in array array['products','variants','categories','collections','settings','private_settings','pages','translations','admins','orders','customers'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_change()', t || '_audit', t);
  end loop; end $$;

-- Order status can only change through set_order_status() (keeps stock consistent). Totals can't be tampered with.
create or replace function public.orders_guard() returns trigger language plpgsql as $$
begin
  if new.status is distinct from old.status and coalesce(current_setting('yb.status_ok', true), '') <> 'on' then
    raise exception 'Use set_order_status() to change an order status' using errcode = 'YB403'; end if;
  if new.subtotal_cents is distinct from old.subtotal_cents or new.number is distinct from old.number then
    raise exception 'Order amounts and number are immutable' using errcode = 'YB403'; end if;
  if new.stock_held is distinct from old.stock_held and coalesce(current_setting('yb.status_ok', true), '') <> 'on' then
    raise exception 'Stock flag is managed by set_order_status()' using errcode = 'YB403'; end if;
  new.total_cents := new.subtotal_cents + new.delivery_cents; return new;
end $$;
create trigger orders_guard before update on public.orders for each row execute function public.orders_guard();

-- Atomic rate limiter (used by server code with the service key).
create or replace function public.rate_hit(p_key text, p_max int, p_window_seconds int) returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare r public.rate_limits;
begin
  insert into rate_limits(key, window_start, hits) values (p_key, now(), 1)
  on conflict (key) do update set
    window_start = case when rate_limits.window_start < now() - make_interval(secs => p_window_seconds) then now() else rate_limits.window_start end,
    hits = case when rate_limits.window_start < now() - make_interval(secs => p_window_seconds) then 1 else rate_limits.hits + 1 end
  returning * into r;
  return r.hits <= p_max;
end $$;

-- Prices a cart from the database only; never trusts the browser. p_lock=true locks the variant rows (inside place_order).
create or replace function public._price_cart(p_items jsonb, p_lock boolean) returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare agg jsonb := '{}'; e jsonb; vid bigint; q int; ids bigint[]; lines jsonb := '[]'; sub bigint := 0; rec record; unit int; avail int; n int := 0;
begin
  if jsonb_typeof(p_items) is distinct from 'array' then return jsonb_build_object('lines', '[]'::jsonb, 'subtotal', 0); end if;
  for e in select * from jsonb_array_elements(p_items) loop
    n := n + 1; exit when n > 100;
    begin vid := trunc((e->>'v')::numeric)::bigint; q := trunc((e->>'q')::numeric)::int; exception when others then continue; end;
    if vid > 0 and q > 0 and q <= 50 then agg := jsonb_set(agg, array[vid::text], to_jsonb(least(50, coalesce((agg->>vid::text)::int, 0) + q))); end if;
  end loop;
  select coalesce(array_agg(k::bigint order by k::bigint), '{}') into ids from jsonb_object_keys(agg) k;
  if p_lock and array_length(ids, 1) > 0 then perform 1 from variants where id = any(ids) order by id for update; end if;
  foreach vid in array ids loop
    q := (agg->>vid::text)::int;
    select v.id, v.sku vsku, v.size, v.color, v.price_cents vprice, v.stock, p.id pid, p.slug, p.name, p.sku psku, p.price_cents, p.sale_price_cents, p.track_stock,
           (select path from product_images where product_id = p.id order by sort, id limit 1) image
      into rec from variants v join products p on p.id = v.product_id
     where v.id = vid and v.active and p.status = 'published' and p.available;
    if not found then lines := lines || jsonb_build_array(jsonb_build_object('v', vid, 'gone', true)); continue; end if;
    unit := coalesce(rec.vprice, case when rec.sale_price_cents is not null and rec.sale_price_cents < rec.price_cents then rec.sale_price_cents else rec.price_cents end);
    avail := case when rec.track_stock then greatest(rec.stock, 0) else 9999 end;
    lines := lines || jsonb_build_array(jsonb_build_object('v', vid, 'asked', q, 'avail', avail, 'ok', q <= avail, 'unit', unit, 'product_id', rec.pid, 'slug', rec.slug, 'name', rec.name,
      'sku', coalesce(rec.vsku, rec.psku, ''), 'size', rec.size, 'color', rec.color, 'track', rec.track_stock, 'image', rec.image));
    sub := sub + unit::bigint * least(q, avail);
  end loop;
  return jsonb_build_object('lines', lines, 'subtotal', sub);
end $$;
create or replace function public.get_cart(p_items jsonb) returns jsonb language sql security definer set search_path = public, pg_temp as
$$ select public._price_cart(p_items, false) $$;

create or replace function public._delivery_for(p_subtotal bigint) returns int language plpgsql stable security definer set search_path = public, pg_temp as $$
declare d jsonb; fee int; fo text;
begin
  select value into d from settings where key = 'delivery';
  fee := greatest(0, coalesce((d->>'fee_cents')::int, 0)); fo := d->>'free_over_cents';
  if fo is not null and p_subtotal >= fo::bigint then return 0; end if;
  return fee;
end $$;

create or replace function public._enabled_methods() returns text[] language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(array_agg(m order by m), '{}') from (select m from private_settings s, unnest(array['cod','bank']) m where s.key = 'payments' and coalesce((s.value->m->>'enabled')::boolean, false)) x $$;

-- Places an order. Called ONLY by server code with the service key. One transaction: validate, lock, check stock, decrement, record.
create or replace function public.place_order(p jsonb, p_lang text default 'fr') returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  nm text := btrim(coalesce(p->>'name','')); ph text := regexp_replace(coalesce(p->>'phone',''), '[\s.\-()]', '', 'g'); ad text := btrim(coalesce(p->>'address',''));
  ct text := btrim(coalesce(p->>'city','')); nt text := left(btrim(coalesce(p->>'note','')), 500); em text := left(btrim(coalesce(p->>'email','')), 120);
  errs jsonb := '{}'; cart jsonb; bad jsonb; l jsonb; methods text[]; method text; sub bigint; del int; tot bigint; cust bigint; oid bigint; num text; pay text; r jsonb; pays jsonb;
begin
  if p_lang not in ('ary','ar','zgh','fr','en','es') then p_lang := 'fr'; end if;
  if length(nm) < 2 then errs := errs || '{"name":"required"}'; elsif length(nm) > 80 then errs := errs || '{"name":"too_long"}'; end if;
  if ph !~ '^\+?\d{8,15}$' then errs := errs || '{"phone":"invalid"}'; end if;
  if length(ad) < 5 then errs := errs || '{"address":"required"}'; elsif length(ad) > 300 then errs := errs || '{"address":"too_long"}'; end if;
  if length(ct) < 2 then errs := errs || '{"city":"required"}'; elsif length(ct) > 60 then errs := errs || '{"city":"too_long"}'; end if;
  if em <> '' and em !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then errs := errs || '{"email":"invalid"}'; end if;
  if errs <> '{}' then raise exception 'Please check the form.' using errcode = 'YB422', detail = errs::text; end if;
  methods := public._enabled_methods();
  if array_length(methods, 1) > 0 then
    method := coalesce(p->>'payment', '');
    if not (method = any(methods)) then raise exception 'Please choose a payment method.' using errcode = 'YB422', detail = '{"payment":"required"}'; end if;
  end if;
  cart := public._price_cart(p->'items', true);
  if jsonb_array_length(cart->'lines') = 0 then raise exception 'Your cart is empty.' using errcode = 'YB422'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('v', x->'v', 'in_stock', case when x ? 'gone' then false else (x->>'avail')::int > 0 end, 'gone', x ? 'gone')), '[]') into bad
    from jsonb_array_elements(cart->'lines') x where x ? 'gone' or not (x->>'ok')::boolean;
  if jsonb_array_length(bad) > 0 then raise exception 'Some items are no longer available in the requested quantity.' using errcode = 'YB409', detail = jsonb_build_object('lines', bad)::text; end if;
  sub := (cart->>'subtotal')::bigint; del := public._delivery_for(sub); tot := sub + del;
  select id into cust from customers where phone = ph and not anonymized order by id limit 1 for update;
  if cust is not null then update customers set name = nm, email = coalesce(nullif(em, ''), email), address = ad, city = ct where id = cust;
  else insert into customers(name, phone, email, address, city) values (nm, ph, nullif(em, ''), ad, ct) returning id into cust; end if;
  oid := nextval(pg_get_serial_sequence('public.orders', 'id')); num := 'YB-' || lpad(oid::text, 6, '0');
  insert into orders(id, number, customer_id, name, phone, email, address, city, customer_note, payment_method, payment_status, subtotal_cents, delivery_cents, total_cents, lang)
  values (oid, num, cust, nm, ph, nullif(em, ''), ad, ct, nullif(nt, ''), method, case when method = 'bank' then 'awaiting_transfer' else 'unpaid' end, sub, del, tot, p_lang);
  perform set_config('yb.reason', 'order', true); perform set_config('yb.order_id', oid::text, true);
  for l in select * from jsonb_array_elements(cart->'lines') loop
    if (l->>'track')::boolean then
      update variants set stock = stock - (l->>'asked')::int where id = (l->>'v')::bigint and stock >= (l->>'asked')::int;
      if not found then raise exception 'Stock changed. Please review your cart.' using errcode = 'YB409'; end if;
    end if;
    insert into order_items(order_id, product_id, variant_id, name, sku, size, color, qty, unit_cents)
    values (oid, (l->>'product_id')::bigint, (l->>'v')::bigint, coalesce(l->'name'->>p_lang, l->'name'->>'fr', (select value from jsonb_each_text(l->'name') limit 1), ''), nullif(l->>'sku',''), l->>'size', l->>'color', (l->>'asked')::int, (l->>'unit')::int);
  end loop;
  perform set_config('yb.reason', '', true); perform set_config('yb.order_id', '', true);
  insert into audit_log(user_id, action, detail) values (null, 'order_placed', num);
  select value into pays from private_settings where key = 'payments';
  r := jsonb_build_object('id', oid, 'number', num, 'subtotal', sub, 'delivery', del, 'total', tot, 'method', method);
  if method = 'bank' then r := r || jsonb_build_object('bank', (pays->'bank') - 'enabled'); elsif method = 'cod' then r := r || jsonb_build_object('cod', pays->'cod'->'instructions'); end if;
  return r;
end $$;

-- Admin changes an order status; stock rules identical to the earlier Node version.
create or replace function public.set_order_status(p_id bigint, p_status text, p_restock boolean default false) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare o public.orders; it record; held boolean; short boolean;
begin
  if not public.is_admin() then raise exception 'Not allowed' using errcode = 'YB403'; end if;
  if p_status not in ('pending','confirmed','shipped','delivered','cancelled','returned') then raise exception 'Unknown status.' using errcode = 'YB422'; end if;
  select * into o from orders where id = p_id for update;
  if not found then raise exception 'Order not found.' using errcode = 'YB404'; end if;
  held := o.stock_held;
  perform set_config('yb.order_id', p_id::text, true);
  if p_status = 'cancelled' and held then
    perform set_config('yb.reason', 'order_cancelled', true);
    for it in select oi.variant_id, oi.qty from order_items oi join variants v on v.id = oi.variant_id join products p on p.id = v.product_id where oi.order_id = p_id and p.track_stock order by oi.variant_id loop
      update variants set stock = stock + it.qty where id = it.variant_id; end loop;
    held := false;
  elsif o.status = 'cancelled' and p_status <> 'cancelled' and not held then
    select exists (select 1 from order_items oi join variants v on v.id = oi.variant_id join products p on p.id = v.product_id where oi.order_id = p_id and p.track_stock and v.stock < oi.qty) into short;
    if short then raise exception 'Not enough stock to reopen this order.' using errcode = 'YB409'; end if;
    perform set_config('yb.reason', 'order_reopened', true);
    for it in select oi.variant_id, oi.qty from order_items oi join variants v on v.id = oi.variant_id join products p on p.id = v.product_id where oi.order_id = p_id and p.track_stock order by oi.variant_id loop
      update variants set stock = stock - it.qty where id = it.variant_id; end loop;
    held := true;
  end if;
  if p_status = 'returned' and p_restock and held then
    perform set_config('yb.reason', 'order_returned', true);
    for it in select oi.variant_id, oi.qty from order_items oi join variants v on v.id = oi.variant_id join products p on p.id = v.product_id where oi.order_id = p_id and p.track_stock order by oi.variant_id loop
      update variants set stock = stock + it.qty where id = it.variant_id; end loop;
    held := false;
  end if;
  perform set_config('yb.status_ok', 'on', true);
  update orders set status = p_status, stock_held = held, delivered_at = case when p_status = 'delivered' and delivered_at is null then now() else delivered_at end where id = p_id;
  perform set_config('yb.status_ok', '', true); perform set_config('yb.reason', '', true); perform set_config('yb.order_id', '', true);
end $$;

create or replace function public.adjust_stock(p_variant bigint, p_delta int, p_reason text default 'manual') returns int language plpgsql security definer set search_path = public, pg_temp as $$
declare s int;
begin
  if not public.is_admin() then raise exception 'Not allowed' using errcode = 'YB403'; end if;
  if p_delta is null or p_delta = 0 then raise exception 'Enter a quantity.' using errcode = 'YB422'; end if;
  perform set_config('yb.reason', left(coalesce(nullif(btrim(p_reason), ''), 'manual'), 60), true);
  update variants set stock = stock + p_delta where id = p_variant returning stock into s;
  perform set_config('yb.reason', '', true);
  if not found then raise exception 'Variant not found.' using errcode = 'YB404'; end if;
  return s;
exception when check_violation then raise exception 'Stock cannot go below zero.' using errcode = 'YB422';
end $$;

create or replace function public.anonymize_customer(p_id bigint) returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if not public.is_admin() then raise exception 'Not allowed' using errcode = 'YB403'; end if;
  update customers set name = 'Anonymized', phone = null, email = null, address = null, city = null, notes = '', anonymized = true where id = p_id;
  update orders set name = 'Anonymized', phone = '-', email = null, address = '-', customer_note = null where customer_id = p_id and status in ('delivered','cancelled','returned');
end $$;
