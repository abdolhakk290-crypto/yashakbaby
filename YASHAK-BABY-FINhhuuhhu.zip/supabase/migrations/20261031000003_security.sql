-- Row Level Security + explicit grants. Default-deny: only what is listed below is reachable through the API.
alter table public.admins enable row level security;            alter table public.settings enable row level security;
alter table public.private_settings enable row level security;  alter table public.categories enable row level security;
alter table public.collections enable row level security;       alter table public.products enable row level security;
alter table public.product_collections enable row level security; alter table public.product_images enable row level security;
alter table public.variants enable row level security;          alter table public.customers enable row level security;
alter table public.orders enable row level security;            alter table public.order_items enable row level security;
alter table public.order_notes enable row level security;       alter table public.stock_log enable row level security;
alter table public.translations enable row level security;      alter table public.pages enable row level security;
alter table public.audit_log enable row level security;         alter table public.rate_limits enable row level security;

revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
grant all on all tables in schema public to service_role;  grant all on all sequences in schema public to service_role;  grant execute on all functions in schema public to service_role;

-- public (storefront) reads
grant select on public.settings, public.categories, public.collections, public.products, public.product_collections, public.product_images, public.variants, public.translations, public.pages to anon, authenticated;
create policy settings_read on public.settings for select using (true);
create policy translations_read on public.translations for select using (true);
create policy pages_read on public.pages for select using (true);
create policy categories_read on public.categories for select using (active or public.is_admin());
create policy collections_read on public.collections for select using (active or public.is_admin());
create policy products_read on public.products for select using (status = 'published' or public.is_admin());
create policy images_read on public.product_images for select using (public.is_admin() or exists (select 1 from public.products p where p.id = product_id and p.status = 'published'));
create policy pcol_read on public.product_collections for select using (public.is_admin() or exists (select 1 from public.products p where p.id = product_id and p.status = 'published'));
create policy variants_read on public.variants for select using (public.is_admin() or (active and exists (select 1 from public.products p where p.id = product_id and p.status = 'published')));

-- admin writes (authenticated role, but RLS requires is_admin())
grant insert, update, delete on public.settings, public.categories, public.collections, public.products, public.product_collections, public.product_images, public.variants, public.translations, public.pages to authenticated;
do $$ declare t text; begin
  foreach t in array array['settings','categories','collections','products','product_collections','product_images','variants','translations','pages'] loop
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t || '_admin', t);
  end loop; end $$;
-- note: policies are permissive and OR-ed: "read" policies above for select, "_admin" policy for everything admin.

-- admin-only data
grant select, insert, update, delete on public.private_settings to authenticated;
create policy private_settings_admin on public.private_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, update on public.customers to authenticated;
create policy customers_admin_read on public.customers for select to authenticated using (public.is_admin());
create policy customers_admin_update on public.customers for update to authenticated using (public.is_admin()) with check (public.is_admin());
grant select, update (payment_status, delivery_cents, customer_note) on public.orders to authenticated;   -- status only via set_order_status()
create policy orders_admin_read on public.orders for select to authenticated using (public.is_admin());
create policy orders_admin_update on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
grant select on public.order_items to authenticated;
create policy order_items_admin_read on public.order_items for select to authenticated using (public.is_admin());
grant select, insert on public.order_notes to authenticated;
create policy order_notes_admin_read on public.order_notes for select to authenticated using (public.is_admin());
create policy order_notes_admin_insert on public.order_notes for insert to authenticated with check (public.is_admin() and user_id = auth.uid());
grant select on public.stock_log, public.audit_log to authenticated;
create policy stock_log_admin_read on public.stock_log for select to authenticated using (public.is_admin());
create policy audit_log_admin_read on public.audit_log for select to authenticated using (public.is_admin());
grant select, insert, update, delete on public.admins to authenticated;
create policy admins_read on public.admins for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy admins_owner_write on public.admins for all to authenticated using (public.is_owner()) with check (public.is_owner());
-- rate_limits: RLS on, no policy, no grant → reachable only by service_role / definer functions.

-- function permissions
grant execute on function public.is_admin(), public.is_owner() to anon, authenticated;
grant execute on function public.get_cart(jsonb) to anon, authenticated;                                  -- public prices/stock only
grant execute on function public.set_order_status(bigint, text, boolean), public.adjust_stock(bigint, int, text), public.anonymize_customer(bigint) to authenticated;   -- each re-checks is_admin()
-- place_order, rate_hit, _price_cart, _delivery_for, _enabled_methods: service_role only (server code with the secret key).
