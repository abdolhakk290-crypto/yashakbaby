-- Storage: one public-read bucket; only admins can write; only images; 8 MB cap. Listing is admin-only.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('store-media', 'store-media', true, 8388608, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 8388608, allowed_mime_types = excluded.allowed_mime_types;

create policy "store-media admin read"   on storage.objects for select to authenticated using (bucket_id = 'store-media' and public.is_admin());
create policy "store-media admin insert" on storage.objects for insert to authenticated with check (
  bucket_id = 'store-media' and public.is_admin() and name ~ '^(products|site)/[A-Za-z0-9_-]+(/[A-Za-z0-9_-]+)*\.(jpg|jpeg|png|webp|gif)$' and name !~ '\.\.');
create policy "store-media admin update" on storage.objects for update to authenticated using (bucket_id = 'store-media' and public.is_admin()) with check (bucket_id = 'store-media' and public.is_admin());
create policy "store-media admin delete" on storage.objects for delete to authenticated using (bucket_id = 'store-media' and public.is_admin());
-- No policy for anon: anonymous visitors can fetch files via the public URL but cannot list, upload, change or delete.
