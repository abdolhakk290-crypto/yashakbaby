-- Server-side validation that holds no matter which client writes (admin UI, SQL console, future code).
create or replace function public._check_urls(v jsonb) returns boolean language plpgsql immutable as $$
declare k text; x jsonb;
begin
  if jsonb_typeof(v) = 'object' then
    for k, x in select * from jsonb_each(v) loop
      if k in ('image','logo_header','logo_footer','og_image','instagram','facebook','tiktok','canonical') and jsonb_typeof(x) = 'string'
         and (x #>> '{}') <> '' and (x #>> '{}') !~ '^(https?://|/(?!/))[^\s"''<>]*$' and (x #>> '{}') !~ '^(site|products)/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp|gif)$' then return false; end if;   -- address, site file, or a photo uploaded to storage
      if jsonb_typeof(x) in ('object','array') and not public._check_urls(x) then return false; end if;
    end loop;
  elsif jsonb_typeof(v) = 'array' then
    for x in select * from jsonb_array_elements(v) loop if not public._check_urls(x) then return false; end if; end loop;
  end if; return true;
end $$;

create or replace function public.validate_setting() returns trigger language plpgsql as $$
declare v jsonb := new.value; n text;
begin
  if tg_table_name = 'settings' and new.key not in ('store','social','whatsapp','delivery','home','branding','seo','legal') then
    raise exception 'Unknown setting %', new.key using errcode = 'YB422'; end if;
  if tg_table_name = 'private_settings' and new.key <> 'payments' then raise exception 'Unknown setting %', new.key using errcode = 'YB422'; end if;
  if jsonb_typeof(v) <> 'object' then raise exception 'Setting must be an object' using errcode = 'YB422'; end if;
  if not public._check_urls(v) then raise exception 'Links and image addresses must start with https:// or /' using errcode = 'YB422'; end if;
  if new.key = 'whatsapp' then
    n := coalesce(v->>'number', '');
    if n <> '' and n !~ '^\d{8,15}$' then raise exception 'WhatsApp number must be digits only in international format (for example 212601668146)' using errcode = 'YB422'; end if;
    if coalesce((v->>'enabled')::boolean, false) and n = '' then raise exception 'Enter a WhatsApp number first' using errcode = 'YB422'; end if;
  elsif new.key = 'store' then
    if coalesce(v->>'email', '') !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Invalid contact email' using errcode = 'YB422'; end if;
    if coalesce(v->>'currency', '') !~ '^[A-Z]{3}$' then raise exception 'Currency must be a 3-letter code' using errcode = 'YB422'; end if;
    if coalesce(v->>'default_lang', '') not in ('ary','ar','zgh','fr','en','es') then raise exception 'Unknown default language' using errcode = 'YB422'; end if;
    if coalesce(v->>'base_url', '') <> '' and (v->>'base_url') !~ '^https?://[^\s/]+$' then raise exception 'Website address must look like https://www.example.com' using errcode = 'YB422'; end if;
    if coalesce(v->>'low_stock_threshold', '0') !~ '^\d{1,4}$' then raise exception 'Low-stock threshold must be a whole number' using errcode = 'YB422'; end if;
  elsif new.key = 'legal' then
    if v ? 'returns_published' and jsonb_typeof(v->'returns_published') <> 'boolean' then raise exception 'returns_published must be true or false' using errcode = 'YB422'; end if;
  elsif new.key = 'delivery' then
    if coalesce(v->>'fee_cents', '0') !~ '^\d{1,9}$' then raise exception 'Delivery fee must be a positive amount' using errcode = 'YB422'; end if;
    if v->>'free_over_cents' is not null and (v->>'free_over_cents') !~ '^\d{1,9}$' then raise exception 'Free-delivery threshold must be a positive amount' using errcode = 'YB422'; end if;
  elsif new.key = 'payments' then
    if coalesce((v->'online'->>'enabled')::boolean, false) then raise exception 'Online payment cannot be enabled until a real provider integration exists' using errcode = 'YB422'; end if;
    if coalesce((v->'bank'->>'enabled')::boolean, false) and (btrim(coalesce(v->'bank'->>'holder', '')) = '' or btrim(coalesce(v->'bank'->>'iban', '')) = '') then
      raise exception 'Bank transfer needs an account holder and an IBAN or account number before it can be enabled' using errcode = 'YB422'; end if;
  end if;
  new.updated_at := now(); return new;
end $$;
create trigger settings_validate before insert or update on public.settings for each row execute function public.validate_setting();
create trigger private_settings_validate before insert or update on public.private_settings for each row execute function public.validate_setting();

create or replace function public.validate_product() returns trigger language plpgsql as $$
begin
  if not public._check_urls(new.seo) then raise exception 'Links and image addresses must start with https:// or /' using errcode = 'YB422'; end if;
  if new.status = 'published' and not exists (select 1 from public.variants where product_id = new.id and active) and tg_op = 'UPDATE' then
    raise exception 'A published product needs at least one active variant' using errcode = 'YB422'; end if;
  return new;
end $$;
create trigger products_validate before insert or update on public.products for each row execute function public.validate_product();

create or replace function public.duplicate_product(p_id bigint) returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
declare p public.products; nid bigint; s text; n int := 1; cand text;
begin
  if not public.is_admin() then raise exception 'Not allowed' using errcode = 'YB403'; end if;
  select * into p from products where id = p_id; if not found then raise exception 'Not found.' using errcode = 'YB404'; end if;
  s := left(p.slug, 52) || '-copy'; cand := s;
  while exists (select 1 from products where slug = cand) loop n := n + 1; cand := s || '-' || n; end loop;
  insert into products(slug, category_id, name, description, specs, price_cents, sale_price_cents, sku, status, featured, available, track_stock, seo)
  values (cand, p.category_id, (select jsonb_object_agg(k, v || ' (copy)') from jsonb_each_text(p.name) e(k, v)), p.description, p.specs, p.price_cents, p.sale_price_cents, null, 'draft', false, p.available, p.track_stock, p.seo)
  returning id into nid;
  insert into variants(product_id, sku, size, color, price_cents, stock, active) select nid, null, size, color, price_cents, 0, active from variants where product_id = p_id;
  insert into product_images(product_id, path, alt, sort) select nid, path, alt, sort from product_images where product_id = p_id;
  insert into product_collections select nid, collection_id from product_collections where product_id = p_id;
  return nid;
end $$;
revoke all on function public.duplicate_product(bigint), public._check_urls(jsonb) from public, anon, authenticated;
grant execute on function public.duplicate_product(bigint) to authenticated;
grant execute on function public._check_urls(jsonb) to authenticated, service_role;   -- pure helper used by validation triggers that run as the caller
