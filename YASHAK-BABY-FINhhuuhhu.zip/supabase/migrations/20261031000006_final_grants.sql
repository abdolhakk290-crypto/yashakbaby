-- Re-assert function permissions after all functions exist (default privileges would otherwise re-grant them).
revoke all on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
grant execute on function public.is_admin(), public.is_owner(), public.get_cart(jsonb) to anon, authenticated;
grant execute on function public.set_order_status(bigint, text, boolean), public.adjust_stock(bigint, int, text), public.anonymize_customer(bigint), public.duplicate_product(bigint) to authenticated;
grant execute on function public._check_urls(jsonb) to authenticated;   -- pure helper, called by validation triggers running as the caller
