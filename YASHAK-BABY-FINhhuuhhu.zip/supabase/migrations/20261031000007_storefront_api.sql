-- Phase 2: storefront API + exact stock is private.
-- Customers (anon / logged-in non-admin) may learn ONLY "in stock / out of stock". Exact quantities are visible to admins only (view admin_variants).

-- 1. The stock column is no longer readable through the API by anon/authenticated. Admins read it through admin_variants (is_admin() inside).
revoke select on public.variants from anon, authenticated;
grant select (id, product_id, sku, size, color, price_cents, active) on public.variants to anon, authenticated;
create view public.admin_variants with (security_barrier = true) as select * from public.variants where public.is_admin();
revoke all on public.admin_variants from public, anon, authenticated;
grant select on public.admin_variants to authenticated;
grant all on public.admin_variants to service_role;

-- 2. get_cart: prices and availability flags only, never quantities.
create or replace function public.get_cart(p_items jsonb) returns jsonb language sql security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('subtotal', c->'subtotal', 'lines', coalesce((
    select jsonb_agg((l - 'avail') || jsonb_build_object('in_stock', case when l ? 'gone' then false else (l->>'avail')::int > 0 end))
      from jsonb_array_elements(c->'lines') l), '[]'::jsonb))
  from (select public._price_cart(p_items, false) c) x
$$;

-- 3. Helpers (internal)
create or replace function public._loc(j jsonb, lang text) returns text language sql immutable set search_path = public, pg_temp as $$
  select coalesce(nullif(j->>lang, ''), nullif(j->>'fr', ''), (select value from jsonb_each_text(j) where value <> '' limit 1), '')
$$;
create or replace function public._cur_cents(p public.products) returns int language sql immutable as $$
  select case when p.sale_price_cents is not null and p.sale_price_cents < p.price_cents then p.sale_price_cents else p.price_cents end
$$;
create or replace function public._variant_ok(p public.products, v public.variants) returns boolean language sql immutable as $$
  select p.available and v.active and (not p.track_stock or v.stock > 0)
$$;
create or replace function public._card(p public.products, lang text) returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'id', p.id, 'slug', p.slug, 'name', public._loc(p.name, lang), 'sku', p.sku,
    'price_cents', public._cur_cents(p), 'old_cents', case when public._cur_cents(p) < p.price_cents then p.price_cents end,
    'available', p.available,
    'in_stock', exists (select 1 from variants v where v.product_id = p.id and public._variant_ok(p, v)),
    'category', (select slug from categories c where c.id = p.category_id),
    'image', (select path from product_images i where i.product_id = p.id order by sort, id limit 1),
    'image_alt', (select public._loc(alt, lang) from product_images i where i.product_id = p.id order by sort, id limit 1))
$$;

-- 4. Public storefront functions. All return JSON; none returns a quantity, a draft product, a hidden variant or private settings.
create or replace function public.store_site(p_lang text default 'fr') returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'settings', coalesce((select jsonb_object_agg(key, value) from settings), '{}'::jsonb),
    'categories', coalesce((select jsonb_agg(jsonb_build_object('slug', slug, 'name', public._loc(name, p_lang), 'description', public._loc(description, p_lang), 'image', image) order by sort, id) from categories where active), '[]'::jsonb),
    'translations', coalesce((select jsonb_object_agg(key, value) from translations where lang = p_lang), '{}'::jsonb))
$$;
create or replace function public.store_page(p_key text, p_lang text default 'fr') returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('title', title, 'blocks', blocks) from pages where key = p_key and lang = p_lang
$$;
create or replace function public.store_catalog(p_lang text default 'fr', p_category text default null, p_q text default null, p_featured boolean default false,
                                                p_size text default null, p_sort text default null, p_limit int default 48, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare pat text; res jsonb; tot int; sizes jsonb;
begin
  p_limit := least(greatest(coalesce(p_limit, 48), 1), 100); p_offset := greatest(coalesce(p_offset, 0), 0);
  pat := case when nullif(btrim(p_q), '') is null then null else '%' || replace(replace(replace(left(btrim(p_q), 60), '\', '\\'), '%', '\%'), '_', '\_') || '%' end;
  with f as (
    select p.* from products p
     where p.status = 'published'
       and (p_category is null or p.category_id = (select id from categories where slug = p_category and active))
       and (not coalesce(p_featured, false) or p.featured)
       and (p_size is null or exists (select 1 from variants v where v.product_id = p.id and v.active and v.size = p_size))
       and (pat is null or p.name::text ilike pat or p.description::text ilike pat or coalesce(p.sku, '') ilike pat)
  )
  select count(*) into tot from f;
  with f as (
    select p.* from products p
     where p.status = 'published'
       and (p_category is null or p.category_id = (select id from categories where slug = p_category and active))
       and (not coalesce(p_featured, false) or p.featured)
       and (p_size is null or exists (select 1 from variants v where v.product_id = p.id and v.active and v.size = p_size))
       and (pat is null or p.name::text ilike pat or p.description::text ilike pat or coalesce(p.sku, '') ilike pat)
     order by case when p_sort = 'asc' then public._cur_cents(p) end asc, case when p_sort = 'desc' then public._cur_cents(p) end desc, p.sort, p.id desc
     limit p_limit offset p_offset)
  select coalesce(jsonb_agg(public._card(f, p_lang)), '[]'::jsonb) into res from f;
  select coalesce(jsonb_agg(s order by s), '[]'::jsonb) into sizes from (select distinct v.size s from variants v join products p on p.id = v.product_id
     where p.status = 'published' and v.active and v.size is not null and (p_category is null or p.category_id = (select id from categories where slug = p_category and active))) z;
  return jsonb_build_object('items', res, 'total', tot, 'sizes', sizes);
end $$;
create or replace function public.store_product(p_slug text, p_lang text default 'fr') returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare p public.products; r jsonb;
begin
  select * into p from products where slug = p_slug and status = 'published';
  if not found then return null; end if;
  r := public._card(p, p_lang) || jsonb_build_object(
    'description', public._loc(p.description, p_lang), 'specs', public._loc(p.specs, p_lang),
    'category_name', (select public._loc(name, p_lang) from categories c where c.id = p.category_id),
    'seo_title', public._loc(p.seo->'title', p_lang), 'seo_desc', public._loc(p.seo->'desc', p_lang), 'og_image', p.seo->>'og_image',
    'images', coalesce((select jsonb_agg(jsonb_build_object('path', path, 'alt', public._loc(alt, p_lang)) order by sort, id) from product_images where product_id = p.id), '[]'::jsonb),
    'variants', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'sku', coalesce(v.sku, p.sku), 'size', v.size, 'color', v.color,
                          'price_cents', coalesce(v.price_cents, public._cur_cents(p)), 'in_stock', public._variant_ok(p, v)) order by v.id)
                          from variants v where v.product_id = p.id and v.active), '[]'::jsonb));
  return r;
end $$;
create or replace function public.store_sitemap() returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object('categories', coalesce((select jsonb_agg(slug order by sort, id) from categories where active), '[]'::jsonb),
                            'products', coalesce((select jsonb_agg(jsonb_build_object('slug', slug, 'updated', updated_at) order by id) from products where status = 'published'), '[]'::jsonb))
$$;
-- Checkout info for the form: which methods are on + public instructions + delivery fee. Bank account details are only given AFTER an order exists.
create or replace function public.store_checkout(p_lang text default 'fr') returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'methods', coalesce((select jsonb_agg(jsonb_build_object('key', m, 'instructions', public._loc(s.value->m->'instructions', p_lang)) order by m)
                           from private_settings s, unnest(array['bank','cod']) m where s.key = 'payments' and coalesce((s.value->m->>'enabled')::boolean, false)), '[]'::jsonb),
    'delivery', (select value - 'note' || jsonb_build_object('note', public._loc(value->'note', p_lang)) from settings where key = 'delivery'))
$$;

-- 5. Permissions (re-assert everything: default privileges would otherwise re-grant)
revoke all on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
grant execute on function public.is_admin(), public.is_owner(), public.get_cart(jsonb) to anon, authenticated;
grant execute on function public.store_site(text), public.store_page(text, text), public.store_catalog(text, text, text, boolean, text, text, int, int),
  public.store_product(text, text), public.store_sitemap(), public.store_checkout(text) to anon, authenticated;
grant execute on function public.set_order_status(bigint, text, boolean), public.adjust_stock(bigint, int, text), public.anonymize_customer(bigint), public.duplicate_product(bigint) to authenticated;
grant execute on function public._check_urls(jsonb) to authenticated;
