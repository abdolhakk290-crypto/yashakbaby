-- Phase 3: admin API. Every function re-checks is_admin() itself (defence in depth: even a bug in the website code cannot let a non-admin use them),
-- is SECURITY DEFINER with a pinned search_path, and is executable by `authenticated` only. Validation errors use YB422 (detail = {field: reason}).

create or replace function public._require_admin() returns void language plpgsql stable security definer set search_path = public, pg_temp as $$
begin if not public.is_admin() then raise exception 'Not allowed' using errcode = 'YB403'; end if; end $$;

create or replace function public._clean_i18n(j jsonb, maxlen int) returns jsonb language sql immutable set search_path = public, pg_temp as $$
  select coalesce(jsonb_object_agg(k, left(btrim(v), maxlen)), '{}'::jsonb)
    from jsonb_each_text(case when jsonb_typeof(j) = 'object' then j else '{}'::jsonb end) e(k, v)
   where k in ('ary','ar','zgh','fr','en','es') and btrim(v) <> ''
$$;
create or replace function public._slugify(s text) returns text language sql immutable set search_path = public, pg_temp as $$
  select coalesce(nullif(btrim(regexp_replace(lower(translate(coalesce(s, ''), 'àâäáãåçéèêëíìîïñóòôöõúùûüýÿÀÂÄÁÃÅÇÉÈÊËÍÌÎÏÑÓÒÔÖÕÚÙÛÜÝ', 'aaaaaaceeeeiiiinooooouuuuyyaaaaaaceeeeiiiinooooouuuuy')), '[^a-z0-9]+', '-', 'g'), '-'), ''), 'item')
$$;
create or replace function public._unique_slug(tbl text, base text, except_id bigint) returns text language plpgsql set search_path = public, pg_temp as $$
declare cand text := left(base, 60); n int := 1; clash boolean;
begin
  loop
    execute format('select exists (select 1 from public.%I where slug = $1 and id is distinct from $2)', tbl) into clash using cand, except_id;
    exit when not clash; n := n + 1; cand := left(base, 55) || '-' || n;
  end loop; return cand;
end $$;

-- ---------- dashboard ----------
create or replace function public.admin_dashboard() returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  return jsonb_build_object(
    'published', (select count(*) from products where status = 'published'), 'drafts', (select count(*) from products where status = 'draft'),
    'unavailable', (select count(*) from products where status = 'published' and not available), 'categories', (select count(*) from categories),
    'orders_pending', (select count(*) from orders where status = 'pending'),
    'whatsapp_ok', coalesce((select (value->>'enabled')::boolean and coalesce(value->>'number', '') <> '' from settings where key = 'whatsapp'), false));
end $$;

-- ---------- products ----------
create or replace function public.admin_list_products(p_q text default null, p_status text default null, p_category bigint default null) returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare pat text := case when nullif(btrim(p_q), '') is null then null else '%' || replace(replace(replace(left(btrim(p_q), 60), '\', '\\'), '%', '\%'), '_', '\_') || '%' end;
begin
  perform public._require_admin();
  return coalesce((select jsonb_agg(x order by (x->>'sort')::int, (x->>'id')::bigint desc) from (
    select jsonb_build_object('id', p.id, 'slug', p.slug, 'name', p.name, 'price_cents', p.price_cents, 'sale_price_cents', p.sale_price_cents, 'sku', p.sku, 'status', p.status, 'available', p.available,
      'featured', p.featured, 'sort', p.sort, 'category_id', p.category_id, 'category', (select name from categories c where c.id = p.category_id),
      'image', (select path from product_images i where i.product_id = p.id order by i.sort, i.id limit 1),
      'variants', (select count(*) from variants v where v.product_id = p.id), 'track_stock', p.track_stock,
      'stock_total', (select coalesce(sum(v.stock), 0) from variants v where v.product_id = p.id and v.active), 'updated_at', p.updated_at) x
    from products p
    where (p_status is null or p.status = p_status) and (p_category is null or p.category_id = p_category)
      and (pat is null or p.name::text ilike pat or coalesce(p.sku, '') ilike pat or p.slug ilike pat)) z), '[]'::jsonb);
end $$;

create or replace function public.admin_get_product(p_id bigint) returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare p public.products;
begin
  perform public._require_admin();
  select * into p from products where id = p_id; if not found then raise exception 'Product not found' using errcode = 'YB404'; end if;
  return to_jsonb(p) || jsonb_build_object(
    'variants', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'sku', v.sku, 'size', v.size, 'color', v.color, 'price_cents', v.price_cents, 'stock', v.stock, 'active', v.active) order by v.id) from variants v where v.product_id = p.id), '[]'::jsonb),
    'images', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'path', i.path, 'alt', i.alt) order by i.sort, i.id) from product_images i where i.product_id = p.id), '[]'::jsonb));
end $$;

create or replace function public.admin_save_product(p jsonb) returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  pid bigint := nullif(p->>'id', '')::bigint; errs jsonb := '{}'; nm jsonb; descr jsonb; sp jsonb; price int; sale int; cat bigint; st text; v_slug text; v_sku text;
  avail boolean; feat boolean; track boolean; v jsonb; vid bigint; keep bigint[] := '{}'; vsize text; vcolor text; vsku text; vprice int; vstock int; vactive boolean; has_variants boolean := p ? 'variants'; want_status text; cur public.products;
begin
  perform public._require_admin();
  if pid is not null then select * into cur from products where id = pid; if not found then raise exception 'Product not found' using errcode = 'YB404'; end if; end if;
  nm := public._clean_i18n(case when p ? 'name' then p->'name' else cur.name end, 200); descr := public._clean_i18n(case when p ? 'description' then p->'description' else coalesce(cur.description, '{}') end, 5000); sp := public._clean_i18n(case when p ? 'specs' then p->'specs' else coalesce(cur.specs, '{}') end, 2000);
  if nm = '{}' then errs := errs || '{"name":"required"}'; end if;
  begin price := case when p ? 'price_cents' then (p->>'price_cents')::numeric::int else cur.price_cents end; exception when others then price := null; end;
  if price is null or price < 0 or price > 100000000 then errs := errs || '{"price":"invalid"}'; end if;
  begin sale := case when p ? 'sale_price_cents' then nullif(p->>'sale_price_cents', '')::numeric::int else cur.sale_price_cents end; exception when others then sale := -1; end;
  if sale is not null and (sale < 0 or price is null or sale >= price) then errs := errs || '{"sale_price":"must be lower than the price"}'; end if;
  cat := case when p ? 'category_id' then nullif(p->>'category_id', '')::bigint else cur.category_id end;
  if cat is not null and not exists (select 1 from categories where id = cat) then errs := errs || '{"category":"unknown"}'; end if;
  want_status := coalesce(p->>'status', cur.status, 'draft'); if want_status not in ('draft','published','archived') then errs := errs || '{"status":"invalid"}'; end if;
  avail := coalesce((p->>'available')::boolean, cur.available, true); feat := coalesce((p->>'featured')::boolean, cur.featured, false); track := coalesce((p->>'track_stock')::boolean, cur.track_stock, false);
  v_sku := case when p ? 'sku' then nullif(left(btrim(p->>'sku'), 60), '') else cur.sku end;
  v_slug := nullif(btrim(coalesce(p->>'slug', '')), '');
  if v_slug is not null and v_slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$' then errs := errs || '{"slug":"invalid"}'; end if;
  if has_variants then
    if jsonb_typeof(p->'variants') <> 'array' or jsonb_array_length(p->'variants') > 60 then errs := errs || '{"variants":"invalid"}';
    else for v in select * from jsonb_array_elements(p->'variants') loop
      begin
        vstock := coalesce(nullif(v->>'stock', '')::numeric, 0)::int; vprice := nullif(v->>'price_cents', '')::numeric::int;
        if vstock < 0 or vstock > 1000000 or (vprice is not null and (vprice < 0 or vprice > 100000000)) or length(coalesce(v->>'size', '')) > 40 or length(coalesce(v->>'color', '')) > 40 then errs := errs || '{"variants":"invalid values"}'; end if;
      exception when others then errs := errs || '{"variants":"invalid values"}'; end;
    end loop; end if;
  end if;
  if errs <> '{}' then raise exception 'Please check the form.' using errcode = 'YB422', detail = errs::text; end if;

  if pid is null then
    v_slug := public._unique_slug('products', coalesce(v_slug, public._slugify(coalesce(nm->>'fr', nm->>'en', (select value from jsonb_each_text(nm) limit 1)))), null);
    insert into products(slug, category_id, name, description, specs, price_cents, sale_price_cents, sku, status, featured, available, track_stock, sort)
    values (v_slug, cat, nm, descr, sp, price, sale, v_sku, 'draft', feat, avail, track, coalesce((select min(sort) from products), 1) - 1) returning id into pid;
  elsif v_slug is not null and v_slug is distinct from cur.slug then
    if exists (select 1 from products where products.slug = v_slug and products.id <> pid) then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"slug":"already used"}'; end if;
  end if;

  if has_variants then
    for v in select * from jsonb_array_elements(p->'variants') loop
      vid := nullif(v->>'id', '')::bigint; vsize := nullif(btrim(coalesce(v->>'size', '')), ''); vcolor := nullif(btrim(coalesce(v->>'color', '')), ''); vsku := nullif(btrim(coalesce(v->>'sku', '')), '');
      vprice := nullif(v->>'price_cents', '')::numeric::int; vstock := coalesce(nullif(v->>'stock', '')::numeric, 0)::int; vactive := coalesce((v->>'active')::boolean, true);
      if vid is not null and exists (select 1 from variants where id = vid and product_id = pid) then
        update variants set size = vsize, color = vcolor, sku = vsku, price_cents = vprice, stock = vstock, active = vactive where id = vid;
      else insert into variants(product_id, size, color, sku, price_cents, stock, active) values (pid, vsize, vcolor, vsku, vprice, vstock, vactive) returning id into vid; end if;
      keep := keep || vid;
    end loop;
    delete from variants where product_id = pid and not (id = any(keep));
  end if;
  if not exists (select 1 from variants where product_id = pid) then insert into variants(product_id, stock, active) values (pid, 0, true); end if;   -- a product without sizes still has one buyable "variant"

  update products set category_id = cat, name = nm, description = descr, specs = sp, price_cents = price, sale_price_cents = sale, sku = v_sku, status = want_status, featured = feat, available = avail, track_stock = track,
         slug = coalesce(v_slug, products.slug)
   where products.id = pid;
  return (select jsonb_build_object('id', products.id, 'slug', products.slug) from products where products.id = pid);
exception when unique_violation then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"sku":"already used by another product"}';
end $$;

create or replace function public.admin_patch_product(p_id bigint, p jsonb) returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  if p ? 'status' and (p->>'status') not in ('draft','published','archived') then raise exception 'Invalid status' using errcode = 'YB422'; end if;
  update products set status = coalesce(p->>'status', status), available = coalesce((p->>'available')::boolean, available), featured = coalesce((p->>'featured')::boolean, featured) where id = p_id;
  if not found then raise exception 'Product not found' using errcode = 'YB404'; end if;
end $$;

create or replace function public.admin_delete_product(p_id bigint) returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare paths jsonb;
begin
  perform public._require_admin();
  select coalesce(jsonb_agg(path), '[]'::jsonb) into paths from product_images where product_id = p_id and path ~ '^products/';
  delete from products where id = p_id; if not found then raise exception 'Product not found' using errcode = 'YB404'; end if;
  return paths;   -- the website then removes these files from storage
end $$;

create or replace function public.admin_duplicate_product(p_id bigint) returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
begin perform public._require_admin(); return public.duplicate_product(p_id); end $$;

create or replace function public.admin_order_products(p_ids bigint[]) returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  update products p set sort = o.n::int from unnest(p_ids) with ordinality o(id, n) where p.id = o.id;
end $$;

-- ---------- product photos ----------
create or replace function public.admin_add_image(p_product bigint, p_path text, p_alt jsonb default '{}') returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
declare nid bigint;
begin
  perform public._require_admin();
  if p_path !~ '^products/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp|gif)$' then raise exception 'Invalid image path' using errcode = 'YB422'; end if;
  if not exists (select 1 from products where id = p_product) then raise exception 'Product not found' using errcode = 'YB404'; end if;
  if (select count(*) from product_images where product_id = p_product) >= 12 then raise exception 'A product can have at most 12 photos.' using errcode = 'YB422', detail = '{"images":"max 12"}'; end if;
  insert into product_images(product_id, path, alt, sort) values (p_product, p_path, public._clean_i18n(p_alt, 200), coalesce((select max(sort) + 1 from product_images where product_id = p_product), 0)) returning id into nid;
  return nid;
end $$;
create or replace function public.admin_remove_image(p_id bigint) returns text language plpgsql security definer set search_path = public, pg_temp as $$
declare pth text;
begin
  perform public._require_admin();
  delete from product_images where id = p_id returning path into pth; if not found then raise exception 'Photo not found' using errcode = 'YB404'; end if;
  return case when pth ~ '^products/' then pth end;   -- storage object to delete (files shipped with the site are never deleted)
end $$;
create or replace function public.admin_order_images(p_product bigint, p_ids bigint[]) returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  update product_images i set sort = o.n::int - 1 from unnest(p_ids) with ordinality o(id, n) where i.id = o.id and i.product_id = p_product;
end $$;

-- ---------- categories ----------
create or replace function public.admin_list_categories() returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  return coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'slug', c.slug, 'name', c.name, 'description', c.description, 'image', c.image, 'sort', c.sort, 'active', c.active,
                   'products', (select count(*) from products p where p.category_id = c.id)) order by c.sort, c.id) from categories c), '[]'::jsonb);
end $$;
create or replace function public.admin_save_category(p jsonb) returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare cid bigint := nullif(p->>'id', '')::bigint; nm jsonb; descr jsonb; v_slug text := nullif(btrim(coalesce(p->>'slug', '')), ''); img text; cur public.categories;
begin
  perform public._require_admin();
  if cid is not null then select * into cur from categories where id = cid; if not found then raise exception 'Category not found' using errcode = 'YB404'; end if; end if;
  nm := public._clean_i18n(case when p ? 'name' then p->'name' else cur.name end, 100); descr := public._clean_i18n(case when p ? 'description' then p->'description' else coalesce(cur.description, '{}') end, 500);
  img := case when p ? 'image' then nullif(btrim(p->>'image'), '') else cur.image end;
  if nm = '{}' then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"name":"required"}'; end if;
  if img is not null and img !~ '^(/[A-Za-z0-9/_.-]+|(products|site)/[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp|gif))$' then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"image":"invalid"}'; end if;
  if v_slug is not null and v_slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$' then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"slug":"invalid"}'; end if;
  if cid is null then
    v_slug := public._unique_slug('categories', coalesce(v_slug, public._slugify(coalesce(nm->>'fr', nm->>'en', (select value from jsonb_each_text(nm) limit 1)))), null);
    insert into categories(slug, name, description, image, sort, active) values (v_slug, nm, descr, img, coalesce((select max(sort) + 1 from categories), 0), coalesce((p->>'active')::boolean, true)) returning id into cid;
  else
    if v_slug is not null and v_slug <> cur.slug and exists (select 1 from categories where categories.slug = v_slug and categories.id <> cid) then raise exception 'Please check the form.' using errcode = 'YB422', detail = '{"slug":"already used"}'; end if;
    update categories set name = nm, description = descr, image = img, slug = coalesce(v_slug, categories.slug), active = coalesce((p->>'active')::boolean, categories.active) where categories.id = cid;
  end if;
  return (select jsonb_build_object('id', categories.id, 'slug', categories.slug) from categories where categories.id = cid);
end $$;
create or replace function public.admin_delete_category(p_id bigint, p_move_to bigint default null) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  perform public._require_admin();
  if not exists (select 1 from categories where id = p_id) then raise exception 'Category not found' using errcode = 'YB404'; end if;
  select count(*) into n from products where category_id = p_id;
  if n > 0 and p_move_to is null then raise exception 'This category still has products. Move them to another category first.' using errcode = 'YB409', detail = jsonb_build_object('products', n)::text; end if;
  if p_move_to = p_id then raise exception 'Choose a different category.' using errcode = 'YB422'; end if;
  if p_move_to is not null then
    if not exists (select 1 from categories where id = p_move_to) then raise exception 'Target category not found' using errcode = 'YB404'; end if;
    update products set category_id = p_move_to where category_id = p_id;
  end if;
  delete from categories where id = p_id;
end $$;
create or replace function public.admin_order_categories(p_ids bigint[]) returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin perform public._require_admin(); update categories c set sort = o.n::int from unnest(p_ids) with ordinality o(id, n) where c.id = o.id; end $$;

-- ---------- site settings (contact, WhatsApp, homepage, SEO, legal switch) ----------
create or replace function public.admin_get_settings() returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
begin perform public._require_admin(); return coalesce((select jsonb_object_agg(key, value) from settings), '{}'::jsonb); end $$;
create or replace function public.admin_save_setting(p_key text, p_value jsonb) returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare n text;
begin
  perform public._require_admin();
  if p_key = 'whatsapp' and jsonb_typeof(p_value) = 'object' then
    n := regexp_replace(coalesce(p_value->>'number', ''), '\D', '', 'g'); n := regexp_replace(n, '^00', '');
    if n <> '' and n ~ '^0' then raise exception 'Use the international format without 0 or +, for example 212601668146' using errcode = 'YB422', detail = '{"number":"international format required"}'; end if;
    p_value := jsonb_set(p_value, '{number}', to_jsonb(n));
  end if;
  insert into settings(key, value) values (p_key, p_value) on conflict (key) do update set value = excluded.value, updated_at = now();
end $$;

-- ---------- orders (minimal: look and set status; no exports, no notes) ----------
create or replace function public.admin_list_orders(p_limit int default 50, p_offset int default 0) returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform public._require_admin();
  return coalesce((select jsonb_agg(x) from (select jsonb_build_object('id', o.id, 'number', o.number, 'status', o.status, 'name', o.name, 'phone', o.phone, 'city', o.city, 'total_cents', o.total_cents, 'created_at', o.created_at,
      'payment_method', o.payment_method, 'items', (select coalesce(sum(qty), 0) from order_items i where i.order_id = o.id)) x from orders o order by o.id desc limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)) z), '[]'::jsonb);
end $$;
create or replace function public.admin_get_order(p_id bigint) returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare o public.orders;
begin
  perform public._require_admin(); select * into o from orders where id = p_id; if not found then raise exception 'Order not found' using errcode = 'YB404'; end if;
  return to_jsonb(o) || jsonb_build_object('items', coalesce((select jsonb_agg(to_jsonb(i) order by i.id) from order_items i where i.order_id = o.id), '[]'::jsonb));
end $$;

-- ---------- permissions: re-assert everything ----------
revoke all on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
grant execute on function public.is_admin(), public.is_owner(), public.get_cart(jsonb) to anon, authenticated;
grant execute on function public.store_site(text), public.store_page(text, text), public.store_catalog(text, text, text, boolean, text, text, int, int),
  public.store_product(text, text), public.store_sitemap(), public.store_checkout(text) to anon, authenticated;
grant execute on function public.set_order_status(bigint, text, boolean), public.adjust_stock(bigint, int, text), public.anonymize_customer(bigint), public.duplicate_product(bigint) to authenticated;
grant execute on function public._check_urls(jsonb) to authenticated;
grant execute on function public.admin_dashboard(), public.admin_list_products(text, text, bigint), public.admin_get_product(bigint), public.admin_save_product(jsonb), public.admin_patch_product(bigint, jsonb),
  public.admin_delete_product(bigint), public.admin_duplicate_product(bigint), public.admin_order_products(bigint[]), public.admin_add_image(bigint, text, jsonb), public.admin_remove_image(bigint),
  public.admin_order_images(bigint, bigint[]), public.admin_list_categories(), public.admin_save_category(jsonb), public.admin_delete_category(bigint, bigint), public.admin_order_categories(bigint[]),
  public.admin_get_settings(), public.admin_save_setting(text, jsonb), public.admin_list_orders(int, int), public.admin_get_order(bigint) to authenticated;
