#!/bin/sh
# Production build with the (non-secret) local test Supabase address baked in. Run before tests/http.test.mjs / ui.test.mjs / admin.test.mjs.
cd "$(dirname "$0")/.." && eval "$(node -e "import('./tests/lib/env.mjs').then(m=>{for(const [k,v] of Object.entries(m.BUILD_ENV))console.log('export '+k+'='+JSON.stringify(v))})")" && npx next build
