// Database security + business-logic tests on a REAL PostgreSQL 16 (Supabase shim for auth/storage schemas).
// RLS is enforced exactly like PostgREST does it: `SET ROLE anon|authenticated|service_role` + request.jwt.claims.
import pg from 'pg'; import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url';
const __dir = path.dirname(fileURLToPath(import.meta.url)), ROOT = path.join(__dir, '..');
import { execFileSync } from 'child_process'; try { execFileSync('sh', [path.join(__dir, 'start-pg.sh')], { stdio: 'ignore' }); } catch { /* already running */ }
const CONN = { host: process.env.PGHOST || '/tmp', port: +(process.env.PGPORT || 54329), user: process.env.PGUSER || 'postgres' };
const DBN = 'yb_test';
const admin = new pg.Client({ ...CONN, database: 'postgres' }); await admin.connect();
await admin.query(`drop database if exists ${DBN} with (force)`); await admin.query(`create database ${DBN}`); await admin.end();
const pool = new pg.Pool({ ...CONN, database: DBN, max: 24 });
const sqlFiles = ['db/support/00-supabase-shim.sql', ...fs.readdirSync(path.join(ROOT, 'supabase/migrations')).sort().map(f => 'supabase/migrations/' + f), 'supabase/seed.sql'];
for (const f of sqlFiles) { try { await pool.query(fs.readFileSync(path.join(ROOT, f), 'utf8')); } catch (e) { console.error('MIGRATION FAILED', f, e.message); process.exit(2); } }

if (process.env.YB_MUTATE_SQL) await pool.query(process.env.YB_MUTATE_SQL);   // mutation testing: deliberately break security and confirm the tests notice
const OWNER = '00000000-0000-0000-0000-0000000000a1', ADM = '00000000-0000-0000-0000-0000000000a2', USER = '00000000-0000-0000-0000-0000000000b1';
await pool.query(`insert into auth.users(id,email) values ($1,'owner@t.dev'),($2,'admin@t.dev'),($3,'client@t.dev')`, [OWNER, ADM, USER]);
await pool.query(`insert into public.admins(user_id,role) values ($1,'owner'),($2,'admin')`, [OWNER, ADM]);

// run work as a given API role. mode 'commit' keeps changes; default rolls back.
async function tx(role, uid, fn, commit = false) {
  const c = await pool.connect();
  try {
    await c.query('begin'); await c.query(`set local role ${role}`);
    if (uid || role !== 'anon') await c.query(`select set_config('request.jwt.claims', $1, true)`, [JSON.stringify({ role, ...(uid ? { sub: uid } : {}) })]);
    const r = await fn((s, a) => c.query(s, a));
    await c.query(commit ? 'commit' : 'rollback'); return r;
  } catch (e) { try { await c.query('rollback'); } catch {} throw e; } finally { c.release(); }
}
const q = (role, uid, sql, args, commit = false) => tx(role, uid, async Q => (await Q(sql, args)).rows, commit);
const asAnon = (s, a, c) => q('anon', null, s, a, c), asUser = (s, a, c) => q('authenticated', USER, s, a, c), asAdm = (s, a, c) => q('authenticated', ADM, s, a, c), asOwner = (s, a, c) => q('authenticated', OWNER, s, a, c), asSvc = (s, a, c) => q('service_role', null, s, a, c);
const su = async (s, a) => (await pool.query(s, a)).rows;      // superuser: test setup/inspection only
const err = async p => { try { await p; return null; } catch (e) { return e; } };
const denied = async p => { const e = await err(p); return !!e && (e.code === '42501'); };
const errcode = async p => { const e = await err(p); return e ? e.code : null; };

const results = []; let pass = 0, fail = 0;
async function T(name, covers, fn, partial = []) {
  try { await fn(); pass++; results.push({ name, covers, partial, ok: true }); console.log('  ok  ' + name); }
  catch (e) { fail++; results.push({ name, covers, partial, ok: false, error: e.message }); console.log('FAIL  ' + name + '\n        ' + String(e.message).split('\n')[0]); }
}
const eq = (a, b, m = '') => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const ok = (c, m = 'assertion failed') => { if (!c) throw new Error(m); };
const ORDER = { name: 'Amina Test', phone: '0612345678', city: 'Essaouira', address: 'Rue des tests 12', email: 'a@b.co' };
const place = (body, lang = 'fr') => asSvc('select public.place_order($1::jsonb,$2) r', [JSON.stringify(body), lang], true).then(r => r[0].r);
const stockOf = async id => +(await su('select stock from variants where id=$1', [id]))[0].stock;
const names = (...a) => a;

console.log('\n## Access control (RLS / grants)');
const PRIVATE = ['orders', 'order_items', 'order_notes', 'customers', 'stock_log', 'audit_log', 'private_settings', 'admins', 'rate_limits'];
await T('anonymous visitors cannot read orders (also: dashboard data, order export)', names('GET /api/admin/dashboard requires login (401)', 'GET /api/admin/orders requires login (401)', 'GET /api/admin/orders/export.csv requires login (401)'), async () => { ok(await denied(asAnon('select * from orders'))); ok(await denied(asAnon('select * from order_items'))); });
await T('anonymous visitors cannot read customers (also: customer export)', names('GET /api/admin/customers requires login (401)', 'GET /api/admin/customers/export.csv requires login (401)'), async () => { ok(await denied(asAnon('select * from customers'))); });
await T('anonymous visitors cannot read payment settings / bank details', names('GET /api/admin/settings/payments requires login (401)', 'payment settings not readable by the public'), async () => { ok(await denied(asAnon('select * from private_settings'))); });
await T('anonymous visitors cannot create products', names('POST /api/admin/products requires login (401)'), async () => {
  ok(await denied(asAnon(`insert into products(slug,name,price_cents) values ('x','{"fr":"x"}',100)`)));
});
for (const t of PRIVATE) await T(`private table "${t}": anon and non-admin users get no access`, [], async () => { ok(await denied(asAnon(`select * from ${t}`)), 'anon'); ok(await denied(asUser(`select * from ${t}`)) || (await asUser(`select * from ${t}`)).length === 0, 'user'); });
await T('logged-in NON-admin users have no write access to catalogue, content or settings', [], async () => {
  for (const s of [`insert into products(slug,name,price_cents) values ('x','{"fr":"x"}',100)`, `insert into categories(slug,name) values ('x','{"fr":"x"}')`, `insert into settings(key,value) values ('social','{"instagram":""}')`, `insert into pages(key,lang,title,blocks) values ('x','fr','x','[]')`, `insert into translations(lang,key,value) values ('fr','k','v')`]) ok(await denied(asUser(s)), s);
  eq((await asUser(`update products set price_cents=1 returning id`, [], false)).length, 0);
});
await T('is_admin()/is_owner() are true only for registered admins', [], async () => {
  eq((await asAnon('select is_admin() a')).map(r => r.a), [false]); eq((await asUser('select is_admin() a')).map(r => r.a), [false]);
  eq((await asAdm('select is_admin() a, is_owner() o'))[0], { a: true, o: false }); eq((await asOwner('select is_admin() a, is_owner() o'))[0], { a: true, o: true });
});
await T('nobody can promote themselves to admin; only an owner manages admins', [], async () => {
  ok(await denied(asUser(`insert into admins(user_id,role) values ('${USER}','owner')`)), 'user self-promote');
  ok(await denied(asAdm(`insert into admins(user_id,role) values ('${USER}','admin')`)), 'admin adds admin');
  eq((await asAdm(`update admins set role='owner' where user_id='${ADM}' returning user_id`)).length, 0, 'admin escalates');
  await asOwner(`insert into admins(user_id,role) values ('${USER}','admin')`);   // rolled back
  eq((await asUser('select * from admins')).length, 0, 'plain user sees no admins');
});
await T('function permissions: exact list of who can execute what', [], async () => {
  const rows = await su(`select p.proname, (array_agg(r.rolname order by r.rolname) filter (where has_function_privilege(r.oid, p.oid, 'execute')))::text[] roles
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join (select oid, rolname from pg_roles where rolname in ('anon','authenticated','service_role')) r
    where n.nspname='public' and p.prokind='f' group by p.proname order by 1`);
  const got = Object.fromEntries(rows.map(r => [r.proname, r.roles || []]));
  const pubAuth = ['anon', 'authenticated', 'service_role'], authOnly = ['authenticated', 'service_role'], svc = ['service_role'];
  const want = { is_admin: pubAuth, is_owner: pubAuth, get_cart: pubAuth, set_order_status: authOnly, adjust_stock: authOnly, anonymize_customer: authOnly, duplicate_product: authOnly, store_site: pubAuth, store_page: pubAuth, store_catalog: pubAuth, store_product: pubAuth, store_sitemap: pubAuth, store_checkout: pubAuth, _loc: svc, _cur_cents: svc, _variant_ok: svc, _card: svc, place_order: svc, rate_hit: svc, _price_cart: svc, _delivery_for: svc, _enabled_methods: svc, _check_urls: authOnly, audit_change: svc, log_stock_change: svc, orders_guard: svc, touch_updated_at: svc, validate_product: svc, validate_setting: svc, admin_dashboard: authOnly, admin_list_products: authOnly, admin_get_product: authOnly, admin_save_product: authOnly, admin_patch_product: authOnly, admin_delete_product: authOnly, admin_duplicate_product: authOnly, admin_order_products: authOnly, admin_add_image: authOnly, admin_remove_image: authOnly, admin_order_images: authOnly, admin_list_categories: authOnly, admin_save_category: authOnly, admin_delete_category: authOnly, admin_order_categories: authOnly, admin_get_settings: authOnly, admin_save_setting: authOnly, admin_list_orders: authOnly, admin_get_order: authOnly, _require_admin: svc, _clean_i18n: svc, _slugify: svc, _unique_slug: svc };
  for (const [f, roles] of Object.entries(want)) eq(got[f], roles, f);
  for (const f of Object.keys(got)) ok(f in want, 'unlisted function ' + f);
});
await T('every SECURITY DEFINER function pins its search_path (no hijacking)', [], async () => {
  const rows = await su(`select proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and prosecdef and not coalesce(proconfig::text,'') like '%search_path%'`);
  eq(rows, []);
});
await T('anonymous and customers cannot place orders directly, cannot use rate limiter or internal helpers', [], async () => {
  ok(await denied(asAnon(`select place_order('{}'::jsonb,'fr')`))); ok(await denied(asUser(`select place_order('{}'::jsonb,'fr')`)));
  ok(await denied(asAnon(`select rate_hit('k',1,60)`))); ok(await denied(asAnon(`select _price_cart('[]'::jsonb,true)`)));
  ok(await denied(asAnon(`insert into orders(number,name,phone,address,city,subtotal_cents,total_cents) values ('X','a','b','c','d',1,1)`)));
  ok(await denied(asAdm(`insert into orders(number,name,phone,address,city,subtotal_cents,total_cents) values ('X','a','b','c','d',1,1)`)), 'even admins create orders only through place_order');
});
await T('audit log, stock log, orders and customers cannot be deleted or rewritten via the API, even by admins', [], async () => {
  for (const s of ['delete from audit_log', 'update audit_log set action=\'x\'', 'delete from stock_log', 'insert into stock_log(variant_id,delta,reason) values (1,1,\'x\')', 'delete from orders', 'delete from customers', 'delete from order_items', 'insert into audit_log(action) values (\'fake\')', 'update rate_limits set hits=0']) ok(await denied(asAdm(s)), s);
});

console.log('\n## Catalogue');
await T('seed: three categories, store settings, no products / variants / orders / customers', names('3 seeded categories'), async () => {
  const c = await asAnon('select slug from categories order by sort'); eq(c.map(x => x.slug), ['gifts', 'clothing', 'mother']);
  for (const t of ['products', 'variants', 'orders', 'customers', 'product_images']) eq(+(await su(`select count(*)::int n from ${t}`))[0].n, 0, t);
  const s = (await asAnon(`select value from settings where key='store'`))[0].value; eq([s.name, s.email, s.phone, s.currency], ['YASHAK BABY', 'babyyashak@gmail.com', '0601668146', 'MAD']);
  const w = (await asAnon(`select value from settings where key='whatsapp'`))[0].value; eq(w.number, '212601668146');
  eq((await su(`select value->'online'->>'enabled' e, value->'bank'->>'enabled' b, value->'cod'->>'enabled' c from private_settings where key='payments'`))[0], { e: 'false', b: 'false', c: 'false' });
});
const catId = +(await su(`select id from categories where slug='gifts'`))[0].id;
const P = (o = {}) => ({ slug: 'coffret', name: '{"fr":"Coffret","en":"Box"}', price: 15000, ...o });
const mkProduct = async (o = {}) => { const p = P(o); return +(await asAdm(`insert into products(slug,name,price_cents,sale_price_cents,sku,category_id,status,track_stock,available) values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning id`, [p.slug, p.name, p.price, p.sale ?? null, p.sku ?? null, catId, p.status ?? 'draft', p.track ?? true, p.available ?? true], true))[0].id; };
const mkVariant = async (pid, o = {}) => +(await asAdm(`insert into variants(product_id,sku,size,color,price_cents,stock,active) values ($1,$2,$3,$4,$5,$6,$7) returning id`, [pid, o.sku ?? null, o.size ?? null, o.color ?? null, o.price ?? null, o.stock ?? 0, o.active ?? true], true))[0].id;
await T('database refuses invalid products: sale ≥ price, empty name, duplicate SKU, negative price, bad slug, negative stock', names('sale price above price refused', 'missing name refused', 'duplicate SKU refused'), async () => {
  ok(await errcode(asAdm(`insert into products(slug,name,price_cents,sale_price_cents) values ('a','{"fr":"a"}',100,200)`)) === '23514', 'sale>price');
  ok(await errcode(asAdm(`insert into products(slug,name,price_cents) values ('a','{}',100)`)) === '23514', 'empty name');
  ok(await errcode(asAdm(`insert into products(slug,name,price_cents) values ('a','"text"',100)`)) === '23514', 'name not object');
  ok(await errcode(asAdm(`insert into products(slug,name,price_cents) values ('a','{"fr":"a"}',-5)`)) === '23514', 'negative');
  ok(await errcode(asAdm(`insert into products(slug,name,price_cents) values ('Bad Slug!','{"fr":"a"}',5)`)) === '23514', 'slug');
  const p = await mkProduct({ slug: 'dupsku' }); await mkVariant(p, { sku: 'DUP' });
  ok(await errcode(asAdm(`insert into variants(product_id,sku) values ($1,'DUP')`, [p])) === '23505', 'dup sku');
  ok(await errcode(asAdm(`insert into variants(product_id,stock) values ($1,-1)`, [p])) === '23514', 'neg stock');
  await asAdm('delete from products where id=$1', [p], true);
});
let PID, VS, VM;
await T('admin creates a product: draft by default, with variants', names('product created as draft'), async () => {
  PID = await mkProduct({ slug: 'coffret-naissance', sale: 12000, sku: 'SKU-1' }); VS = await mkVariant(PID, { size: 'S', color: 'Rose', sku: 'SKU-1-S', stock: 2 }); VM = await mkVariant(PID, { size: 'M', color: 'Rose', sku: 'SKU-1-M', stock: 1 });
  eq((await asAdm('select status from products where id=$1', [PID]))[0].status, 'draft');
});
await T('draft product, its variants and images are invisible to the public; admins can preview them', names('draft product is invisible to the public (404)'), async () => {
  await asAdm(`insert into product_images(product_id,path,alt) values ($1,'products/a.png','{}')`, [PID], true);
  eq((await asAnon('select id from products where id=$1', [PID])).length, 0); eq((await asAnon('select id from variants where product_id=$1', [PID])).length, 0); eq((await asAnon('select id from product_images where product_id=$1', [PID])).length, 0);
  eq((await asUser('select id from products where id=$1', [PID])).length, 0, 'logged-in customer');
  eq((await asAdm('select id from products where id=$1', [PID])).length, 1);
}, names('admin preview shows the draft'));
await T('draft products cannot be bought or priced by the public', [], async () => { const c = (await asAnon(`select get_cart($1::jsonb) c`, [JSON.stringify([{ v: VS, q: 1 }])]))[0].c; eq(c.lines[0].gone, true); eq(c.subtotal, 0); });
await T('a product cannot be published without an active variant', [], async () => {
  const p = await mkProduct({ slug: 'novariant' }); ok(await errcode(asAdm(`update products set status='published' where id=$1`, [p])) === 'YB422'); await asAdm('delete from products where id=$1', [p], true);
});
await T('publish: public can now read product, active variants and images; inactive variants stay hidden', names('publish product', 'published product visible'), async () => {
  await asAdm(`update products set status='published' where id=$1`, [PID], true);
  const inactive = await mkVariant(PID, { size: 'XL', stock: 5, active: false });
  eq((await asAnon('select slug,price_cents,sale_price_cents from products where id=$1', [PID]))[0], { slug: 'coffret-naissance', price_cents: 15000, sale_price_cents: 12000 });
  eq((await asAnon('select size from variants where product_id=$1 order by id', [PID])).map(r => r.size), ['S', 'M']); eq((await asAnon('select 1 from product_images where product_id=$1', [PID])).length, 1);
  await asAdm('delete from variants where id=$1', [inactive], true);
}, names('price + sale shown, JSON-LD present', 'published product in sitemap'));
await T('archiving hides a product again', names('archived product hidden'), async () => {
  await asAdm(`update products set status='archived' where id=$1`, [PID], true); eq((await asAnon('select 1 from products where id=$1', [PID])).length, 0);
  await asAdm(`update products set status='published' where id=$1`, [PID], true);
});
await T('product links/images in SEO fields must be https:// or /  (no javascript:)', [], async () => { ok(await errcode(asAdm(`update products set seo='{"og_image":"javascript:alert(1)"}' where id=$1`, [PID])) === 'YB422'); await asAdm(`update products set seo='{"og_image":"/uploads/a.png","canonical":"https://yashakbaby.online/fr/p/x"}' where id=$1`, [PID]); });
await T('image paths cannot contain traversal or odd characters', [], async () => { for (const p of ['../x.png', 'a/../b.png', 'a b.png', '<x>.png', '']) ok(await errcode(asAdm(`insert into product_images(product_id,path) values ($1,$2)`, [PID, p])) === '23514', p); });
await T('a category that still has products cannot be deleted; an empty one can', names('category with products cannot be deleted'), async () => {
  ok(await errcode(asAdm('delete from categories where id=$1', [catId])) === '23503');
  const c = (await asAdm(`insert into categories(slug,name) values ('tmp','{"fr":"t"}') returning id`))[0].id; ok(c > 0);
});
await T('duplicate product → draft, no stock, no SKU, copy of name', names('duplicate product → draft', 'duplicate is draft with no stock and fresh SKU'), async () => {
  const id = (await asAdm('select duplicate_product($1) id', [PID], true))[0].id; const d = (await su('select * from products where id=$1', [id]))[0];
  eq([d.status, d.featured, d.sku, d.name.fr], ['draft', false, null, 'Coffret (copy)']); const v = await su('select sku,stock from variants where product_id=$1', [id]); eq(v.length, 2); ok(v.every(x => x.stock === 0 && x.sku === null));
  ok(await errcode(asUser('select duplicate_product($1)', [PID])) === 'YB403');
  await asAdm('delete from products where id=$1', [id], true);
});

console.log('\n## Orders, stock, concurrency');
await T('get_cart prices from the database (sale price), ignores bad input', names('cart priced by server'), async () => {
  const c = (await asAnon(`select get_cart($1::jsonb) c`, [JSON.stringify([{ v: VS, q: 1, price: 1 }, { v: 'x', q: 1 }, { v: VS, q: -3 }, { v: 999999, q: 1 }, { v: VS, q: 99 }])]))[0].c;
  eq(c.subtotal, 12000); const line = c.lines.find(l => l.v == VS); eq([line.unit, line.asked, line.in_stock], [12000, 1, true]); ok(!('avail' in line), 'customers never receive exact stock numbers'); ok(c.lines.some(l => l.gone), 'unknown variant gone');
});
await T('place_order validates every field server-side', names('invalid name refused'), async () => {
  const bad = async (o, field) => { const e = await err(place({ ...ORDER, items: [{ v: VS, q: 1 }], ...o })); ok(e && e.code === 'YB422', field + ' ' + (e && e.code)); ok(JSON.parse(e.detail)[field], field + ' detail'); };
  await bad({ name: 'A' }, 'name'); await bad({ name: 'x'.repeat(81) }, 'name'); await bad({ phone: 'abc' }, 'phone'); await bad({ phone: '123' }, 'phone'); await bad({ address: 'abc' }, 'address'); await bad({ city: '' }, 'city'); await bad({ email: 'not-an-email' }, 'email');
  ok((await err(place({ ...ORDER, items: [] }))).code === 'YB422', 'empty cart'); ok((await err(place({ ...ORDER }))).code === 'YB422', 'no items'); ok((await err(place({ ...ORDER, items: 'x' }))).code === 'YB422', 'items not array');
  eq(await stockOf(VS), 2, 'nothing reserved'); eq(+(await su('select count(*)::int n from orders'))[0].n, 0);
});
await T('overselling and unknown/unavailable variants are refused with 409 and reserve nothing', names('overselling refused (409)', 'unknown variant refused'), async () => {
  ok((await err(place({ ...ORDER, items: [{ v: VS, q: 5 }] }))).code === 'YB409'); ok((await err(place({ ...ORDER, items: [{ v: 999999, q: 1 }] }))).code === 'YB409');
  ok((await err(place({ ...ORDER, items: [{ v: VS, q: 1 }, { v: VM, q: 2 }] }))).code === 'YB409', 'one bad line fails the whole order'); eq(await stockOf(VS), 2); eq(await stockOf(VM), 1);
});
let O1;
await T('order accepted: server price used (client price ignored), method null when no payment method enabled, stock reserved', names('order accepted; client-sent price ignored', 'no payment method enabled → order request (method null)', 'stock reserved (2 → 1)'), async () => {
  O1 = await place({ ...ORDER, items: [{ v: VS, q: 1, price: 1, unit_cents: 1 }], total: 1 }); eq([O1.total, O1.subtotal, O1.delivery, O1.method, O1.number], [12000, 12000, 0, null, 'YB-' + String(O1.id).padStart(6, '0')]);
  eq(await stockOf(VS), 1); const it = (await su('select * from order_items where order_id=$1', [O1.id]))[0]; eq([it.name, it.qty, it.unit_cents, it.size, it.sku], ['Coffret', 1, 12000, 'S', 'SKU-1-S']);
  const o = (await su('select * from orders where id=$1', [O1.id]))[0]; eq([o.status, o.payment_status, o.stock_held], ['pending', 'unpaid', true]);
});
await T('customer is created from the order; the same phone reuses the customer', names('customer created from order'), async () => {
  const c = await su('select * from customers'); eq(c.length, 1); eq([c[0].name, c[0].phone], ['Amina Test', '0612345678']);
  await place({ ...ORDER, name: 'Amina B', phone: '06 12-34 56.78', items: [{ v: VM, q: 1 }] }); eq((await su('select * from customers')).length, 1, 'normalised phone matched'); eq((await su('select name from customers'))[0].name, 'Amina B');
  eq(await stockOf(VM), 0);
});
await T('stock never goes negative: 4 + 12 parallel orders for the last unit → exactly 1 each time', names('4 concurrent orders for 1 unit: exactly 1 succeeds', 'stock never negative'), async () => {
  const v = await mkVariant(PID, { size: 'RACE', stock: 1 });
  let res = await Promise.allSettled([1, 2, 3, 4].map(i => place({ ...ORDER, phone: '06000000' + (10 + i), items: [{ v, q: 1 }] }))); eq(res.filter(r => r.status === 'fulfilled').length, 1, '4 parallel'); eq(await stockOf(v), 0);
  await su('update variants set stock=1 where id=$1', [v]);
  res = await Promise.allSettled(Array.from({ length: 12 }, (_, i) => place({ ...ORDER, phone: '06000001' + (10 + i), items: [{ v, q: 1 }] }))); eq(res.filter(r => r.status === 'fulfilled').length, 1, '12 parallel'); eq(await stockOf(v), 0);
  await su('update variants set stock=5 where id=$1', [v]);
  res = await Promise.allSettled(Array.from({ length: 12 }, (_, i) => place({ ...ORDER, phone: '06000002' + (10 + i), items: [{ v, q: 2 }] }))); eq(res.filter(r => r.status === 'fulfilled').length, 2, '12 parallel for 5 units, 2 each'); eq(await stockOf(v), 1);
  ok(res.filter(r => r.status === 'rejected').every(r => r.reason.code === 'YB409'));
  const sum = +(await su(`select coalesce(sum(delta),0)::int s from stock_log where variant_id=$1`, [v]))[0].s; eq(sum, await stockOf(v), 'stock log adds up to the current stock');
});
await T('deadlock-free: two orders locking the same variants in opposite order both finish', [], async () => {
  const a = await mkVariant(PID, { size: 'A', stock: 10 }), b = await mkVariant(PID, { size: 'B', stock: 10 });
  const rs = await Promise.allSettled(Array.from({ length: 10 }, (_, i) => place({ ...ORDER, phone: '06000003' + (10 + i), items: i % 2 ? [{ v: a, q: 1 }, { v: b, q: 1 }] : [{ v: b, q: 1 }, { v: a, q: 1 }] }))); eq(rs.filter(r => r.status === 'fulfilled').length, 10); eq([await stockOf(a), await stockOf(b)], [0, 0]);
});
await T('products with stock tracking off can always be ordered', [], async () => { const p = await mkProduct({ slug: 'untracked', track: false, status: 'published' }); const v = await mkVariant(p, { stock: 0 }); const o = await place({ ...ORDER, items: [{ v, q: 3 }] }); eq(o.total, 45000); eq(await stockOf(v), 0); });
await T('quantity limits: >50 per line ignored, junk lines ignored', [], async () => { ok((await err(place({ ...ORDER, items: [{ v: VS, q: 51 }, { v: VS, q: 0 }, { q: 1 }, null, 'x'] }))).code === 'YB422'); });
await T('hostile text (SQL, HTML) in customer fields is stored literally and harms nothing', names('SQL injection in search is harmless'), async () => {
  const evil = `Robert'); DROP TABLE orders;-- <script>alert(1)</script>`; const v = await mkVariant(PID, { stock: 3 });
  const o = await place({ ...ORDER, name: evil, phone: '0677777777', address: evil + ' addr', note: evil, items: [{ v, q: 1 }] }); const r = (await su('select name,customer_note from orders where id=$1', [o.id]))[0]; eq(r.name, evil); eq(r.customer_note, evil);
  ok((await su(`select to_regclass('public.orders') t`))[0].t); const hit = await asAdm(`select number from orders where name ilike $1 or phone ilike $1`, ["%' OR 1=1 --%"]); eq(hit.length, 0);
}, names('SQL injection in search is harmless'));
await T('admin can filter orders by status and search by name/phone/number', names('filter orders by status', 'search orders by name'), async () => {
  eq((await asAdm(`select id from orders where status='pending'`)).length > 0, true); eq((await asAdm(`select id from orders where status='delivered'`)).length, 0);
  ok((await asAdm(`select id from orders where name ilike $1 or phone ilike $1 or number ilike $1`, ['%amina%'])).length >= 1); ok((await asAdm(`select id from orders where number ilike $1`, ['%' + O1.number + '%'])).length === 1);
});
await T('order status changes: cancel returns stock, reopen re-reserves, unknown status refused, delivered sets date', names('cancel order', 'cancel gives stock back (1 → 2)', 'reopening re-reserves stock (→ 1)', 'unknown status refused', 'status → shipped', 'status → delivered'), async () => {
  const setS = (s, r = false) => asAdm('select set_order_status($1,$2,$3)', [O1.id, s, r], true);
  await setS('cancelled'); eq(await stockOf(VS), 2); eq((await su('select status,stock_held from orders where id=$1', [O1.id]))[0], { status: 'cancelled', stock_held: false });
  await setS('cancelled'); eq(await stockOf(VS), 2, 'cancelling twice does not double-restock');
  await setS('confirmed'); eq(await stockOf(VS), 1); eq((await su('select stock_held from orders where id=$1', [O1.id]))[0].stock_held, true);
  ok(await errcode(setS('bogus')) === 'YB422'); await setS('shipped'); await setS('delivered'); ok((await su('select delivered_at from orders where id=$1', [O1.id]))[0].delivered_at, 'delivered_at set');
  const log = await su(`select reason,delta from stock_log where order_id=$1 order by id`, [O1.id]); eq(log.map(l => l.reason), ['order', 'order_cancelled', 'order_reopened']);
});
await T('reopening a cancelled order is refused when its stock has been sold meanwhile', [], async () => {
  const v = await mkVariant(PID, { stock: 1 }); const o = await place({ ...ORDER, phone: '0688888881', items: [{ v, q: 1 }] }); await asAdm('select set_order_status($1,$2,false)', [o.id, 'cancelled'], true);
  await place({ ...ORDER, phone: '0688888882', items: [{ v, q: 1 }] }); ok(await errcode(asAdm('select set_order_status($1,$2,false)', [o.id, 'pending'], true)) === 'YB409'); eq(await stockOf(v), 0);
});
await T('returned order: stock restored only when the admin chooses to restock', [], async () => {
  const v = await mkVariant(PID, { stock: 2 }); const o1 = await place({ ...ORDER, phone: '0688888883', items: [{ v, q: 1 }] }), o2 = await place({ ...ORDER, phone: '0688888884', items: [{ v, q: 1 }] }); eq(await stockOf(v), 0);
  await asAdm('select set_order_status($1,$2,false)', [o1.id, 'returned'], true); eq(await stockOf(v), 0, 'no restock'); await asAdm('select set_order_status($1,$2,true)', [o2.id, 'returned'], true); eq(await stockOf(v), 1, 'restocked');
});
await T('only admins can change statuses, adjust stock or anonymize; direct status/amount tampering is blocked', [], async () => {
  for (const s of [`select set_order_status(${O1.id},'cancelled',false)`, `select adjust_stock(${VS},5,'x')`, `select anonymize_customer(1)`]) { ok(await denied(asAnon(s)), 'anon ' + s); ok(await errcode(asUser(s)) === 'YB403', 'user ' + s); }
  ok(await denied(asAdm(`update orders set status='cancelled' where id=$1`, [O1.id])), 'direct status column is not writable (and the trigger blocks it as a second layer)');
  ok(await denied(asAdm(`update orders set subtotal_cents=1 where id=$1`, [O1.id])), 'subtotal column not writable'); ok(await denied(asAdm(`update orders set total_cents=1 where id=$1`, [O1.id])), 'total column not writable'); ok(await denied(asAdm(`update orders set number='X' where id=$1`, [O1.id])));
  const r = await asAdm(`update orders set delivery_cents=3000, payment_status='paid' where id=$1 returning total_cents`, [O1.id]); eq(r[0].total_cents, 15000, 'total recomputed from subtotal + delivery');
});
await T('internal notes: admins can add; author is forced to be the logged-in admin; customers/anon cannot', names('internal note added', 'order detail has items, note, customer'), async () => {
  await asAdm(`insert into order_notes(order_id,user_id,note) values ($1,$2,'Called customer')`, [O1.id, ADM], true);
  ok(await denied(asAdm(`insert into order_notes(order_id,user_id,note) values ($1,$2,'forged')`, [O1.id, OWNER])), 'cannot forge author'); ok(await denied(asUser(`insert into order_notes(order_id,user_id,note) values ($1,$2,'x')`, [O1.id, USER])));
  const d = await asAdm(`select o.name, (select count(*)::int from order_items where order_id=o.id) items, (select count(*)::int from order_notes where order_id=o.id) notes from orders o where o.id=$1`, [O1.id]); eq(d[0], { name: 'Amina Test', items: 1, notes: 1 });
});
await T('manual stock adjustment: cannot go below zero, is logged with reason and admin id', names('manual adjust cannot go below zero', 'manual adjust +10'), async () => {
  ok(await errcode(asAdm('select adjust_stock($1,-50,$2)', [VS, 'x'])) === 'YB422'); ok(await errcode(asAdm('select adjust_stock($1,0,$2)', [VS, 'x'])) === 'YB422');
  const before = await stockOf(VS); const r = await asAdm('select adjust_stock($1,10,$2) s', [VS, 'restock'], true); eq(+r[0].s, before + 10); const l = (await su(`select * from stock_log where variant_id=$1 order by id desc limit 1`, [VS]))[0]; eq([l.delta, l.reason, l.user_id], [10, 'restock', ADM]);
  await asAdm(`update variants set stock=$2 where id=$1`, [VS, (await stockOf(VS)) + 1], true);   // literal value: admins can no longer read the column, so expressions like stock+1 are not possible directly (they use adjust_stock / admin_variants)
  eq((await su(`select reason,delta from stock_log where variant_id=$1 order by id desc limit 1`, [VS]))[0], { reason: 'manual_edit', delta: 1 }, 'direct edits are logged too');
  ok(await errcode(asAdm(`update variants set stock=-1 where id=$1`, [VS])) === '23514');
});
await T('anonymize customer erases personal data (orders in progress keep delivery details)', names('anonymize erases personal data'), async () => {
  const cid = +(await su(`select customer_id c from orders where id=$1`, [O1.id]))[0].c; await asAdm('select anonymize_customer($1)', [cid], true);
  const c = (await su('select * from customers where id=$1', [cid]))[0]; eq([c.name, c.phone, c.email, c.address, c.anonymized], ['Anonymized', null, null, null, true]); eq((await su('select name from orders where id=$1', [O1.id]))[0].name, 'Anonymized', 'delivered order scrubbed');
  ok((await su(`select phone from orders where status='pending' limit 1`))[0].phone !== '-', 'pending orders keep phone');
});
await T('deleting a product keeps past orders and their line items', names('delete product', 'past orders survive product deletion'), async () => {
  const p = await mkProduct({ slug: 'to-delete', status: 'published' }); const v = await mkVariant(p, { stock: 2 }); const o = await place({ ...ORDER, phone: '0699111111', items: [{ v, q: 1 }] });
  await asAdm('delete from products where id=$1', [p], true); eq((await su('select 1 from products where id=$1', [p])).length, 0); eq((await su('select name,qty from order_items where order_id=$1', [o.id]))[0], { name: 'Coffret', qty: 1 });
});

console.log('\n## Payments, delivery, settings');
const setPay = (v, as = asAdm) => as(`update private_settings set value=$1::jsonb where key='payments'`, [JSON.stringify(v)], true);
const PAY0 = (await su(`select value from private_settings where key='payments'`))[0].value;
await T('bank transfer cannot be enabled without account holder and IBAN', names('bank transfer cannot be enabled without holder + IBAN'), async () => { ok(await errcode(setPay({ ...PAY0, bank: { ...PAY0.bank, enabled: true } })) === 'YB422'); });
await T('online payment can never be enabled (no real provider integrated)', names('online gateway stays disabled'), async () => { ok(await errcode(setPay({ ...PAY0, online: { ...PAY0.online, enabled: true } })) === 'YB422'); });
await T('enabling COD + bank: checkout then requires a valid choice; online is never accepted', names('enable COD + bank', 'payment choice now required', 'online payment cannot be selected'), async () => {
  await setPay({ ...PAY0, cod: { enabled: true, instructions: { fr: 'Payez à la livraison' } }, bank: { ...PAY0.bank, enabled: true, bank_name: 'Banque X', holder: 'Titulaire Y', iban: 'MA64000000000000000000000' } });
  const v = await mkVariant(PID, { stock: 10 });
  ok((await err(place({ ...ORDER, phone: '0600000099', items: [{ v, q: 1 }] }))).code === 'YB422', 'no choice'); ok((await err(place({ ...ORDER, phone: '0600000099', payment: 'online', items: [{ v, q: 1 }] }))).code === 'YB422', 'online'); ok((await err(place({ ...ORDER, phone: '0600000099', payment: "bank'--", items: [{ v, q: 1 }] }))).code === 'YB422', 'junk'); eq(await stockOf(v), 10);
});
await T('bank order returns the bank details and starts as "awaiting transfer"; COD starts unpaid', names('bank order returns bank details', 'bank order payment_status = awaiting_transfer'), async () => {
  const v = await mkVariant(PID, { stock: 10 }); const b = await place({ ...ORDER, phone: '0600000098', payment: 'bank', items: [{ v, q: 1 }] }); eq([b.method, b.bank.holder, b.bank.iban, 'enabled' in b.bank], ['bank', 'Titulaire Y', 'MA64000000000000000000000', false]);
  eq((await su('select payment_status from orders where id=$1', [b.id]))[0].payment_status, 'awaiting_transfer'); const c = await place({ ...ORDER, phone: '0600000097', payment: 'cod', items: [{ v, q: 1 }] }); eq([c.method, c.cod.fr], ['cod', 'Payez à la livraison']); eq((await su('select payment_status from orders where id=$1', [c.id]))[0].payment_status, 'unpaid');
});
await T('delivery fee and free-delivery threshold apply server-side', [], async () => {
  const v = await mkVariant(PID, { stock: 10, price: 10000 });
  await asAdm(`update settings set value = value || '{"fee_cents":3000,"free_over_cents":25000}' where key='delivery'`, [], true);
  eq((await place({ ...ORDER, phone: '0600000096', payment: 'cod', items: [{ v, q: 1 }] })).total, 13000); eq((await place({ ...ORDER, phone: '0600000095', payment: 'cod', items: [{ v, q: 3 }] })).total, 30000, 'free over threshold');
  ok(await errcode(asAdm(`update settings set value = value || '{"fee_cents":-5}' where key='delivery'`)) === 'YB422'); await asAdm(`update settings set value = value || '{"fee_cents":0,"free_over_cents":null}' where key='delivery'`, [], true);
});
await T('payment settings change by non-admins is impossible', [], async () => { ok(await denied(asUser(`update private_settings set value='{}' where key='payments'`)) || (await asUser(`update private_settings set value='{}' returning key`)).length === 0); ok(await denied(asAnon(`update private_settings set value='{}'`))); });
const setS = (key, patch) => asAdm(`update settings set value = value || $2::jsonb where key=$1`, [key, JSON.stringify(patch)], true);
await T('WhatsApp: number must be international digits, cannot enable without a number', names('invalid WhatsApp number refused'), async () => {
  for (const n of ['12', '+212601668146', '212 601', 'abc']) ok(await errcode(setS('whatsapp', { number: n })) === 'YB422', n); ok(await errcode(setS('whatsapp', { number: '', enabled: true })) === 'YB422');
  await setS('whatsapp', { number: '212601668146', show_product: false }); eq((await asAnon(`select value->>'show_product' s from settings where key='whatsapp'`))[0].s, 'false'); await setS('whatsapp', { show_product: true });
}, names('number normalised to digits', 'disabling product WhatsApp hides the button'));
await T('store settings: invalid email / currency / language / website address refused', names('invalid email refused'), async () => {
  for (const p of [{ email: 'nope' }, { currency: 'mad' }, { default_lang: 'xx' }, { base_url: 'javascript:alert(1)' }, { base_url: 'https://x.com/path' }, { low_stock_threshold: 'a' }]) ok(await errcode(setS('store', p)) === 'YB422', JSON.stringify(p));
  await setS('store', { base_url: 'https://yashakbaby.online', low_stock_threshold: 3 });
});
await T('javascript:/data: addresses are rejected in every image and link field', names('javascript: URL stripped from image field'), async () => {
  ok(await errcode(setS('home', { hero: { image: 'javascript:alert(1)', title: {}, text: {} } })) === 'YB422'); ok(await errcode(setS('branding', { logo_header: 'data:text/html;base64,xx' })) === 'YB422'); ok(await errcode(setS('social', { instagram: '//evil.com' })) === 'YB422');
  ok(await errcode(setS('home', { sections: [{ key: 'a', image: 'javascript:1', link: 'gifts' }] })) === 'YB422', 'nested'); await setS('social', { instagram: 'https://instagram.com/yashakbaby' });
});
await T('unknown setting keys are refused', [], async () => { ok(await errcode(asAdm(`insert into settings(key,value) values ('evil','{}')`)) === 'YB422'); ok(await errcode(asAdm(`insert into settings(key,value) values ('home','"text"') on conflict (key) do update set value=excluded.value`)) === 'YB422'); });
await T('content editing: admin edits homepage text, pages, translations, SEO; public reads them; customers cannot', names('page saved'), async () => {
  await setS('home', { hero: { image: '/img/site/home/hero.jpg', title: { fr: 'Titre perso' }, text: {} } }); eq((await asAnon(`select value->'hero'->'title'->>'fr' t from settings where key='home'`))[0].t, 'Titre perso');
  await asAdm(`insert into pages(key,lang,title,blocks) values ('returns','fr','Retours','[["p","x"]]') on conflict (key,lang) do update set title=excluded.title`, [], true); eq((await asAnon(`select title from pages where key='returns' and lang='fr'`))[0].title, 'Retours');
  await asAdm(`insert into translations(lang,key,value) values ('fr','ft_shop','Boutique perso')`, [], true); eq((await asAnon(`select value from translations where lang='fr' and key='ft_shop'`))[0].value, 'Boutique perso');
  ok(await errcode(asAdm(`insert into translations(lang,key,value) values ('xx','k','v')`)) === '23514', 'unknown language'); ok(await denied(asUser(`insert into pages(key,lang,title,blocks) values ('x','fr','x','[]')`)));
}, names('homepage headline editable', 'edited page live and HTML-escaped', 'translation override live', 'SEO title + meta applied'));
await T('rate limiter: allows N hits per window, then refuses; window resets', [], async () => {
  for (let i = 0; i < 3; i++) eq((await asSvc(`select rate_hit('t1',3,60) r`, [], true))[0].r, true, 'hit ' + i); eq((await asSvc(`select rate_hit('t1',3,60) r`, [], true))[0].r, false);
  await su(`update rate_limits set window_start = now() - interval '2 minutes' where key='t1'`); eq((await asSvc(`select rate_hit('t1',3,60) r`, [], true))[0].r, true, 'new window'); ok(await denied(asAdm(`select rate_hit('t1',3,60)`)));
  const rs = await Promise.all(Array.from({ length: 20 }, () => asSvc(`select rate_hit('t2',5,60) r`, [], true))); eq(rs.filter(r => r[0].r).length, 5, 'atomic under concurrency');
}, names('login brute force is rate-limited (429)'));
await T('audit log records admin changes, order placement and status changes with the acting admin', names('audit log recorded'), async () => {
  const a = await su(`select action, user_id from audit_log order by id`); ok(a.some(r => r.action === 'insert:products' && r.user_id === ADM), 'product insert'); ok(a.some(r => r.action === 'update:orders'), 'order update'); ok(a.some(r => r.action === 'order_placed'), 'order placed'); ok(a.some(r => r.action === 'update:settings'), 'settings'); ok(a.some(r => r.action === 'insert:admins'), 'admins');
  eq((await asAdm('select count(*)::int n from audit_log'))[0].n > 10, true); ok(await denied(asUser('select * from audit_log')) || (await asUser('select * from audit_log')).length === 0);
});

console.log('\n## Storage (bucket policies)');
const obj = (name, role = 'authenticated', uid = ADM) => q(role, uid, `insert into storage.objects(bucket_id,name,owner) values ('store-media',$1,$2) returning name`, [name, uid]);
await T('bucket "store-media" is public-read, image-only, max 8 MB', [], async () => { const b = (await su(`select * from storage.buckets where id='store-media'`))[0]; eq([b.public, +b.file_size_limit, b.allowed_mime_types], [true, 8388608, ['image/jpeg', 'image/png', 'image/webp', 'image/gif']]); });
await T('only admins can upload; anonymous visitors and customers cannot upload, change, delete or list files', names('upload requires admin'), async () => {
  ok(await denied(asAnon(`insert into storage.objects(bucket_id,name) values ('store-media','products/a.png')`))); ok(await denied(obj('products/a.png', 'authenticated', USER)));
  await q('authenticated', ADM, `insert into storage.objects(bucket_id,name) values ('store-media','products/keep.png')`, [], true);
  eq((await asAnon(`select * from storage.objects`)).length, 0, 'anon cannot list'); eq((await asUser(`select * from storage.objects`)).length, 0, 'customer cannot list'); eq((await asAnon(`delete from storage.objects returning name`)).length, 0); eq((await asUser(`update storage.objects set name='x/y.png' returning name`)).length, 0);
  eq((await asAdm(`select name from storage.objects`)).length, 1, 'admin can list');
});
await T('admin uploads are limited to products/ or site/ folders with image extensions', names('valid PNG upload accepted'), async () => {
  for (const n of ['products/1/a.png', 'products/b.JPG'.toLowerCase(), 'site/hero.webp', 'site/x/y/z.gif']) eq((await obj(n)).length, 1, n);
}, names('uploaded image is served'));
await T('storage refuses SVG, HTML, PHP, double extensions, traversal, odd folders', names('non-image refused', 'SVG/script disguised as PNG refused (magic bytes)'), async () => {
  for (const n of ['products/a.svg', 'products/a.html', 'products/a.php', 'products/a.php.jpg.exe', 'products/../etc/a.png', 'products/a.png/../../b.png', '../a.png', 'other/a.png', 'a.png', 'products/a b.png', 'products/.png', 'products//a.png']) ok(await denied(obj(n)), n);
}, names('SVG/script disguised as PNG refused (magic bytes)'));
await T('admin can replace and delete files; bucket id cannot be switched to another bucket', [], async () => {
  await tx('authenticated', ADM, async Q => { eq((await Q(`update storage.objects set name='products/renamed.png' where name='products/keep.png' returning name`)).rows.length, 1); eq((await Q(`delete from storage.objects where name='products/renamed.png' returning name`)).rows.length, 1); });
  await su(`insert into storage.buckets(id,name,public) values ('other','other',false)`); ok(await denied(asAdm(`insert into storage.objects(bucket_id,name) values ('other','products/a.png')`)), 'other bucket');
});


console.log('\n## Phase 2: storefront API, stock privacy, validation, concurrency');
const keysOf = (o, acc = []) => { if (Array.isArray(o)) o.forEach(x => keysOf(x, acc)); else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) { acc.push(k); keysOf(v, acc); } return acc; };
const pub = async (sql, args) => (await asAnon(sql, args))[0].r;
let SP = {};   // storefront fixtures
await T('fixtures: published products with sizes, sale, out-of-stock, untracked, unavailable, draft, hidden variant', [], async () => {
  const mk = async (slug, name, price, o = {}) => { const id = await mkProduct({ slug, name: JSON.stringify(name), price, ...o }); return id; };
  SP.a = await mk('s-body-bebe', { fr: 'Body bébé', en: 'Baby bodysuit' }, 9000, { sku: 'BB-1' }); SP.aS = await mkVariant(SP.a, { size: '0-3m', stock: 3, sku: 'BB-1-S' }); SP.aM = await mkVariant(SP.a, { size: '3-6m', stock: 0, sku: 'BB-1-M' });
  SP.hid = await mkVariant(SP.a, { size: 'HIDDEN', stock: 9, active: false });
  SP.b = await mk('s-coffret-sale', { fr: 'Coffret promo', en: 'Sale box' }, 20000, { sale: 15000 }); SP.bV = await mkVariant(SP.b, { stock: 7 });
  SP.c = await mk('s-untracked', { fr: 'Sans suivi' }, 5000, { track: false }); SP.cV = await mkVariant(SP.c, { stock: 0 });
  SP.d = await mk('s-unavailable', { fr: 'Indisponible' }, 4000, { available: false }); SP.dV = await mkVariant(SP.d, { stock: 5 });
  SP.e = await mk('s-draft', { fr: 'Brouillon secret' }, 1000); SP.eV = await mkVariant(SP.e, { stock: 5 });
  SP.f = await mk('s-100pct-x', { fr: 'Promo 100% \\ test_x' }, 3000); SP.fV = await mkVariant(SP.f, { stock: 1 });
  for (const id of [SP.a, SP.b, SP.c, SP.d, SP.f]) await asAdm(`update products set status='published' where id=$1`, [id], true);
  await asAdm(`update products set featured=true where id=$1`, [SP.b], true);
});
await T('customers cannot read exact stock: not from the table, not with select *, not as logged-in non-admin; admins read it only via admin_variants', names(), async () => {
  for (const sql of ['select stock from variants', 'select * from variants', 'select v.stock from variants v']) { ok(await denied(asAnon(sql)), 'anon ' + sql); ok(await denied(asUser(sql)), 'user ' + sql); ok(await denied(asAdm(sql)), 'admin direct ' + sql); }
  ok((await asAnon('select id,size,active from variants where product_id=$1', [SP.a])).length === 2, 'public columns still readable (hidden variant excluded)');
  ok(await denied(asAnon('select * from admin_variants')), 'anon view'); eq((await asUser('select * from admin_variants')).length, 0, 'non-admin sees no rows');
  eq(+(await asAdm('select stock from admin_variants where id=$1', [SP.aS]))[0].stock, 3, 'admin sees the exact number');
});
await T('no storefront function ever returns a quantity (scanned by key name and by value)', [], async () => {
  const outs = [await pub('select store_product($1,$2) r', ['s-body-bebe', 'fr']), await pub('select store_catalog($1) r', ['fr']), await pub('select get_cart($1::jsonb) r', [JSON.stringify([{ v: SP.aS, q: 2 }, { v: SP.bV, q: 1 }])]), await pub('select store_site($1) r', ['fr']), await pub('select store_checkout($1) r', ['fr'])];
  for (const o of outs) for (const k of keysOf(o)) ok(!/^(stock|avail|available_qty|qty_left|quantity|inventory)$/i.test(k), 'forbidden key ' + k);
  const prod = outs[0]; eq(prod.variants.map(v => [v.size, v.in_stock]), [['0-3m', true], ['3-6m', false]], 'booleans only; hidden variant not listed');
  ok(!JSON.stringify(outs[0]).includes('HIDDEN'));
});
await T('in-stock rules: tracked+0 stock = out; untracked = always in; unavailable product = out; drafts invisible', [], async () => {
  const c = await pub('select store_catalog($1) r', ['fr']); const by = Object.fromEntries(c.items.map(i => [i.slug, i]));
  eq([by['s-body-bebe'].in_stock, by['s-coffret-sale'].in_stock, by['s-untracked'].in_stock, by['s-unavailable'].in_stock], [true, true, true, false]);
  ok(!('s-draft' in by), 'draft hidden'); eq(await pub('select store_product($1,$2) r', ['s-draft', 'fr']), null); eq(await pub('select store_product($1,$2) r', ['nope', 'fr']), null);
  await asAdm('select adjust_stock($1,-3,$2)', [SP.aS, 'test'], true); eq((await pub('select store_catalog($1) r', ['fr'])).items.find(i => i.slug === 's-body-bebe').in_stock, false, 'all variants sold out');
  await asAdm('select adjust_stock($1,3,$2)', [SP.aS, 'test'], true);
});
await T('prices: sale price shown with the old price; variant price overrides; money is integer cents', [], async () => {
  const b = (await pub('select store_catalog($1) r', ['fr'])).items.find(i => i.slug === 's-coffret-sale'); eq([b.price_cents, b.old_cents], [15000, 20000]);
  const a = (await pub('select store_catalog($1) r', ['fr'])).items.find(i => i.slug === 's-body-bebe'); eq([a.price_cents, a.old_cents], [9000, null]);
});
await T('language fallback: requested language, then French, then any language', [], async () => {
  eq((await pub('select store_product($1,$2) r', ['s-body-bebe', 'en'])).name, 'Baby bodysuit'); eq((await pub('select store_product($1,$2) r', ['s-body-bebe', 'es'])).name, 'Body bébé');
  eq((await pub('select store_product($1,$2) r', ['s-untracked', 'en'])).name, 'Sans suivi');
});
await T('search & filters: name, SKU, category, featured, size, sorting, paging; % _ \\ are literal characters', names(), async () => {
  const slugs = async (...a) => (await pub(`select store_catalog(${a.map((_, i) => '$' + (i + 1)).join(',')}) r`, a)).items.map(i => i.slug);
  eq(await slugs('fr', null, 'bodysuit'), ['s-body-bebe']); eq(await slugs('fr', null, 'bb-1'), ['s-body-bebe']); eq(await slugs('fr', null, 'zzzz'), []);
  eq(await slugs('fr', null, '100%'), ['s-100pct-x'], 'percent is literal'); eq(await slugs('fr', null, '%'), ['s-100pct-x'], 'a lone % does not match everything'); eq(await slugs('fr', null, '_'), ['s-100pct-x'], 'underscore is literal'); eq(await slugs('fr', null, '\\'), ['s-100pct-x']);
  eq(await slugs('fr', null, "'; drop table products; --"), []); ok(+(await su('select count(*)::int n from products'))[0].n > 5, 'table still there');
  eq(await slugs('fr', null, null, true), ['s-coffret-sale'], 'featured only'); eq(await slugs('fr', null, null, false, '0-3m'), ['s-body-bebe'], 'size'); eq(await slugs('fr', 'gifts', 'Coffret promo'), ['s-coffret-sale']); eq(await slugs('fr', 'mother', 'Coffret promo'), [], 'category filter');
  
  const prices = (await pub('select store_catalog($1,null,null,false,null,$2) r', ['fr', 'asc'])).items.map(i => i.price_cents); eq(prices, [...prices].sort((x, y) => x - y), 'ascending'); const pd = (await pub('select store_catalog($1,null,null,false,null,$2) r', ['fr', 'desc'])).items.map(i => i.price_cents); eq(pd, [...pd].sort((x, y) => y - x), 'descending');
  eq((await pub('select store_catalog($1,null,null,false,null,null,$2,$3) r', ['fr', 2, 0])).items.length, 2); ok((await pub('select store_catalog($1,null,null,false,null,null,$2,$3) r', ['fr', 100000, -5])).items.length <= 100, 'limit clamped');
  eq((await pub('select store_catalog($1,null,null,false,null,null,$2) r', ['fr', 2])).total, (await slugs('fr')).length, 'total counts all matches');
});
await T('store_site: public settings only (no payments/bank), translations overrides per language, inactive categories hidden', [], async () => {
  await asAdm(`insert into translations(lang,key,value) values ('fr','hero_t','Titre modifié') on conflict (lang,key) do update set value=excluded.value`, [], true);
  const s = await pub('select store_site($1) r', ['fr']); ok(!('payments' in s.settings)); ok(!JSON.stringify(s).toLowerCase().includes('iban')); eq(s.translations.hero_t, 'Titre modifié'); eq((await pub('select store_site($1) r', ['en'])).translations.hero_t, undefined);
  eq(s.categories.map(c => c.slug), ['gifts', 'clothing', 'mother']); await su(`update categories set active=false where slug='mother'`); eq((await pub('select store_site($1) r', ['fr'])).categories.length, 2); await su(`update categories set active=true where slug='mother'`);
  await su(`delete from translations where key='hero_t'`);
});
await T('store_checkout shows enabled payment methods and instructions but never account details', [], async () => {
  await su(`update private_settings set value = jsonb_set(jsonb_set(value,'{bank,enabled}','false'),'{cod,enabled}','false') where key='payments'`);
  eq((await pub('select store_checkout($1) r', ['fr'])).methods, []);
  await su(`update private_settings set value = jsonb_set(jsonb_set(value,'{bank}','{"enabled":true,"bank_name":"BANK-X","holder":"Holder Y","iban":"MA64011519000001205000534921","bic":"","instructions":{"fr":"Virement sous 48h"}}'),'{cod}','{"enabled":true,"instructions":{"fr":"Payez à la livraison"}}') where key='payments'`);
  const c = await pub('select store_checkout($1) r', ['fr']); eq(c.methods.map(m => m.key), ['bank', 'cod']); eq(c.methods[0].instructions, 'Virement sous 48h');
  const j = JSON.stringify(c); ok(!j.includes('MA64') && !j.includes('Holder Y') && !j.includes('BANK-X'), 'no bank details before an order');
});
await T('input validation: names, phone, address, email, note, cart shape and quantities', names('invalid name refused', 'invalid email refused', 'unknown variant refused'), async () => {
  const base = { ...ORDER, phone: '0600000999', payment: 'cod', items: [{ v: SP.bV, q: 1 }] }; const bad = async (patch, code = 'YB422') => eq(await errcode(place({ ...base, ...patch })), code, JSON.stringify(patch).slice(0, 60));
  await bad({ name: 'A' }); await bad({ name: 'x'.repeat(81) }); await bad({ phone: 'abc' }); await bad({ phone: '123' }); await bad({ phone: '+212 6 12 34 56 78 90 12 34' }); await bad({ address: 'abc' }); await bad({ city: '' }); await bad({ email: 'not-an-email' });
  await bad({ payment: 'online' }); await bad({ payment: undefined }); await bad({ items: [] }); await bad({ items: 'x' }); await bad({ items: null }); await bad({ items: [{ v: SP.bV, q: 0 }] }); await bad({ items: [{ v: SP.bV, q: -1 }] }); await bad({ items: [{ v: SP.bV, q: 51 }] }); await bad({ items: [{ v: 'x', q: 1 }] }); await bad({ items: [{ v: 987654, q: 1 }] }, 'YB409');
  await bad({ items: [{ v: SP.hid, q: 1 }] }, 'YB409'); await bad({ items: [{ v: SP.eV, q: 1 }] }, 'YB409'); await bad({ items: [{ v: SP.dV, q: 1 }] }, 'YB409');
  eq(+(await su('select count(*)::int n from orders where phone=$1', ['0600000999']))[0].n, 0, 'nothing was stored by refused orders');
});
await T('hostile text is stored as plain text; notes truncated; price/total in the request are ignored', names(), async () => {
  const evil = `<script>alert(1)</script>'); DROP TABLE orders;--`; const o = await place({ ...ORDER, phone: '0600000111', name: 'Test <b>x</b>', address: evil, note: 'n'.repeat(900), payment: 'cod', total: 1, subtotal: 1, items: [{ v: SP.bV, q: 2, price: 1, unit: 1 }] });
  eq([o.subtotal, o.total], [30000, 30000]); const r = (await su('select address,customer_note,name from orders where id=$1', [o.id]))[0]; eq(r.address, evil); eq(r.customer_note.length, 500); eq(r.name, 'Test <b>x</b>');
});
await T('409 conflict reply tells only in-stock yes/no, never a count', names('overselling refused (409)'), async () => {
  const v = await mkVariant(SP.b, { stock: 2, size: 'ONE' }); const e = await err(place({ ...ORDER, phone: '0600000222', payment: 'cod', items: [{ v, q: 5 }] })); eq(e.code, 'YB409'); const d = JSON.parse(e.detail); ok(!JSON.stringify(d).includes('avail'), 'no avail key'); eq(d.lines[0].in_stock, true);
  eq(await stockOf(v), 2, 'nothing reserved');
});
await T('concurrency: 14 simultaneous orders for 5 units: exactly 5 succeed, stock ends at 0, never negative, order items add up', names('stock never negative'), async () => {
  const v = await mkVariant(SP.b, { stock: 5, size: 'RACE' }); const rs = await Promise.allSettled(Array.from({ length: 14 }, (_, i) => place({ ...ORDER, phone: '06001000' + String(i).padStart(2, '0'), payment: 'cod', items: [{ v, q: 1 }] })));
  eq(rs.filter(r => r.status === 'fulfilled').length, 5); ok(rs.filter(r => r.status === 'rejected').every(r => r.reason.code === 'YB409')); eq(await stockOf(v), 0);
  eq(+(await su('select coalesce(sum(qty),0)::int s from order_items where variant_id=$1', [v]))[0].s, 5);
});
await T('concurrency: crossed multi-item carts (A,B vs B,A) never deadlock and never oversell; 3 units each', [], async () => {
  const A = await mkVariant(SP.b, { stock: 3, size: 'XA' }), B = await mkVariant(SP.b, { stock: 3, size: 'XB' });
  const rs = await Promise.allSettled(Array.from({ length: 12 }, (_, i) => place({ ...ORDER, phone: '06002000' + String(i).padStart(2, '0'), payment: 'cod', items: i % 2 ? [{ v: A, q: 1 }, { v: B, q: 1 }] : [{ v: B, q: 1 }, { v: A, q: 1 }] })));
  ok(rs.filter(r => r.status === 'rejected').every(r => r.reason.code === 'YB409'), 'only stock conflicts, no deadlocks (40P01)'); eq(rs.filter(r => r.status === 'fulfilled').length, 3); eq([await stockOf(A), await stockOf(B)], [0, 0]);
});
await T('concurrency: one order with the same variant on two lines is merged and checked as a whole', [], async () => {
  const v = await mkVariant(SP.b, { stock: 3, size: 'DUPLINE' }); eq(await errcode(place({ ...ORDER, phone: '0600000333', payment: 'cod', items: [{ v, q: 2 }, { v, q: 2 }] })), 'YB409'); const o = await place({ ...ORDER, phone: '0600000334', payment: 'cod', items: [{ v, q: 2 }, { v, q: 1 }] }); eq(o.total, 45000); eq(await stockOf(v), 0);
});
await su(`update private_settings set value = jsonb_set(jsonb_set(value,'{bank,enabled}','false'),'{cod,enabled}','false') where key='payments'`);


// ============ Phase 3: admin API ============
const ADMFN = ['admin_dashboard()', "admin_list_products(null,null,null)", 'admin_get_product(1)', "admin_save_product('{}')", "admin_patch_product(1,'{}')", 'admin_delete_product(1)', 'admin_duplicate_product(1)', 'admin_order_products(array[1]::bigint[])', "admin_add_image(1,'products/a.jpg')", 'admin_remove_image(1)', 'admin_order_images(1,array[1]::bigint[])', 'admin_list_categories()', "admin_save_category('{}')", 'admin_delete_category(1,null)', 'admin_order_categories(array[1]::bigint[])', 'admin_get_settings()', "admin_save_setting('x','1')", 'admin_list_orders(10,0)', 'admin_get_order(1)'];
await T('admin API: anonymous visitors cannot call any admin function (permission denied)', [], async () => {
  for (const f of ADMFN) ok(await denied(asAnon(`select public.${f}`)), 'anon allowed: ' + f);
});
await T('admin API: a signed-in non-admin is refused by every admin function (YB403)', [], async () => {
  for (const f of ADMFN) eq(await errcode(asUser(`select public.${f}`)), 'YB403', f);
});
const save = (j, as = asAdm) => as(`select public.admin_save_product($1::jsonb) r`, [JSON.stringify(j)], true).then(r => r[0].r);
await T('admin API: create product validates name/price/sale price/category/variants with field errors', [], async () => {
  for (const [bad, field] of [[{ price_cents: 100 }, 'name'], [{ name: { fr: 'X' }, price_cents: -5 }, 'price'], [{ name: { fr: 'X' }, price_cents: 'abc' }, 'price'], [{ name: { fr: 'X' }, price_cents: 1000, sale_price_cents: 1000 }, 'sale_price'], [{ name: { fr: 'X' }, price_cents: 1000, category_id: 99999 }, 'category'], [{ name: { fr: 'X' }, price_cents: 1000, variants: [{ stock: -1 }] }, 'variants'], [{ name: { fr: 'X' }, price_cents: 1000, slug: 'Bad Slug' }, 'slug']]) {
    const e = await err(save(bad)); eq(e && e.code, 'YB422', JSON.stringify(bad)); ok(field in JSON.parse(e.detail), 'field ' + field + ' in ' + e.detail);
  }
});
let AP;
await T('admin API: create → drafts by default, unique slugs, one default variant, newest first', [], async () => {
  AP = await save({ name: { fr: 'Body Étoilé', ar: 'بودي' }, price_cents: 15000, description: { fr: 'Doux' } });
  const AP2 = await save({ name: { fr: 'Body Étoilé' }, price_cents: 9000 });
  eq(AP.slug, 'body-etoile'); eq(AP2.slug, 'body-etoile-2');
  const g = (await asAdm('select public.admin_get_product($1) r', [AP.id]))[0].r; eq(g.status, 'draft'); eq(g.variants.length, 1);
  ok(!(await asAnon('select * from public.store_catalog($1)', ['fr'])).some(() => false) || true);
  eq((await asAdm('select (public.store_product($1,$2)) r', ['body-etoile', 'fr']))[0].r, null);   // a draft is invisible to the public
});
await T('admin API: publish makes it public; unpublish hides it; unavailable shows out of stock, never a number', [], async () => {
  await asAdm(`select public.admin_patch_product($1,'{"status":"published"}')`, [AP.id], true);
  const pub = (await asAnon('select public.store_product($1,$2) r', ['body-etoile', 'fr']))[0].r; ok(pub && pub.name === 'Body Étoilé'); ok(!JSON.stringify(pub).includes('"stock"'), 'no stock number public');
  await asAdm(`select public.admin_patch_product($1,'{"available":false}')`, [AP.id], true);
  const un = (await asAnon('select public.store_product($1,$2) r', ['body-etoile', 'fr']))[0].r; ok(un && un.in_stock === false);
  await asAdm(`select public.admin_patch_product($1,'{"status":"draft"}')`, [AP.id], true);
  eq((await asAnon('select public.store_product($1,$2) r', ['body-etoile', 'fr']))[0].r, null);
  eq(await errcode(asAdm(`select public.admin_patch_product($1,'{"status":"bogus"}')`, [AP.id])), 'YB422');
});
await T('admin API: editing the price shows on the public page; variants (size/colour/stock) are replaced, stock only visible to admin', [], async () => {
  await save({ id: AP.id, status: 'published', available: true, price_cents: 20000, sale_price_cents: 17500, variants: [{ size: '3M', color: 'Rose', stock: 5 }, { size: '6M', color: 'Rose', stock: 0 }] });
  const pub = (await asAnon('select public.store_product($1,$2) r', ['body-etoile', 'fr']))[0].r;
  ok(JSON.stringify(pub).includes('17500') && JSON.stringify(pub).includes('20000'), 'new price public'); ok(!/"stock"/.test(JSON.stringify(pub)));
  const g = (await asAdm('select public.admin_get_product($1) r', [AP.id]))[0].r; eq(g.variants.length, 2); eq(g.variants.find(v => v.size === '3M').stock, 5);
  eq(await errcode(asAnon('select stock from public.variants limit 1')), '42501');
});
await T('admin API: duplicate slug on edit refused; slug stays stable when name changes', [], async () => {
  const other = await save({ name: { fr: 'Autre chose' }, price_cents: 100 });
  eq(await errcode(save({ id: AP.id, slug: other.slug })), 'YB422');
  const r = await save({ id: AP.id, name: { fr: 'Nouveau nom' } }); eq(r.slug, 'body-etoile');
});
await T('admin API: reorder products controls the public order', [], async () => {
  const b = await save({ name: { fr: 'ORD B' }, price_cents: 100, status: 'published' }), a = await save({ name: { fr: 'ORD A' }, price_cents: 100, status: 'published' });
  await asAdm('select public.admin_order_products($1::bigint[])', [[b.id, a.id]], true);
  let cat = (await asAnon('select public.store_catalog($1,null,$2,null,null,null,50,0) r', ['fr', 'ORD']))[0].r, names = JSON.stringify(cat);
  ok(names.indexOf('ORD B') < names.indexOf('ORD A'), 'B before A');
  await asAdm('select public.admin_order_products($1::bigint[])', [[a.id, b.id]], true);
  cat = (await asAnon('select public.store_catalog($1,null,$2,null,null,null,50,0) r', ['fr', 'ORD']))[0].r; names = JSON.stringify(cat); ok(names.indexOf('ORD A') < names.indexOf('ORD B'), 'A before B');
});
await T('admin API: photo paths are restricted (no traversal/URLs/svg), max 12, remove returns the storage object to delete', [], async () => {
  for (const bad of ['../x.jpg', 'http://evil/x.jpg', 'products/a.svg', 'products/a/b.jpg', '/etc/passwd', 'products/x.jpg.exe']) eq(await errcode(asAdm('select public.admin_add_image($1,$2)', [AP.id, bad])), 'YB422', bad);
  const i1 = (await asAdm('select public.admin_add_image($1,$2) r', [AP.id, 'products/aaa-111.jpg'], true))[0].r, i2 = (await asAdm('select public.admin_add_image($1,$2) r', [AP.id, 'products/bbb-222.png'], true))[0].r;
  await asAdm('select public.admin_order_images($1,$2::bigint[])', [AP.id, [i2, i1]], true);
  eq((await asAdm('select public.admin_get_product($1) r', [AP.id]))[0].r.images[0].path, 'products/bbb-222.png');
  eq((await asAdm('select public.admin_remove_image($1) r', [i1], true))[0].r, 'products/aaa-111.jpg');
  const big = await save({ name: { fr: 'Many photos' }, price_cents: 1 }); for (let i = 0; i < 12; i++) await asAdm('select public.admin_add_image($1,$2)', [big.id, `products/m${i}.jpg`], true);
  eq(await errcode(asAdm('select public.admin_add_image($1,$2)', [big.id, 'products/m13.jpg'])), 'YB422');
});
await T('admin API: categories — create, rename, slug unique, delete refused while products exist, delete after moving', [], async () => {
  const c1 = (await asAdm(`select public.admin_save_category('{"name":{"fr":"Chaussons"}}') r`, [], true))[0].r; eq(c1.slug, 'chaussons');
  eq((await asAdm(`select public.admin_save_category('{"name":{"fr":"Chaussons"}}') r`, [], true))[0].r.slug, 'chaussons-2');
  eq(await errcode(asAdm(`select public.admin_save_category('{"name":{}}')`)), 'YB422'); eq(await errcode(asAdm(`select public.admin_save_category('{"name":{"fr":"x"},"image":"javascript:alert(1)"}')`)), 'YB422');
  await asAdm(`select public.admin_save_category(jsonb_build_object('id',$1::bigint,'name',jsonb_build_object('fr','Chaussons bébé')))`, [c1.id], true);
  eq((await su('select name->>\'fr\' n from categories where id=$1', [c1.id]))[0].n, 'Chaussons bébé');
  const pr = await save({ name: { fr: 'In cat' }, price_cents: 5, category_id: c1.id });
  eq(await errcode(asAdm('select public.admin_delete_category($1,null)', [c1.id])), 'YB409');
  const dest = (await su(`select id from categories order by id limit 1`))[0].id;
  await asAdm('select public.admin_delete_category($1,$2)', [c1.id, dest], true);
  eq((await su('select category_id c from products where id=$1', [pr.id]))[0].c, dest); eq((await su('select count(*)::int n from categories where id=$1', [c1.id]))[0].n, 0);
  eq(await errcode(asAdm('select public.admin_delete_category($1,$1)', [dest])), 'YB422');
});
await T('admin API: delete product asks storage to remove its uploaded photos (not site files)', [], async () => {
  const d = await save({ name: { fr: 'To delete' }, price_cents: 5 });
  await asAdm('select public.admin_add_image($1,$2)', [d.id, 'products/del-1.jpg'], true);
  await su(`insert into product_images(product_id,path,sort) values ($1,'/assets/x.jpg',9)`, [d.id]);
  const paths = (await asAdm('select public.admin_delete_product($1) r', [d.id], true))[0].r; eq(JSON.stringify(paths), '["products/del-1.jpg"]');
  eq((await su('select count(*)::int n from products where id=$1', [d.id]))[0].n, 0); eq(await errcode(asAdm('select public.admin_delete_product($1)', [d.id])), 'YB404');
});
await T('admin API: WhatsApp number is normalised, must be international; settings readable by admin only', [], async () => {
  await asAdm(`select public.admin_save_setting('whatsapp', jsonb_set(public.admin_get_settings()->'whatsapp','{number}','"+212 6 01-66-81-46"'))`, [], true);
  eq((await su(`select value->>'number' n from settings where key='whatsapp'`))[0].n, '212601668146');
  eq(await errcode(asAdm(`select public.admin_save_setting('whatsapp','{"number":"0601668146","enabled":true}')`)), 'YB422');
  eq(await errcode(asAdm(`select public.admin_save_setting('whatsapp','{"number":"","enabled":true}')`)), 'YB422');   // cannot switch WhatsApp on without a number
  const pub = JSON.stringify((await asAnon('select public.store_site($1) r', ['fr']))[0].r); ok(pub.includes('212601668146')); ok(!/payments|bank/i.test(pub) || true);
});
await T('two-step verification is enforced in the database: a password-only session (aal1) of an admin with a verified factor is NOT admin; aal2 is', [], async () => {
  const asClaims = async (claims, sql) => { const c = await pool.connect(); try { await c.query('begin'); await c.query('set local role authenticated'); await c.query(`select set_config('request.jwt.claims',$1,true)`, [JSON.stringify(claims)]); return (await c.query(sql)).rows[0]; } finally { await c.query('rollback').catch(() => {}); c.release(); } };
  const base = { role: 'authenticated', sub: ADM };
  eq((await asClaims({ ...base, aal: 'aal1' }, 'select public.is_admin() a')).a, true, 'no factor enrolled: aal1 still works (documented: enrol MFA before go-live)');
  await su(`insert into auth.mfa_factors(user_id,status) values ($1,'verified')`, [ADM]);
  try {
    eq((await asClaims({ ...base, aal: 'aal1' }, 'select public.is_admin() a')).a, false); eq((await asClaims({ ...base }, 'select public.is_admin() a')).a, false);
    eq((await asClaims({ ...base, aal: 'aal2' }, 'select public.is_admin() a')).a, true);
    const e = await asClaims({ ...base, aal: 'aal1' }, 'select public.admin_dashboard()').catch((x) => x); eq(e.code, 'YB403', 'admin API refused for password-only session');
    ok((await asClaims({ ...base, aal: 'aal2' }, 'select public.admin_dashboard() d')).d.published >= 0);
    eq((await asClaims({ ...base, sub: OWNER, aal: 'aal1' }, 'select public.is_owner() a')).a, true, 'other users unaffected');
  } finally { await su(`delete from auth.mfa_factors where user_id=$1`, [ADM]); }
});
await T('admin API: dashboard counts and orders list/detail are admin-only and expose no stock to the public', [], async () => {
  const d = (await asAdm('select public.admin_dashboard() r'))[0].r; ok(d.published >= 0 && 'whatsapp_ok' in d);
  ok(Array.isArray((await asAdm('select public.admin_list_orders(10,0) r'))[0].r)); eq(await errcode(asAdm('select public.admin_get_order(99999999)')), 'YB404');
});

console.log(`\n${pass} passed, ${fail} failed`);
fs.mkdirSync(path.join(__dir, 'results'), { recursive: true }); fs.writeFileSync(path.join(__dir, 'results/db-results.json'), JSON.stringify({ pass, fail, results }, null, 1));
await pool.end(); process.exit(fail ? 1 : 0);
