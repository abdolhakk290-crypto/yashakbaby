// Creates (or re-creates) a local PostgreSQL database with the Supabase stand-in + migrations + seed (+ optional TEST fixtures).
// usage: node tests/dev-db.mjs <dbname> [--fixtures]
import pg from 'pg'; import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url';
const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..'), name = process.argv[2] || 'yb_dev';
const CONN = { host: process.env.PGHOST || '/tmp', port: +(process.env.PGPORT || 54329), user: process.env.PGUSER || 'postgres' };
const a = new pg.Client({ ...CONN, database: 'postgres' }); await a.connect(); await a.query(`drop database if exists ${name} with (force)`); await a.query(`create database ${name}`); await a.end();
const c = new pg.Client({ ...CONN, database: name }); await c.connect();
const files = ['db/support/00-supabase-shim.sql', ...fs.readdirSync(path.join(ROOT, 'supabase/migrations')).sort().map((f) => 'supabase/migrations/' + f), 'supabase/seed.sql', ...(process.argv.includes('--fixtures') ? ['tests/fixtures.sql'] : [])];
for (const f of files) { try { await c.query(fs.readFileSync(path.join(ROOT, f), 'utf8')); } catch (e) { console.error('FAILED', f, e.message); process.exit(1); } }
await c.query(`do $$ begin if not exists (select 1 from pg_roles where rolname='authenticator') then create role authenticator noinherit login; end if; end $$; grant anon, authenticated, service_role to authenticator;`);
await c.end(); console.log('database ready:', name, process.argv.includes('--fixtures') ? '(with TEST fixtures)' : '');
