-- TEST DATA ONLY (never loaded into a real project). Clearly fake products so the storefront can be exercised end to end.
-- Loaded by tests/dev-db.mjs after the migrations + seed.
insert into public.products(slug,category_id,name,description,specs,price_cents,sale_price_cents,sku,status,featured,available,track_stock) values
 ('test-body',  (select id from categories where slug='clothing'), '{"fr":"TEST Body","en":"TEST Bodysuit","ary":"TEST بودي"}', '{"fr":"Description <b>test</b> du body.","en":"Test description."}', '{"fr":"Matière: coton\nLavage: 30°"}', 9000, null, 'TB-1', 'draft', true, true, true),
 ('test-box',   (select id from categories where slug='gifts'),    '{"fr":"TEST Coffret","en":"TEST Gift box"}', '{"fr":"Coffret de test."}', '{}', 20000, 15000, 'TBOX', 'draft', true, true, true),
 ('test-color', (select id from categories where slug='mother'),   '{"fr":"TEST Couleur"}', '{}', '{}', 5000, null, 'TC', 'draft', false, true, true),
 ('test-oos',   (select id from categories where slug='clothing'), '{"fr":"TEST Épuisé"}', '{}', '{}', 4000, null, 'TO', 'draft', false, true, true),
 ('test-xss',   (select id from categories where slug='clothing'), '{"fr":"<script>alert(1)</script> TEST \"quote\" & <img src=x onerror=alert(2)>"}', '{"fr":"<script>alert(3)</script>"}', '{}', 3000, null, 'TX', 'draft', false, true, true),
 ('test-draft', (select id from categories where slug='gifts'),    '{"fr":"TEST Brouillon"}', '{}', '{}', 1000, null, 'TD', 'draft', false, true, true);
insert into public.variants(product_id,sku,size,color,stock) select id,'TB-1-A','0-3m',null,3 from products where slug='test-body';
insert into public.variants(product_id,sku,size,color,stock) select id,'TB-1-B','3-6m',null,0 from products where slug='test-body';
insert into public.variants(product_id,sku,size,color,stock) select id,'TBOX-1',null,null,10 from products where slug='test-box';
insert into public.variants(product_id,sku,size,color,stock) select id,'TC-SR','S','Rose',2 from products where slug='test-color';
insert into public.variants(product_id,sku,size,color,stock) select id,'TC-MR','M','Rose',0 from products where slug='test-color';
insert into public.variants(product_id,sku,size,color,stock) select id,'TC-SB','S','Bleu',5 from products where slug='test-color';
insert into public.variants(product_id,sku,stock) select id,'TO-1',0 from products where slug='test-oos';
insert into public.variants(product_id,sku,stock) select id,'TX-1',7 from products where slug='test-xss';
insert into public.variants(product_id,sku,stock) select id,'TD-1',4 from products where slug='test-draft';
insert into public.product_images(product_id,path,alt,sort) select id,'/img/site/home/cat-clothing.jpg','{"fr":"photo test"}',0 from products where slug in ('test-body','test-oos','test-xss','test-color');
insert into public.product_images(product_id,path,alt,sort) select id,'/img/site/gifts/banner.jpg','{}',0 from products where slug='test-box';
insert into public.product_images(product_id,path,alt,sort) select id,'/img/site/home/cat-gifts.jpg','{}',1 from products where slug='test-box';
update public.products set status='published' where slug <> 'test-draft';
update public.private_settings set value = jsonb_set(jsonb_set(value,'{cod}','{"enabled":true,"instructions":{"fr":"TEST: payez à la livraison"}}'),'{bank}','{"enabled":true,"bank_name":"TEST BANK","holder":"TEST HOLDER","iban":"MA00 0000 0000 0000 0000 0000 000","bic":"TESTMAMC","instructions":{"fr":"TEST: virement sous 48h"}}') where key='payments';
update public.settings set value = '{"fee_cents":3000,"free_over_cents":50000,"note":{}}' where key='delivery';
