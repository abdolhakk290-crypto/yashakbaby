// Web-layer tests: the real production build of the site, talking to a real PostgreSQL (with Supabase stand-in) through the same SQL functions Supabase would call.
import { startSite, makeRunner } from './lib/harness.mjs';
const { T, eq, ok, finish, names } = makeRunner('http-results.json');
const PORT = +(process.env.HTTP_TEST_PORT || 3410);
const site = await startSite({ db: 'yb_http', port: PORT, env: { ORDER_RATE_LIMIT: '15' } });
const { base, sql } = site;
let ipn = 0; const ip = () => `198.51.100.${(++ipn % 250) + 1}`;
const get = (p, h = {}) => fetch(base + p, { redirect: 'manual', headers: h });
const post = (p, body, h = {}, raw) => fetch(base + p, { method: 'POST', redirect: 'manual', headers: { 'content-type': 'application/json', origin: base, 'x-forwarded-for': ip(), ...h }, body: raw ?? JSON.stringify(body) });
const q = async (s, a) => (await sql.query(s, a)).rows;
const vid = async (sku) => +(await q('select id from variants where sku=$1', [sku]))[0].id;
const stock = async (sku) => +(await q('select stock from variants where sku=$1', [sku]))[0].stock;
const text = (html) => html.replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<style[\s\S]*?<\/style>/g, ' ').replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/g, ' ');
const CUST = { name: 'Amina Test', phone: '0612345678', city: 'Essaouira', address: 'Rue des tests 12', email: 'a@b.co' };
const order = (items, o = {}, h = {}) => post('/api/orders', { ...CUST, payment: 'cod', lang: 'fr', items, ...o }, h);
const LANGS = ['ary', 'ar', 'zgh', 'fr', 'en', 'es'];
const settingSet = (k, v) => q(`update settings set value=$2::jsonb where key=$1`, [k, JSON.stringify(v)]);
const settingGet = async (k) => (await q('select value from settings where key=$1', [k]))[0].value;

console.log('\n## Pages, languages, RTL');
await T('/ redirects to a language (cookie > browser language > default)', names('/ redirects to a language'), async () => {
  const a = await get('/'); eq([a.status, new URL(a.headers.get('location'), base).pathname], [307, '/ary']);
  eq(new URL((await get('/', { 'accept-language': 'fr-FR,fr;q=0.9' })).headers.get('location'), base).pathname, '/fr'); eq(new URL((await get('/', { 'accept-language': 'fr', cookie: 'yb_lang=es' })).headers.get('location'), base).pathname, '/es');
  eq(new URL((await get('/', { cookie: 'yb_lang=evil' })).headers.get('location'), base).pathname, '/ary', 'unknown cookie value ignored');
});
await T('every language renders home, category, product, cart, search, contact and all six information pages', [], async () => {
  for (const l of LANGS) for (const p of ['', '/c/clothing', '/p/test-box', '/cart', '/search?q=test', '/contact', ...['about', 'delivery', 'returns', 'faq', 'privacy', 'terms'].map((k) => '/page/' + k)]) { const r = await get(`/${l}${p}`); eq(r.status, 200, `${l}${p}`); }
});
await T('Darija and Arabic pages are right-to-left; French, English, Spanish and Amazigh are left-to-right', names('Arabic page is RTL', 'Amazigh page loads'), async () => {
  for (const [l, d] of [['ary', 'rtl'], ['ar', 'rtl'], ['fr', 'ltr'], ['en', 'ltr'], ['es', 'ltr'], ['zgh', 'ltr']]) { const h = await (await get('/' + l)).text(); ok(h.includes(`<html lang="${l}" dir="${d}">`), l + ' ' + d); }
  const z = await (await get('/zgh')).text(); ok(z.includes('class="zn"'), 'Amazigh draft notice shown');
});
await T('unknown language, product, category or page gives a real 404', [], async () => {
  for (const p of ['/xx', '/fr/p/none', '/fr/c/none', '/fr/page/none', '/fr/nothing-here', '/fr/p/test-draft']) eq((await get(p)).status, 404, p);
  ok((await (await get('/fr/p/none')).text()).includes('404'));
});

console.log('\n## Catalogue from the database');
await T('home lists featured products and categories from the database; draft products never appear anywhere', names('product visible in its category on the storefront'), async () => {
  const h = text(await (await get('/fr')).text()); ok(h.includes('TEST Body') && h.includes('TEST Coffret'), 'featured'); ok(!h.includes('TEST Brouillon'));
  for (const p of ['/fr/c/gifts', '/fr/c/clothing', '/fr/search?q=TEST', '/sitemap.xml']) ok(!(await (await get(p)).text()).includes('Brouillon') && !(await (await get(p)).text()).includes('test-draft'), p);
}, names('product visible in its category on the storefront'));
await T('category page: products, size filter, price sorting; unknown sort values are ignored', [], async () => {
  const c = await (await get('/fr/c/clothing')).text(); ok(c.includes('TEST Body') && c.includes('TEST Épuisé') && !c.includes('TEST Coffret'));
  ok(!text(await (await get('/fr/c/clothing?size=0-3m')).text()).includes('Épuisé'), 'size filter');
  const asc = await (await get('/fr/c/clothing?sort=asc')).text(), desc = await (await get('/fr/c/clothing?sort=desc')).text(); ok(asc.indexOf('TEST Épuisé') < asc.indexOf('TEST Body') && desc.indexOf('TEST Body') < desc.indexOf('TEST Épuisé'), 'sorting');
  eq((await get('/fr/c/clothing?sort=%27;drop%20table%20products;--')).status, 200);
});
await T('empty category shows the empty state and the WhatsApp button, no products', names('empty category shows empty state, no products'), async () => {
  await q(`insert into categories(slug,name,description,sort) values ('vide','{"fr":"Catégorie vide"}','{}',9)`);
  const h = await (await get('/fr/c/vide')).text(); ok(h.includes('class="note"') && h.includes('wa.me/212601668146'), 'empty state'); ok(!h.includes('class="card"'), 'no product cards');
  await q(`delete from categories where slug='vide'`);
});
await T('price and sale price are shown, JSON-LD product data is present and valid', names('price + sale shown, JSON-LD present'), async () => {
  const h = await (await get('/fr/p/test-box')).text(); ok(h.includes('150 DH') && /<s class="small"><bdi class="lat">200 DH/.test(h), 'sale + old price');
  const ld = JSON.parse(h.match(/<script type="application\/ld\+json">(.*?)<\/script>/)[1]); eq([ld['@type'], ld.offers.price, ld.offers.priceCurrency, ld.offers.availability], ['Product', '150.00', 'MAD', 'https://schema.org/InStock']); eq(ld.sku, 'TBOX');
  eq(JSON.parse((await (await get('/fr/p/test-oos')).text()).match(/<script type="application\/ld\+json">(.*?)<\/script>/)[1]).offers.availability, 'https://schema.org/OutOfStock');
});
await T('XSS: hostile product names/descriptions are escaped on product, category, home and search pages and in cart data', names('XSS: product name escaped on the page'), async () => {
  for (const p of ['/fr/p/test-xss', '/fr/c/clothing', '/fr', '/fr/search?q=TEST']) { const h = await (await get(p)).text(); ok(!h.includes('<script>alert('), 'raw script in ' + p); ok(!/<img src=x onerror/.test(h), 'raw img in ' + p); }
  ok((await (await get('/fr/p/test-xss')).text()).includes('&lt;script&gt;alert(1)&lt;/script&gt;'), 'shown as text');
  const c = await (await post('/api/cart', { items: [{ v: await vid('TX-1'), q: 1 }], lang: 'fr' })).json(); ok(c.lines[0].name.includes('<script>'), 'API returns data as JSON text (rendered escaped by React)');
});
await T('search: literal %, quotes and SQL injection are harmless; query reflected only as escaped text; length limited', names('SQL injection in search is harmless'), async () => {
  for (const s of ["' OR 1=1; DROP TABLE products; --", '%', '"><script>alert(1)</script>', 'x'.repeat(500)]) { const r = await get('/fr/search?q=' + encodeURIComponent(s)); eq(r.status, 200); const h = await r.text(); ok(!h.includes('<script>alert(1)</script>'), 'reflected xss'); }
  ok(+(await q('select count(*)::int n from products'))[0].n >= 6, 'table intact'); ok(text(await (await get('/fr/search?q=Coffret')).text()).includes('TEST Coffret'));
  ok(!(await (await get('/fr/search?q=%25')).text()).includes('TEST Body'), 'percent is literal, not a wildcard');
});

console.log('\n## Stock privacy');
await T('customers see only in stock / out of stock: no exact quantity in HTML, page data, or API replies', names(), async () => {
  const bodyStock = await stock('TB-1-A'); eq(bodyStock, 3);
  const bad = /["\\]*(stock|avail|available_qty|inventory|quantity_left|qty_left)["\\]*\s*:\s*\d/i;
  for (const p of ['/fr/p/test-body', '/fr/p/test-color', '/fr/c/clothing', '/fr', '/fr/search?q=TEST']) { const h = await (await get(p)).text(); ok(!bad.test(h), 'numeric stock key in ' + p); ok(!/\b(only|plus que|quedan)\b.{0,12}\b3\b/i.test(text(h)), 'low-stock sentence'); }
  const r = await post('/api/cart', { items: [{ v: await vid('TB-1-A'), q: 2 }, { v: await vid('TB-1-B'), q: 1 }], lang: 'fr' }); const j = await r.json(); const s = JSON.stringify(j); ok(!/avail|stock"/.test(s.replace(/in_stock/g, '')), 'cart reply: ' + s.slice(0, 200));
  eq(j.lines.map((l) => [l.q, l.ok, l.in_stock]), [[2, true, true], [1, false, false]]);
  const o = await order([{ v: await vid('TB-1-A'), q: 9 }]); eq(o.status, 409); const oj = await o.json(); ok(!/"avail"/.test(JSON.stringify(oj)) && oj.lines[0].in_stock === true, JSON.stringify(oj));
});
await T('product page: out-of-stock options are marked unavailable; sold-out product shows "Épuisé"; unavailable product is not buyable', [], async () => {
  const h = await (await get('/fr/p/test-body')).text(); ok(/aria-disabled="false"[^>]*>0-3m</.test(h) && /aria-disabled="true"[^>]*>3-6m</.test(h), 'in-stock size enabled, sold-out size marked unavailable');
  ok(text(await (await get('/fr/c/clothing')).text()).includes('Épuisé'), 'sold-out tag on card');
});

console.log('\n## Sitemap, robots, SEO');
await T('sitemap.xml lists every public page in all six languages with alternates; never drafts, cart, search or admin', names('published product in sitemap', 'draft not in sitemap'), async () => {
  const r = await get('/sitemap.xml'); eq(r.status, 200); ok((r.headers.get('content-type') || '').includes('xml')); const x = await r.text();
  const locs = [...x.matchAll(/<loc>(.*?)<\/loc>/g)].map((m) => m[1]); eq(locs.length, 96, '16 pages x 6 languages'); eq(new Set(locs).size, 96, 'no duplicates');
  for (const l of LANGS) for (const p of ['', '/contact', '/page/returns', '/c/gifts', '/p/test-box', '/p/test-xss']) ok(locs.includes(`${base}/${l}${p}`), `${l}${p}`);
  ok(!x.includes('test-draft') && !x.includes('/cart') && !x.includes('/search') && !x.includes('/admin'));
  eq((x.match(/<url>/g) || []).length, (x.match(/<\/url>/g) || []).length); ok((x.match(/hreflang="ary"/g) || []).length === 96, 'each entry has alternates');
});
await T('robots.txt blocks /admin and /api, lists the sitemap', names('robots.txt blocks /admin and /api, lists sitemap'), async () => {
  const t = await (await get('/robots.txt')).text(); ok(/Disallow: \/admin/.test(t) && /Disallow: \/api\//.test(t) && t.includes(`Sitemap: ${base}/sitemap.xml`), t);
});
await T('admin pages are noindex (header + meta) and /admin redirects to the login when not signed in', names('/admin page is noindex'), async () => {
  const a = await get('/admin'); eq(a.status, 307); ok(new URL(a.headers.get('location'), base).pathname === '/admin/login');
  const l = await get('/admin/login'); ok(/noindex/.test(l.headers.get('x-robots-tag') || ''), 'header'); ok(/<meta name="robots" content="noindex/.test(await l.text()), 'meta');
});
await T('SEO: title/description from settings, canonical + hreflang on pages, noindex on cart and search', names('SEO title + meta applied'), async () => {
  const old = await settingGet('seo'); await settingSet('seo', { pages: { home: { fr: { title: 'SEO-TITRE-TEST', desc: 'seo desc test' } } } });
  const h = await (await get('/fr')).text(); ok(/<title>SEO-TITRE-TEST/.test(h) && h.includes('content="seo desc test"'), 'seo applied'); await settingSet('seo', old);
  const p = await (await get('/fr/p/test-box')).text(); ok(p.includes('rel="canonical" href="http://localhost:' + PORT + '/fr/p/test-box"') && p.includes('hrefLang="es" href="http://localhost:' + PORT + '/es/p/test-box"') && p.includes('hrefLang="ary"'), 'canonical + alternates');
  for (const u of ['/fr/cart', '/fr/search']) ok(/<meta name="robots" content="noindex/.test(await (await get(u)).text()), u);
});

console.log('\n## Content edited by the owner is live and safe');
await T('headline, translations and information pages edited in the database appear immediately, HTML-escaped', names('homepage headline editable', 'translation override live', 'edited page live and HTML-escaped'), async () => {
  const home = await settingGet('home'); await settingSet('home', { ...home, hero: { ...home.hero, title: { fr: 'HEADLINE-TEST' } } }); ok((await (await get('/fr')).text()).includes('HEADLINE-TEST')); await settingSet('home', home);
  await q(`insert into translations(lang,key,value) values ('fr','hero_s','HERO-OVERRIDE <b>x</b>') on conflict (lang,key) do update set value=excluded.value`); const h = await (await get('/fr')).text(); ok(h.includes('HERO-OVERRIDE &lt;b&gt;x&lt;/b&gt;'), 'override shown escaped'); await q(`delete from translations where key='hero_s'`);
  await q(`insert into pages(key,lang,title,blocks) values ('about','fr','Titre <i>x</i>','[["p","<script>alert(9)</script> {mail}"]]')`); const a = await (await get('/fr/page/about')).text();
  ok(!a.includes('<script>alert(9)') && a.includes('&lt;script&gt;alert(9)') && a.includes('babyyashak@gmail.com'), 'escaped + placeholder replaced'); await q(`delete from pages where key='about'`);
});

console.log('\n## WhatsApp');
await T('product page has the WhatsApp inquiry button with the owner\'s real number; message has product, price, SKU, size, colour, quantity and link', names('WhatsApp button present on product page'), async () => {
  const h = await (await get('/fr/p/test-color')).text(); const m = h.match(/id="wab"[^>]*href="(https:\/\/wa\.me\/[^"]+)"|href="(https:\/\/wa\.me\/[^"]+)"[^>]*id="wab"/); ok(m, 'button'); const u = new URL((m[1] || m[2]).replace(/&amp;/g, '&'));
  eq(u.pathname, '/212601668146'); const msg = u.searchParams.get('text'); ok(msg.startsWith('Bonjour YASHAK BABY'), msg); ok(msg.includes('TEST Couleur') && msg.includes('50 DH') && msg.includes(`${base}/fr/p/test-color`), msg);
}, names('WhatsApp link opens wa.me with the configured number'));
await T('turning the product WhatsApp switch off, or disabling WhatsApp, hides the button; a different number is used immediately', names('disabling product WhatsApp hides the button'), async () => {
  const w = await settingGet('whatsapp'); await settingSet('whatsapp', { ...w, show_product: false }); ok(!(await (await get('/fr/p/test-box')).text()).includes('id="wab"'));
  await settingSet('whatsapp', { ...w, number: '212611111111' }); ok((await (await get('/fr/p/test-box')).text()).includes('wa.me/212611111111'));
  await settingSet('whatsapp', { ...w, enabled: false, number: '' }); const h = await (await get('/fr/contact')).text(); ok(!h.includes('wa.me')); await settingSet('whatsapp', w);
});

console.log('\n## Legal hold: returns policy not published');
await T('the 24-hour return window is not shown anywhere on the public site in any language (home, info pages, FAQ, cart, product, contact)', names(), async () => {
  const win = /\b24\b|٢٤/;
  for (const l of LANGS) for (const p of ['', '/page/returns', '/page/delivery', '/page/faq', '/page/about', '/page/terms', '/page/privacy', '/contact', '/cart', '/p/test-box', '/c/gifts']) { const t = text(await (await get(`/${l}${p}`)).text()); ok(!win.test(t), `${l}${p}: ${(t.match(/.{30}(\b24\b|٢٤).{30}/) || [''])[0]}`); }
  ok(text(await (await get('/fr/page/returns')).text()).includes('en cours de finalisation'), 'notice shown instead'); ok(text(await (await get('/fr')).text()).includes('Politique en cours de finalisation'), 'home card');
});
await T('the policy text stays unchanged (strictly 24 hours) and appears only after the owner publishes it', [], async () => {
  const old = await q(`select value from settings where key='legal'`); eq(old[0].value, { returns_published: false }, 'seed default is unpublished');
  await settingSet('legal', { returns_published: true }); const r = text(await (await get('/fr/page/returns')).text()); ok(/dans les 24 heures/.test(r) && !/7 jours|7 days/.test(r), 'rule shown once published'); ok(/24 heures/.test(text(await (await get('/fr/page/faq')).text()))); await settingSet('legal', { returns_published: false });
  ok(!/\b24\b/.test(text(await (await get('/fr/page/returns')).text())), 'hidden again');
});

console.log('\n## Security headers and request protection');
await T('security headers: strict CSP with a new nonce per request (no unsafe-inline for scripts), nosniff, frame deny, referrer policy', names('security headers (CSP, nosniff, frame deny)'), async () => {
  const a = await get('/fr'), b = await get('/fr'); const ca = a.headers.get('content-security-policy'), cb = b.headers.get('content-security-policy');
  const sa = ca.match(/script-src ([^;]*)/)[1]; ok(!sa.includes("'unsafe-inline'") && !sa.includes('unsafe-eval') && sa.includes("'nonce-") && sa.includes("'strict-dynamic'"), sa);
  ok(ca !== cb, 'nonce differs per request'); for (const d of ["frame-ancestors 'none'", "object-src 'none'", "base-uri 'self'", "form-action 'self'", "default-src 'self'"]) ok(ca.includes(d), d);
  eq([a.headers.get('x-content-type-options'), a.headers.get('x-frame-options')], ['nosniff', 'DENY']); ok(a.headers.get('referrer-policy') && a.headers.get('permissions-policy') && a.headers.get('strict-transport-security'));
  const html = await a.text(), nonce = ca.match(/'nonce-([^']+)'/)[1]; const scripts = [...html.matchAll(/<script\b([^>]*)>/g)].map((m) => m[1]).filter((x) => !/application\/ld\+json/.test(x)); ok(scripts.length > 3);
  ok(scripts.every((s) => s.includes(`nonce="${nonce}"`)), 'every executable script carries this request\'s nonce: ' + scripts.filter((s) => !s.includes(nonce))[0]);
  ok(!/\son(click|load|error)=/i.test(html), 'no inline event handlers');
});
await T('CSRF/origin protection (replaces the old CSRF-token check; the new site has no cookie session on public writes): writes need a same-site Origin (or Sec-Fetch-Site) and JSON; cross-site, form-encoded, malformed or oversized requests are refused', names('wrong CSRF token rejected', 'cross-origin write rejected'), async () => {
  const body = { items: [{ v: await vid('TBOX-1'), q: 1 }], lang: 'fr' };
  eq((await post('/api/cart', body, { origin: 'https://evil.example' })).status, 403); eq((await post('/api/cart', body, { origin: 'null' })).status, 403);
  eq((await post('/api/cart', body, { origin: '' })).status, 403, 'no origin, no fetch metadata'); eq((await post('/api/cart', body, { origin: '', 'sec-fetch-site': 'cross-site' })).status, 403);
  eq((await post('/api/cart', body, { origin: '', 'sec-fetch-site': 'same-origin' })).status, 200, 'same-origin fetch metadata is accepted');
  eq((await post('/api/orders', body, { 'content-type': 'application/x-www-form-urlencoded' }, 'a=b')).status, 415); eq((await post('/api/orders', body, { 'content-type': 'text/plain' }, '{}')).status, 415);
  eq((await post('/api/orders', null, {}, '{not json')).status, 400); eq((await post('/api/orders', null, {}, '[1,2]')).status, 400); eq((await post('/api/cart', null, {}, '"str"')).status, 400);
  eq((await post('/api/orders', null, {}, JSON.stringify({ note: 'x'.repeat(60000) }))).status, 413);
  eq((await get('/api/orders')).status, 405); eq((await get('/api/cart')).status, 405);
  eq(+(await q('select count(*)::int n from orders'))[0].n, 0, 'nothing was created by refused requests');
});

console.log('\n## Cart pricing');
await T('cart prices come from the database: browser-sent prices are ignored; unknown items dropped; totals and delivery correct', names('cart lists the product with server price'), async () => {
  const body = { items: [{ v: await vid('TB-1-A'), q: 2, price: 1, unit: 1 }, { v: 999999, q: 1 }, { v: 'x', q: 1 }, { v: await vid('TBOX-1'), q: 1 }], lang: 'fr', total: 5 };
  const j = await (await post('/api/cart', body)).json(); const live = j.lines.filter((l) => !l.gone);
  eq(live.map((l) => [l.unit, l.q]), [[9000, 2], [15000, 1]]); eq([j.subtotal, j.delivery, j.total, j.sym, j.deliverySet], [33000, 3000, 36000, 'DH', true]); ok(j.lines.some((l) => l.gone), 'unknown variant flagged');
  eq(j.methods.map((m) => m.key), ['bank', 'cod']); ok(!JSON.stringify(j).includes('MA00'), 'no bank details in the cart reply');
  const free = await (await post('/api/cart', { items: [{ v: await vid('TBOX-1'), q: 4 }] })).json(); eq([free.subtotal, free.delivery, free.total], [60000, 0, 60000], 'free delivery over the threshold');
});

console.log('\n## Orders');
await T('order with cash on delivery: stored with server prices, stock reduced, number returned, customer text kept as text', names('order placed, number shown'), async () => {
  const before = await stock('TB-1-A'); const r = await order([{ v: await vid('TB-1-A'), q: 1, price: 1 }], { total: 1, address: '<b>Rue</b> \'; DROP TABLE orders;--' }); eq(r.status, 201); const j = await r.json();
  ok(/^YB-\d{6}$/.test(j.number), j.number); eq([j.method, j.total, j.delivery], ['cod', 12000, 3000]); ok(j.instructions.includes('TEST: payez')); eq(j.wa, '212601668146');
  eq(await stock('TB-1-A'), before - 1); const o = (await q('select * from orders where number=$1', [j.number]))[0]; eq([o.status, o.subtotal_cents, o.total_cents, o.payment_status, o.address], ['pending', 9000, 12000, 'unpaid', '<b>Rue</b> \'; DROP TABLE orders;--']);
});
await T('order with bank transfer returns the bank details only after the order exists; free delivery above the threshold', [], async () => {
  const r = await order([{ v: await vid('TBOX-1'), q: 4 }], { payment: 'bank' }); eq(r.status, 201); const j = await r.json(); eq([j.method, j.total, j.delivery], ['bank', 60000, 0]); eq(j.bank.iban, 'MA00 0000 0000 0000 0000 0000 000'); eq(j.bank.holder, 'TEST HOLDER');
  eq((await q('select payment_status from orders where number=$1', [j.number]))[0].payment_status, 'awaiting_transfer');
});
await T('input validation on the server: missing/invalid fields, wrong payment method, empty cart, bad quantities, hostile and control characters', names('invalid name refused', 'invalid email refused', 'unknown variant refused'), async () => {
  const v = await vid('TBOX-1'), n0 = +(await q('select count(*)::int n from orders'))[0].n;
  const bad = async (o, status, field) => { const r = await order([{ v, q: 1 }], o); eq(r.status, status, JSON.stringify(o).slice(0, 70)); if (field) ok(field in (await r.json()).fields, 'field ' + field); };
  await bad({ name: '' }, 422, 'name'); await bad({ name: 'A' }, 422, 'name'); await bad({ name: 'x'.repeat(100) }, 422, 'name'); await bad({ phone: 'abc' }, 422, 'phone'); await bad({ phone: '123' }, 422, 'phone'); await bad({ phone: '0612345678901234567' }, 422, 'phone');
  await bad({ address: 'abc' }, 422, 'address'); await bad({ city: ' ' }, 422, 'city'); await bad({ email: 'nope' }, 422, 'email'); await bad({ payment: 'online' }, 422, 'payment'); await bad({ payment: '' }, 422, 'payment'); await bad({ payment: 12 }, 422, 'payment');
  for (const items of [[], [{ v, q: 0 }], [{ v, q: -2 }], [{ v, q: 51 }], [{ v: 'x', q: 1 }], [{ v: null, q: null }], 'x', null]) eq((await order(items)).status, 422, JSON.stringify(items));
  eq((await order([{ v: 987654, q: 1 }])).status, 409, 'unknown variant'); eq((await order([{ v: await vid('TO-1'), q: 1 }])).status, 409, 'sold out'); eq((await order([{ v: await vid('TD-1'), q: 1 }])).status, 409, 'draft product');
  eq((await order([{ v, q: 1 }], { name: 'Null\u0000Byte\u0007 Test' })).status, 201, 'control characters are stripped, not fatal'); eq((await q(`select name from orders where name like 'NullByte%'`))[0].name, 'NullByte Test');
  eq((await order([{ v, q: 1 }], { name: 'عائشة 🌸 Émilie', city: 'الصويرة', address: 'زنقة 12، حي تافوكت' })).status, 201, 'Arabic, emoji and accents accepted');
  eq((await q('select count(*)::int n from orders'))[0].n - n0, 2, 'only the two valid orders were stored');
});
await T('browser-sent fields cannot change the price: price, total, unit, subtotal, status are ignored', [], async () => {
  const r = await order([{ v: await vid('TBOX-1'), q: 1, price: 1, unit_cents: 1 }], { total: 1, subtotal: 1, status: 'delivered', delivery: 0, payment_status: 'paid' }); eq(r.status, 201);
  const o = (await q('select status,payment_status,total_cents from orders order by id desc limit 1'))[0]; eq([o.status, o.payment_status, o.total_cents], ['pending', 'unpaid', 18000]);
});
await T('rejected orders (stock, validation) reserve nothing', names('overselling refused (409)'), async () => {
  const s0 = await stock('TC-SR'); eq((await order([{ v: await vid('TC-SR'), q: 5 }])).status, 409); eq((await order([{ v: await vid('TC-SR'), q: 1 }, { v: await vid('TC-MR'), q: 1 }])).status, 409, 'one sold-out line refuses the whole order');
  eq(await stock('TC-SR'), s0, 'nothing reserved');
});
await T('12 simultaneous HTTP orders for 4 units: exactly 4 are accepted, 8 get a stock conflict, stock ends at 0 and totals add up', names('stock never negative'), async () => {
  await q(`update variants set stock=4 where sku='TC-SB'`); const v = await vid('TC-SB');
  const rs = await Promise.all(Array.from({ length: 12 }, (_, i) => order([{ v, q: 1 }], { phone: '06111100' + String(i).padStart(2, '0') }))); const codes = rs.map((r) => r.status).sort();
  eq(codes.filter((c) => c === 201).length, 4, codes.join()); eq(codes.filter((c) => c === 409).length, 8); eq(await stock('TC-SB'), 0); eq(+(await q('select coalesce(sum(qty),0)::int s from order_items where variant_id=$1', [v]))[0].s, 4);
  ok(!/Server error/.test(site.log()), 'no server errors in log');
});
await T('order rate limit: the 16th order attempt from one address in an hour is refused with 429 (other addresses unaffected)', names('login brute force is rate-limited (429)'), async () => {
  const h = { 'x-forwarded-for': '203.0.113.77' }; const codes = []; for (let i = 0; i < 17; i++) codes.push((await post('/api/orders', { lang: 'fr', items: [] }, h)).status);
  eq(codes.slice(0, 15).every((c) => c === 422), true, codes.join()); eq(codes.slice(15), [429, 429]); eq((await order([{ v: await vid('TBOX-1'), q: 1 }], {}, { 'x-forwarded-for': '203.0.113.78' })).status, 201, 'another address still works');
}, names('login brute force is rate-limited (429)'));
await T('no server errors or stack traces were produced during the whole run', [], async () => { const l = site.log(); ok(!/Error:|TypeError|ECONN|unhandled/i.test(l.replace(/cart error|order error/g, '')), l.slice(-400)); });

await site.stop(); process.exit(finish() ? 1 : 0);
