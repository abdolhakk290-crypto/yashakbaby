#!/bin/sh
# Starts the throw-away local PostgreSQL used by the tests (idempotent).
B=$(ls -d /usr/lib/postgresql/*/bin | head -1)
pg_isready -h /tmp -p 54329 >/dev/null 2>&1 && exit 0
rm -f /tmp/pgdata/postmaster.pid
(su postgres -c "$B/pg_ctl -D /tmp/pgdata -o '-p 54329 -k /tmp' -l /tmp/pg.log start" 2>/dev/null || $B/pg_ctl -D /tmp/pgdata -o '-p 54329 -k /tmp' -l /tmp/pg.log start) >/dev/null 2>&1
sleep 3; pg_isready -h /tmp -p 54329
