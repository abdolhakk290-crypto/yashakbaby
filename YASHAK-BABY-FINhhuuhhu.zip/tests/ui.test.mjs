// Browser tests (Playwright, real Chromium) of the storefront: options, quantity, WhatsApp, cart, checkout, RTL, dark mode, mobile overflow, console errors.
import { startSite, makeRunner, ROOT } from './lib/harness.mjs'; import { createRequire } from 'module'; import fs from 'fs'; import path from 'path';
const { T, eq, ok, finish, names } = makeRunner('ui-results.json');
const { chromium } = createRequire(import.meta.url)(process.env.PW_PATH || 'playwright');
const site = await startSite({ db: 'yb_ui', port: +(process.env.UI_TEST_PORT || 3420), env: { ORDER_RATE_LIMIT: '1000' } });
const { base, sql } = site; const SH = path.join(ROOT, 'tests/results/shots'); fs.mkdirSync(SH, { recursive: true });
const browser = await chromium.launch();
const errors = [];
async function newPage(opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'fr-FR', ...opts }); const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('requestfailed', (r) => errors.push('requestfailed: ' + r.url())); page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('/p/none')) errors.push(`http ${r.status()}: ${r.url()}`); });
  return { ctx, page };
}
const hscroll = (page) => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
const { ctx, page } = await newPage();

console.log('\n## Storefront in a real browser (phone size)');
await T('home loads with header, categories and featured products', [], async () => {
  await page.goto(base + '/fr'); await page.waitForSelector('.cat'); ok((await page.locator('.cat').count()) === 3); ok((await page.locator('.card').count()) >= 2, 'featured products'); await page.screenshot({ path: SH + '/home-fr-mobile.png', fullPage: true });
});
await T('product page: adding without choosing a size is refused with a message (no silent add)', names('selecting options is required (no silent add)'), async () => {
  await page.goto(base + '/fr/p/test-body'); await page.click('#addb'); eq(await page.textContent('#err'), 'Choisissez une option'); eq(await page.evaluate(() => localStorage.getItem('yb-cart2')), null);
});
await T('sold-out size cannot be selected; in-stock size can; status says "En stock" without any number', [], async () => {
  await page.click('button.chip:has-text("3-6m")', { force: true }); eq(await page.getAttribute('button.chip:has-text("3-6m")', 'aria-pressed'), 'false'); await page.click('button.chip:has-text("0-3m")');
  eq(await page.getAttribute('button.chip:has-text("0-3m")', 'aria-pressed'), 'true'); eq((await page.textContent('#pstock')).trim(), 'En stock'); ok(!/\d/.test(await page.textContent('#pstock')), 'no number');
});
await T('quantity stepper works and never goes below 1', names('quantity stepper works'), async () => {
  const q = () => page.textContent('#qv'); eq(await q(), '1'); await page.click('.qr button[aria-label="−"]'); eq(await q(), '1'); await page.click('.qr button[aria-label="+"]'); await page.click('.qr button[aria-label="+"]'); eq(await q(), '3'); await page.click('.qr button[aria-label="−"]'); eq(await q(), '2');
});
await T('WhatsApp button opens wa.me with the configured number; the message lists product, price, SKU, size, quantity and link and follows the choices', names('WhatsApp link opens wa.me with the configured number', 'WhatsApp message has product, price, SKU, size, color, quantity and URL'), async () => {
  const u = new URL(await page.getAttribute('#wab', 'href')); eq(u.hostname + u.pathname, 'wa.me/212601668146'); const m = u.searchParams.get('text');
  for (const part of ['TEST Body', '90 DH', 'TB-1-A', '0-3m', 'Quantité: 2', `${base}/fr/p/test-body`]) ok(m.includes(part), part + ' in ' + m); eq(await page.getAttribute('#wab', 'target'), '_blank'); ok((await page.getAttribute('#wab', 'rel')).includes('noopener'));
});
await T('adding to the cart shows a confirmation and the cart badge shows 2', names('cart badge shows 2'), async () => {
  await page.click('#addb'); await page.waitForSelector('#toast:not([hidden])'); eq((await page.textContent('#toast')).trim(), 'Ajouté au panier'); eq((await page.textContent('#ccount')).trim(), '2'); await page.screenshot({ path: SH + '/product-mobile.png', fullPage: true });
});
await T('cart lists the product with the server price, delivery and total', names('cart lists the product with server price'), async () => {
  await page.goto(base + '/fr/cart'); await page.waitForSelector('.ci'); const t = await page.textContent('#app'); ok(t.includes('TEST Body') && t.includes('180 DH') && t.includes('30 DH') && t.includes('210 DH'), t.replace(/\s+/g, ' ').slice(0, 300));
  await page.evaluate(() => localStorage.setItem('yb-cart2', JSON.stringify([{ v: 1, q: 2 }]))); await page.reload(); await page.waitForSelector('.ci'); ok((await page.textContent('#app')).includes('180 DH'), 'price re-read from server, not from the browser');
});
await T('empty checkout shows validation errors and sends nothing', names('empty checkout shows validation errors'), async () => {
  await page.click('button[type=submit]'); await page.waitForSelector('.ferr:not(:empty)'); const n = await page.locator('.ferr:not(:empty)').count(); eq(n, 4); eq(+(await sql.query('select count(*)::int n from orders')).rows[0].n, 0);
  await page.fill('#f-name', 'Amina'); await page.fill('#f-phone', '12ab'); await page.fill('#f-city', 'Essaouira'); await page.fill('#f-address', 'Rue 1, n 2'); await page.click('button[type=submit]'); eq((await page.textContent('#f-phone ~ .ferr')).trim(), 'Numéro de téléphone invalide');
});
await T('placing an order shows the order number and the payment instructions, empties the cart and reduces the stock', names('order placed, number shown', 'cart emptied after order'), async () => {
  await page.fill('#f-phone', '0612345678'); await page.check('input[value=bank]'); const before = +(await sql.query(`select stock from variants where sku='TB-1-A'`)).rows[0].stock;
  await page.click('button[type=submit]'); await page.waitForSelector('.thanks'); const t = await page.textContent('.thanks'); ok(/YB-\d{6}/.test(t), t); ok(t.includes('TEST HOLDER') && t.includes('MA00 0000'), 'bank details shown after the order');
  eq(await page.evaluate(() => localStorage.getItem('yb-cart2')), '[]'); eq(await page.locator('#ccount').isHidden(), true, 'badge hidden');
  eq(+(await sql.query(`select stock from variants where sku='TB-1-A'`)).rows[0].stock, before - 2, 'stock reduced by 2'); await page.screenshot({ path: SH + '/order-done-mobile.png', fullPage: true });
}, names('inventory shows stock 1 after reserving 2 of 3'));
await T('a product whose stock ran out while it was in the cart blocks the order with a clear message', [], async () => {
  await page.evaluate(() => localStorage.setItem('yb-cart2', JSON.stringify([{ v: 1, q: 1 }]))); await sql.query(`update variants set stock=0 where sku='TB-1-A'`); await page.goto(base + '/fr/cart'); await page.waitForSelector('.ci .err');
  ok(await page.locator('button[type=submit]').isDisabled(), 'order button disabled'); await sql.query(`update variants set stock=1 where sku='TB-1-A'`);
});

console.log('\n## Languages, RTL, dark mode, mobile layout');
await T('Darija page is right-to-left and uses Arabic text; language menu keeps the current page and remembers the choice', names('Darija page is RTL'), async () => {
  await page.goto(base + '/ary'); eq(await page.evaluate(() => [document.documentElement.dir, getComputedStyle(document.body).direction]), ['rtl', 'rtl']); await page.screenshot({ path: SH + '/home-ary-mobile.png', fullPage: true });
  await page.goto(base + '/fr/p/test-box'); await page.click('#lbtn'); await page.click('a.lopt:has-text("English")'); await page.waitForURL('**/en/p/test-box'); ok((await page.context().cookies()).some((c) => c.name === 'yb_lang' && c.value === 'en'));
});
await T('no horizontal scrolling on a phone in any language (home, category, product, cart, search, info pages)', names('no horizontal scroll on mobile (RTL home)'), async () => {
  for (const l of ['ary', 'ar', 'zgh', 'fr', 'en', 'es']) for (const p of ['', '/c/gifts', '/p/test-color', '/cart', '/search?q=test', '/page/faq', '/contact']) { await page.goto(`${base}/${l}${p}`); const d = await hscroll(page); ok(d <= 0, `${l}${p} overflows by ${d}px`); }
});
await T('dark mode: dark background with readable text on home, product and cart; light mode unchanged', [], async () => {
  const lum = (c) => { const [r, g, b] = c.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  const contrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05); };
  const dark = await newPage({ colorScheme: 'dark' }), light = await newPage({ colorScheme: 'light' });
  for (const p of ['/fr', '/fr/p/test-box', '/fr/cart', '/ary']) {
    await dark.page.goto(base + p); await light.page.goto(base + p); const cd = await dark.page.evaluate(() => [getComputedStyle(document.body).backgroundColor, getComputedStyle(document.body).color]), cl = await light.page.evaluate(() => [getComputedStyle(document.body).backgroundColor, getComputedStyle(document.body).color]);
    ok(lum(cd[0]) < 0.1 && lum(cl[0]) > 0.5, `${p} bg dark=${cd[0]} light=${cl[0]}`); ok(contrast(cd[0], cd[1]) >= 7 && contrast(cl[0], cl[1]) >= 7, `${p} contrast`);
    const ft = await dark.page.evaluate(() => { const f = document.querySelector('.ft'), a = f.querySelector('a'); return [getComputedStyle(f).backgroundColor, getComputedStyle(a).color]; }); ok(contrast(ft[0], ft[1]) >= 4.5, `${p} footer link contrast ${ft}`);
  }
  await dark.page.goto(base + '/fr'); await dark.page.screenshot({ path: SH + '/home-fr-dark.png', fullPage: true }); await dark.ctx.close(); await light.ctx.close();
});
await T('desktop layout: home, category and product pages render without overflow or errors', [], async () => {
  const d = await newPage({ viewport: { width: 1280, height: 800 }, isMobile: false, hasTouch: false, deviceScaleFactor: 1 });
  for (const p of ['/fr', '/fr/c/clothing', '/fr/p/test-box', '/ary', '/ary/p/test-box']) { await d.page.goto(base + p); ok((await hscroll(d.page)) <= 0, p); } await d.page.goto(base + '/fr/p/test-box'); await d.page.screenshot({ path: SH + '/product-desktop.png' }); await d.ctx.close();
});
await T('keyboard: language menu opens with Enter and closes with Escape; focus is visible on links and buttons', [], async () => {
  await page.goto(base + '/fr'); await page.focus('#lbtn'); await page.keyboard.press('Enter'); ok(await page.locator('#lmenu').isVisible()); await page.keyboard.press('Escape'); ok(await page.locator('#lmenu').isHidden());
  await page.focus('.logo'); const o = await page.evaluate(() => { const s = getComputedStyle(document.activeElement); return s.outlineStyle !== 'none' || s.boxShadow !== 'none'; }); ok(o, 'focus ring');
});
await T('no JavaScript errors, failed requests, CSP violations or error responses anywhere during the whole browser run', names('no JavaScript errors anywhere'), async () => { eq(errors, []); });

await browser.close(); await site.stop(); process.exit(finish() ? 1 : 0);
