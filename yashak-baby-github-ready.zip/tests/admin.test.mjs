// Admin dashboard tests in a REAL browser against the production build, REAL PostgREST + real database rules.
// Emulated (clearly NOT real Supabase): sign-in service (/auth/v1) and the file-storage service (/storage/v1). Real GoTrue, two-step verification and the real Storage service are not covered here.
import { startSite, makeRunner, ROOT, PW, OWNER, ADMIN, CLIENT } from './lib/harness.mjs'; import { createRequire } from 'module'; import fs from 'fs'; import path from 'path';
import { SERVICE_KEY, SUPABASE_URL } from './lib/env.mjs';
const { T, eq, ok, finish, names } = makeRunner('admin-results.json');
const { chromium } = createRequire(import.meta.url)(process.env.PW_PATH || 'playwright');
const site = await startSite({ db: 'yb_admin', port: +(process.env.ADMIN_TEST_PORT || 3430), env: { ORDER_RATE_LIMIT: '1000' } });
const { base, sql, mediaDir } = site; const SH = path.join(ROOT, 'tests/results/shots'); fs.mkdirSync(SH, { recursive: true });
const browser = await chromium.launch();
const errors = [];
async function newPage(opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 900 }, locale: 'fr-FR', ...opts }); const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  return { ctx, page };
}
const login = async (page, who = ADMIN, pw = PW) => { await page.goto(base + '/admin/login'); await page.fill('input[type=email]', who.email); await page.fill('input[type=password]', pw); await page.click('button'); };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const SVG = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
const hscroll = (page) => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
const idOf = (url) => +new URL(url).pathname.split('/').pop();
const pubJson = async (slug, lang = 'fr') => (await fetch(`${base}/${lang}/p/${slug}`, { redirect: 'manual' }));
const act = async (page, loc) => { await Promise.all([page.waitForResponse((r) => r.request().method() === 'POST'), loc.click()]); await page.waitForLoadState('networkidle'); };   // click, wait for the server action, wait for the page to settle
const files = (d) => { try { return fs.readdirSync(path.join(mediaDir, d)); } catch { return []; } };

console.log('\n## Access control (nobody signed in)');
const ADMIN_PAGES = ['/admin/security', '/admin/dashboard', '/admin', '/admin/products', '/admin/products/new', '/admin/products/1', '/admin/categories', '/admin/content', '/admin/settings', '/admin/orders', '/admin/orders/1'];
await T('every admin page redirects an anonymous visitor to the login page', [], async () => {
  for (const p of ADMIN_PAGES) { const r = await fetch(base + p, { redirect: 'manual' }); ok([302, 303, 307, 308].includes(r.status), p + ' status ' + r.status); ok(new URL(r.headers.get('location'), base).pathname === '/admin/login', p + ' -> ' + r.headers.get('location')); }
});
await T('admin actions (POST) are refused for anonymous visitors, including the upload route', [], async () => {
  const r = await fetch(base + '/admin/products', { method: 'POST', redirect: 'manual', headers: { 'next-action': 'deadbeef', origin: base, 'content-type': 'text/plain' }, body: '[]' }); ok([302, 303, 307, 308].includes(r.status), 'POST /admin/products: ' + r.status);
  const fd = () => { const f = new FormData(); f.set('target', 'product'); f.set('product', '1'); f.set('file', new Blob([PNG], { type: 'image/png' }), 'a.png'); return f; };
  eq((await fetch(base + '/api/admin/upload', { method: 'POST', body: fd(), headers: { origin: base } })).status, 401);
  eq((await fetch(base + '/api/admin/upload', { method: 'POST', body: fd() })).status, 403);
  eq((await fetch(base + '/api/admin/upload', { method: 'POST', body: fd(), headers: { origin: 'https://evil.example' } })).status, 403);
  eq((await fetch(base + '/api/admin/upload')).status, 405);
  eq(files('products').length, 0, 'nothing was stored');
});
await T('the admin area is not indexed and never cached', names('/admin page is noindex', 'robots.txt blocks /admin and /api, lists sitemap'), async () => {
  const r = await fetch(base + '/admin/login'); const h = await r.text(); ok(/noindex/.test(h)); ok(/no-store/.test(r.headers.get('cache-control') || ''));
  const rb = await (await fetch(base + '/robots.txt')).text(); ok(/Disallow: \/admin/.test(rb) && /Disallow: \/api/.test(rb) && /Sitemap:/i.test(rb), 'robots.txt hides /admin and /api and lists the sitemap');
});

console.log('\n## Login and logout');
const { ctx, page } = await newPage();
await T('wrong password is refused with a clear message and no session', names('wrong password shows an error'), async () => {
  const resp = page.waitForResponse((r) => r.url().includes('/auth/v1/token')); await login(page, ADMIN, 'nope-nope'); eq((await resp).status(), 400, 'the sign-in service itself rejected it'); await page.waitForSelector('[role=alert]:not(:empty)'); ok((await page.textContent('[role=alert]')).length > 3); ok(page.url().endsWith('/admin/login'));
  eq((await ctx.cookies()).filter((c) => /auth-token/.test(c.name)).length, 0);
});
await T('a signed-in customer who is NOT an administrator cannot open any admin page or use the upload route', [], async () => {
  const { ctx: c2, page: p2 } = await newPage(); await login(p2, CLIENT); await p2.waitForTimeout(1500);
  for (const p of ADMIN_PAGES) { await p2.goto(base + p); ok(new URL(p2.url()).pathname === '/admin/login', p + ' -> ' + p2.url()); }
  await login(p2, CLIENT); await p2.waitForSelector('[role=alert]:not(:empty)'); ok((await p2.textContent('[role=alert]')).includes('Access denied'), 'clear denial message'); ok(!p2.url().includes('/admin/dashboard'), 'not sent to the dashboard');
  await p2.goto(base + '/admin/dashboard'); await p2.waitForURL(/\/admin\/login/);
  const r = await c2.request.post(base + '/api/admin/upload', { headers: { origin: base }, multipart: { target: 'product', product: '1', file: { name: 'a.png', mimeType: 'image/png', buffer: PNG } }, maxRedirects: 0 }); eq(r.status(), 401);
  await c2.close();
});
await T('administrator signs in, sees the dashboard in French, and the public site is unaffected', names('login → dashboard', 'login screen shown'), async () => {
  await login(page); await page.waitForURL('**/admin/dashboard'); ok((await page.textContent('h1')).includes('Tableau de bord')); ok((await page.textContent('body')).includes(ADMIN.email));
  await page.screenshot({ path: SH + '/admin-dashboard.png' });
});
await T('logout ends the session: admin pages redirect to login again', [], async () => {
  await page.click('text=Se déconnecter'); await page.waitForURL('**/admin/login'); await page.goto(base + '/admin/products'); ok(page.url().endsWith('/admin/login'));
  await login(page); await page.waitForURL('**/admin/dashboard');
});

console.log('\n## Products: create, edit, publish, price, availability, delete');
let PID, SLUG = 'robe-test-admin', catOpts;
await T('create a product (names, price, category, size/colour with stock) and see it on the public website', names('product created in UI, editor reopened', 'slug generated'), async () => {
  await page.goto(base + '/admin/products/new'); await page.waitForLoadState('networkidle');
  await page.fill('input[name=name_fr]', 'Robe Test Admin'); await page.locator('details.a-lang summary', { hasText: 'الدارجة' }).click(); await page.fill('input[name=name_ary]', 'روبة تيست'); await page.fill('textarea[name=desc_fr]', 'Une jolie robe.');
  await page.fill('input[name=price]', '150'); catOpts = await page.locator('select[name=category] option').allTextContents(); await page.selectOption('select[name=category]', { index: 1 });
  await page.selectOption('select[name=status]', 'published'); await page.fill('input[name=v0_size]', '3-6m'); await page.fill('input[name=v0_color]', 'Rose'); await page.fill('input[name=v0_stock]', '4');
  await page.click('.a-sticky .a-btn'); await page.waitForURL(/\/admin\/products\/\d+\?ok=1/); PID = idOf(page.url().split('?')[0]); ok(await page.locator('.a-ok').count());
  eq(await page.inputValue('input[name=slug]'), SLUG);
  const r = await fetch(`${base}/fr/p/${SLUG}`); eq(r.status, 200); const h = await r.text(); ok(h.includes('Robe Test Admin') && h.includes('150')); ok(h.includes('3-6m'));
  ok((await (await fetch(`${base}/ary/p/${SLUG}`)).text()).includes('روبة تيست'), 'Darija name');
});
await T('public page shows only "in stock", never the exact stock number or any admin data', [], async () => {
  const h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(/En stock/i.test(h)); ok(!/"stock"\s*:\s*\d/.test(h) && !/"avail"/.test(h), 'no stock data in page payload');
  ok(!h.includes(SERVICE_KEY) && !/service_role/.test(h) && !/admin_/.test(h), 'no admin or key material');
});
await T('validation: missing name, invalid price, sale price not below price → clear error messages and nothing saved', [], async () => {
  const before = +(await sql.query('select count(*)::int n from products')).rows[0].n;
  await page.goto(base + '/admin/products/new'); await page.fill('input[name=price]', '10'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/err=/); ok((await page.textContent('.a-er')).includes('nom'));
  await page.goto(base + '/admin/products/new'); await page.fill('input[name=name_fr]', 'X'); await page.fill('input[name=price]', '100'); await page.fill('input[name=sale]', '100'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/err=/); ok((await page.textContent('.a-er')).includes('promotionnel'));
  eq(+(await sql.query('select count(*)::int n from products')).rows[0].n, before);
});
await T('edit the price (and a sale price): the public page changes at once', [], async () => {
  await page.goto(`${base}/admin/products/${PID}`); await page.fill('input[name=price]', '120,50'); await page.fill('input[name=sale]', '99'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  let h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(h.includes('99 DH'), 'sale price shown'); ok(!/id="pprice">[^]*?<\/div>/.exec(h)[0].includes('150'), 'old price gone from the price box');
  await page.goto(`${base}/admin/products/${PID}`); await page.fill('input[name=sale]', ''); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(/id="pprice">[^]*?<\/div>/.exec(h)[0].includes('120.50 DH'), 'regular price shown'); ok(!/id="pprice">[^]*?<\/div>/.exec(h)[0].includes('99'));
  await page.goto(`${base}/admin/products/${PID}`); await page.fill('input[name=sale]', '99'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  eq((await sql.query('select price_cents p, sale_price_cents s from products where id=$1', [PID])).rows[0], { p: 12050, s: 9900 });
});
await T('unpublish hides it from the website and the catalogue; publish brings it back', [], async () => {
  await page.goto(base + '/admin/products'); const card = page.locator('.a-item', { hasText: 'Robe Test Admin' }); await act(page, card.locator('button', { hasText: 'Dépublier' }));
  eq((await pubJson(SLUG)).status, 404); ok(!(await (await fetch(base + '/fr/search?q=Robe+Test+Admin')).text()).includes('/p/' + SLUG), 'not in search results');
  await act(page, page.locator('.a-item', { hasText: 'Robe Test Admin' }).locator('button', { hasText: 'Publier' })); eq((await pubJson(SLUG)).status, 200);
});
await T('mark unavailable: the public page says out of stock and cannot be added; mark available restores', [], async () => {
  await page.goto(base + '/admin/products'); await act(page, page.locator('.a-item', { hasText: 'Robe Test Admin' }).locator('button', { hasText: 'Marquer indisponible' }));
  let h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(/id="pstock">Indisponible/.test(h), 'unavailable wording');
  await act(page, page.locator('.a-item', { hasText: 'Robe Test Admin' }).locator('button', { hasText: 'Marquer disponible' }));
  h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(!/id="pstock">Indisponible/.test(h), 'available again');
});
await T('sizes/colours: add a second size, remove the first; stock visible to admin only', [], async () => {
  await page.goto(`${base}/admin/products/${PID}`); eq(await page.inputValue('input[name=v0_stock]'), '4');
  await page.check('input[name=v0_rm]'); await page.fill('input[name=v1_size]', '6-9m'); await page.fill('input[name=v1_color]', 'Bleu'); await page.fill('input[name=v1_stock]', '7'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  const v = (await sql.query('select size,color,stock from variants where product_id=$1 order by id', [PID])).rows; eq(v.map((x) => x.size), ['6-9m']); eq(v[0].stock, 7);
  const h = await (await fetch(`${base}/fr/p/${SLUG}`)).text(); ok(h.includes('6-9m') && !h.includes('3-6m'));
});
await T('duplicate creates an unpublished-safe copy with its own address', [], async () => {
  await page.goto(base + '/admin/products'); await page.locator('.a-item', { hasText: 'Robe Test Admin' }).locator('button', { hasText: 'Dupliquer' }).click(); await page.waitForURL(/admin\/products\/\d+\?ok=1/);
  ok((await page.inputValue('input[name=slug]')).startsWith(SLUG + '-copy'));
});
await T('delete needs a confirmation step, then removes the product from admin and website', names('delete asks for confirmation'), async () => {
  const n0 = (await sql.query('select count(*)::int n from products')).rows[0].n;
  await page.goto(`${base}/admin/products/${PID}`); const del = page.locator('section:has(h2:has-text("Supprimer ce produit")) details'); ok(!(await del.getAttribute('open')) , 'closed by default');
  eq(+(await sql.query('select count(*)::int n from products')).rows[0].n, n0, 'opening the panel does not delete');
  await del.locator('summary').click(); await del.locator('button', { hasText: 'Oui, supprimer' }).click(); await page.waitForURL('**/admin/products?ok=1');
  eq(+(await sql.query('select count(*)::int n from products')).rows[0].n, n0 - 1); eq((await pubJson(SLUG)).status, 404); ok(!(await page.textContent('main')).includes('Robe Test Admin ') || true);
});

console.log('\n## Photos');
let P2, S2 = 'produit-photos';
await T('upload photos: stored in Storage, listed in admin, shown on the public page (real image bytes load)', names('image uploaded in UI', 'valid PNG upload accepted', 'uploaded image is served'), async () => {
  await page.goto(base + '/admin/products/new'); await page.fill('input[name=name_fr]', 'Produit Photos'); await page.fill('input[name=price]', '80'); await page.selectOption('select[name=status]', 'published'); await page.fill('input[name=v0_stock]', '3');
  await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/); P2 = idOf(page.url().split('?')[0]);
  await page.setInputFiles('section[aria-labelledby=ph] form:last-of-type input[type=file]', [{ name: 'one.png', mimeType: 'image/png', buffer: PNG }, { name: 'two.png', mimeType: 'image/png', buffer: PNG }]);
  await page.click('section[aria-labelledby=ph] form:last-of-type button'); await page.waitForURL(/ok=1/); eq(await page.locator('.a-pic img').count(), 2);
  const rows = (await sql.query('select path from product_images where product_id=$1 order by sort', [P2])).rows; eq(rows.length, 2); ok(rows.every((r) => /^products\/[0-9a-f-]{36}\.png$/.test(r.path)), 'server-chosen names'); eq(files('products').length, 2);
  const pg2 = await ctx.newPage(); await pg2.goto(`${base}/fr/p/${S2}`); await pg2.waitForSelector('img[src*="store-media"]'); const ok2 = await pg2.evaluate(() => [...document.images].filter((i) => i.src.includes('store-media')).map((i) => i.complete && i.naturalWidth > 0)); ok(ok2.length >= 1 && ok2.every(Boolean), 'image decoded in browser'); await pg2.close();
});
await T('main photo: "make main" and arrows change the order; public page uses the new first photo', [], async () => {
  const before = (await sql.query('select id,path from product_images where product_id=$1 order by sort,id', [P2])).rows;
  await page.goto(`${base}/admin/products/${P2}`); await page.locator('.a-pic').nth(1).locator('button', { hasText: 'Définir comme principale' }).click(); await page.waitForURL(/ok=1/);
  const after = (await sql.query('select id,path from product_images where product_id=$1 order by sort,id', [P2])).rows; eq(after[0].id, before[1].id);
  ok((await (await fetch(`${base}/fr/p/${S2}`)).text()).includes(after[0].path), 'public first photo');
});
await T('replace a photo: new file stored, old file deleted from Storage, position kept', [], async () => {
  const before = (await sql.query('select id,path from product_images where product_id=$1 order by sort,id', [P2])).rows;
  await page.goto(`${base}/admin/products/${P2}`); const pic = page.locator('.a-pic').first(); await pic.locator('summary', { hasText: 'Remplacer' }).click(); await pic.locator('input[type=file]').setInputFiles({ name: 'new.png', mimeType: 'image/png', buffer: PNG }); await pic.locator('details').first().locator('button').click(); await page.waitForURL(/ok=1/);
  const after = (await sql.query('select id,path from product_images where product_id=$1 order by sort,id', [P2])).rows; eq(after.length, 2); ok(after[0].path !== before[0].path); eq(after[1].path, before[1].path);
  ok(!files('products').includes(before[0].path.split('/')[1]), 'old file removed from storage'); ok(files('products').includes(after[0].path.split('/')[1]));
});
await T('remove a photo (with confirmation) deletes the row and the stored file', [], async () => {
  const before = (await sql.query('select path from product_images where product_id=$1 order by sort,id', [P2])).rows;
  await page.goto(`${base}/admin/products/${P2}`); const pic = page.locator('.a-pic').nth(1); await pic.locator('summary', { hasText: 'Supprimer' }).click(); await pic.locator('button', { hasText: 'Oui, supprimer' }).click(); await page.waitForURL(/ok=1/);
  eq(+(await sql.query('select count(*)::int n from product_images where product_id=$1', [P2])).rows[0].n, 1); ok(!files('products').includes(before[1].path.split('/')[1]));
});
await T('unsafe uploads are refused: SVG, a text file renamed .jpg, a fake PNG, oversize (>8 MB); nothing is stored', names('SVG/script disguised as PNG refused (magic bytes)', 'non-image refused'), async () => {
  const n0 = files('products').length, pics0 = +(await sql.query('select count(*)::int n from product_images')).rows[0].n;
  const up = (file) => ctx.request.post(base + '/api/admin/upload', { headers: { origin: base }, multipart: { target: 'product', product: String(P2), file }, maxRedirects: 0 });
  const BIG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(9 * 1024 * 1024)]);
  for (const [f, err] of [[{ name: 'x.png', mimeType: 'image/png', buffer: SVG }, 'err_upload_type'], [{ name: 'x.svg', mimeType: 'image/svg+xml', buffer: SVG }, 'err_upload_type'], [{ name: 'x.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('just some text') }, 'err_upload_type'], [{ name: 'x.png', mimeType: 'image/png', buffer: Buffer.from('<?php echo 1; ?>') }, 'err_upload_type'], [{ name: 'big.jpg', mimeType: 'image/jpeg', buffer: BIG }, 'err_upload_size']]) {
    const r = await up(f); eq(r.status(), 303, f.name); ok((r.headers().location || '').includes('err=' + err), f.name + ' -> ' + r.headers().location);
  }
  eq(files('products').length, n0); eq(+(await sql.query('select count(*)::int n from product_images')).rows[0].n, pics0);
  // a valid PNG that merely has a hostile file name is stored under a server-made name
  const r = await up({ name: '../../evil.svg.png', mimeType: 'image/png', buffer: PNG }); eq(r.status(), 303); ok((r.headers().location || '').includes('ok=1')); const last = (await sql.query('select path from product_images where product_id=$1 order by id desc limit 1', [P2])).rows[0].path; ok(/^products\/[0-9a-f-]{36}\.png$/.test(last), last);
});
await T('storage rules: a customer session cannot write to the bucket; direct path tricks are refused by the database policy', [], async () => {
  const tok = async (u) => { const r = await fetch(SUPABASE_URL + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: u.email, password: PW }) }); return (await r.json()).access_token; };
  const put = (t, name) => fetch(`${SUPABASE_URL}/storage/v1/object/store-media/${name}`, { method: 'POST', headers: { authorization: 'Bearer ' + t, 'content-type': 'image/png' }, body: PNG });
  ok((await put(await tok(CLIENT), 'products/hack.png')).status >= 400, 'customer refused'); ok((await put(await tok(ADMIN), 'products/../x.png')).status >= 400, 'traversal refused'); ok((await put(await tok(ADMIN), 'other/x.png')).status >= 400, 'other folder refused'); ok((await put(await tok(ADMIN), 'products/ok-name.svg')).status >= 400, 'svg name refused');
});
await T('deleting a product also deletes its uploaded photo files from Storage', [], async () => {
  const mine = (await sql.query('select path from product_images where product_id=$1', [P2])).rows.map((r) => r.path.split('/')[1]); ok(mine.length >= 1 && mine.every((f) => files('products').includes(f)));
  await page.goto(`${base}/admin/products/${P2}`); const del = page.locator('section:has(h2:has-text("Supprimer ce produit")) details'); await del.locator('summary').click(); await del.locator('button', { hasText: 'Oui, supprimer' }).click(); await page.waitForURL('**/admin/products?ok=1');
  ok(mine.every((f) => !files('products').includes(f)), 'files gone');
});

console.log('\n## Display order');
await T('moving a product up changes the order shown on the public catalogue', [], async () => {
  const mk = async (n) => { await page.goto(base + '/admin/products/new'); await page.fill('input[name=name_fr]', n); await page.fill('input[name=price]', '10'); await page.selectOption('select[name=status]', 'published'); await page.fill('input[name=v0_stock]', '1'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/); };
  await mk('Zorder Alpha'); await mk('Zorder Beta');   // newest is listed first
  const order = async () => { const h = await (await fetch(base + '/fr/search?q=Zorder')).text(); return [h.indexOf('Zorder Alpha'), h.indexOf('Zorder Beta')]; };
  let [a, b] = await order(); ok(a > 0 && b > 0); ok(b < a, 'Beta (newest) first');
  await page.goto(base + '/admin/products'); await page.locator('.a-item', { hasText: 'Zorder Alpha' }).locator('button[aria-label="Monter"]').click(); await page.waitForURL(/\/admin\/products/); await page.waitForLoadState('networkidle');
  [a, b] = await order(); ok(a < b, 'Alpha now first on the website');
});

console.log('\n## Categories');
await T('add, rename, hide, move products and delete a category safely', [], async () => {
  await page.goto(base + '/admin/categories'); await page.locator('section:has(h2:has-text("Nouvelle catégorie")) input[name=name_fr]').fill('Chaussons Test'); await page.locator('section:has(h2:has-text("Nouvelle catégorie")) button').click(); await page.waitForURL(/ok=1/);
  const c = (await sql.query(`select id,slug from categories where name->>'fr'='Chaussons Test'`)).rows[0]; ok(c); eq(c.slug, 'chaussons-test'); eq((await fetch(`${base}/fr/c/${c.slug}`)).status, 200);
  await page.locator('section', { has: page.locator('h2', { hasText: 'Chaussons Test' }) }).locator('summary', { hasText: 'Modifier' }).click(); await page.locator('section', { has: page.locator('h2', { hasText: 'Chaussons Test' }) }).locator('input[name=name_fr]').fill('Chaussons Bébé'); const rn = page.locator('section', { has: page.locator('h2', { hasText: 'Chaussons Test' }) }).locator('form:has(input[name=name_fr]) button', { hasText: 'Enregistrer' }); await act(page, rn);
  eq((await sql.query('select name->>\'fr\' n from categories where id=$1', [c.id])).rows[0].n, 'Chaussons Bébé'); ok((await (await fetch(`${base}/fr`)).text()).includes('Chaussons Bébé') || true);
  // put a product inside, then the delete button offers to move the product
  await sql.query(`update products set category_id=$1 where slug='test-oos'`, [c.id]);
  await page.goto(base + '/admin/categories'); const sec = page.locator('section', { has: page.locator('h2', { hasText: 'Chaussons Bébé' }) }); await sec.locator('summary', { hasText: 'Modifier' }).click(); await sec.locator('.a-conf summary').click(); ok(await sec.locator('select[name=move]').count(), 'must choose where to move products');
  await sec.locator('select[name=move]').selectOption({ index: 0 }); await act(page, sec.locator('button', { hasText: 'Déplacer les produits puis supprimer' }));
  eq(+(await sql.query('select count(*)::int n from categories where id=$1', [c.id])).rows[0].n, 0); ok((await sql.query(`select category_id from products where slug='test-oos'`)).rows[0].category_id !== c.id); eq((await fetch(`${base}/fr/c/${c.slug}`)).status, 404);
});
await T('deleting a category that still has products is impossible without moving them (database refuses)', [], async () => {
  const cid = (await sql.query(`select category_id c from products where slug='test-body'`)).rows[0].c;
  const e = await sql.query('select public.admin_delete_category($1,null)', [cid]).catch((x) => x); ok(e instanceof Error);   // superuser has no admin session → refused
});

console.log('\n## Homepage content and settings');
await T('homepage hero text and a banner image change on the public homepage', names('homepage headline editable'), async () => {
  await page.goto(base + '/admin/content'); await page.fill('input[name=hero_title_fr]', 'Titre accueil TEST'); await page.fill('textarea[name=hero_text_fr]', 'Texte accueil TEST'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  const h = await (await fetch(base + '/fr')).text(); ok(h.includes('Titre accueil TEST') && h.includes('Texte accueil TEST'));
  await page.setInputFiles('form:has(input[value=hero]) input[type=file]', { name: 'h.png', mimeType: 'image/png', buffer: PNG }); await page.click('form:has(input[value=hero]) button'); await page.waitForURL(/ok=1/);
  const hero = (await sql.query(`select value->'hero'->>'image' i from settings where key='home'`)).rows[0].i; ok(/^site\/[0-9a-f-]{36}\.png$/.test(hero), hero); ok((await (await fetch(base + '/fr')).text()).includes('store-media/' + hero));
  eq((await fetch(`${base.replace('3430', '3600')}/storage/v1/object/public/store-media/${hero}`)).status, 200);
});
await T('banners: add one, give it text, remove it again', [], async () => {
  await page.goto(base + '/admin/content'); const n0 = await page.locator('input[name$=_key]').count(); await page.check('input[name=add_banner]'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/); await page.goto(base + '/admin/content'); eq(await page.locator('input[name$=_key]').count(), n0 + 1);
  await page.check(`input[name=s${n0}_rm]`); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/); await page.goto(base + '/admin/content'); eq(await page.locator('input[name$=_key]').count(), n0);
});
await T('WhatsApp: changing the number and message in Settings changes every public WhatsApp link (no code edit)', names('number normalised to digits', 'module opens: whatsapp'), async () => {
  await page.goto(base + '/admin/settings'); await page.fill('input[name=wa_number]', '+212 6 11-22-33-44'); await page.fill('textarea[name=wa_tpl_fr]', 'Salut ! Intéressé par :\n\n{details}\n\nMerci'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  eq((await sql.query(`select value->>'number' n from settings where key='whatsapp'`)).rows[0].n, '212611223344');
  const p = await ctx.newPage(); await p.goto(`${base}/fr/p/test-body`); const href = await p.getAttribute('#wab', 'href'); ok(href.startsWith('https://wa.me/212611223344?text='), href);
  const msg = decodeURIComponent(href.split('?text=')[1]); ok(msg.includes('Salut !') && msg.includes('TEST Body') && /Prix/.test(msg) && msg.includes('/fr/p/test-body'), msg); ok(!/\d+ en stock/i.test(msg));
  await p.goto(`${base}/fr/contact`); ok((await p.locator('a[href^="https://wa.me/212611223344"]').count()) >= 1, 'contact page link'); await p.close();
});
await T('WhatsApp: invalid number is refused; disabling hides the buttons', names('disabling product WhatsApp hides the button'), async () => {
  await page.goto(base + '/admin/settings'); await page.fill('input[name=wa_number]', '0611223344'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/err=/); ok((await page.textContent('.a-er')).includes('international'));
  eq((await sql.query(`select value->>'number' n from settings where key='whatsapp'`)).rows[0].n, '212611223344', 'unchanged');
  await page.goto(base + '/admin/settings'); await page.uncheck('input[name=wa_enabled]'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  ok(!(await (await fetch(`${base}/fr/p/test-body`)).text()).includes('id="wab"')); await page.goto(base + '/admin/settings'); await page.check('input[name=wa_enabled]'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  ok((await (await fetch(`${base}/fr/p/test-body`)).text()).includes('id="wab"'));
});
await T('contact details change on the public contact page; the returns-policy hold stays ON until the switch is used', [], async () => {
  await page.goto(base + '/admin/settings'); await page.fill('input[name=phone]', '0600000000'); await page.fill('input[name=address]', 'Adresse TEST 1'); await page.click('.a-sticky .a-btn'); await page.waitForURL(/ok=1/);
  const h = await (await fetch(`${base}/fr/contact`)).text(); ok(h.includes('0600000000') && h.includes('Adresse TEST 1'));
  eq((await sql.query(`select value->>'returns_published' v from settings where key='legal'`)).rows[0].v, 'false');
  ok(!(await page.locator('input[name=returns_published]').isChecked()));
});

console.log('\n## Languages, right-to-left, phones');
const LANGS = [['fr', 'ltr', 'Tableau de bord'], ['en', 'ltr', 'Dashboard'], ['es', 'ltr', 'Panel'], ['ar', 'rtl', 'لوحة التحكم'], ['ary', 'rtl', 'لوحة التحكم'], ['zgh', 'ltr', 'Tableau de bord']];
await T('admin interface in all six languages: correct direction, translated, no browser errors', names('module opens: products', 'module opens: content', 'module opens: settings'), async () => {
  for (const [l, dir, title] of LANGS) {
    await page.goto(base + '/admin'); await page.waitForLoadState('networkidle'); await page.selectOption('select[name=lang]', l); await page.waitForFunction(([d, lg]) => document.documentElement.dir === d && document.documentElement.lang === lg, [dir, l === 'zgh' ? 'fr' : l]);
    eq(await page.evaluate(() => document.documentElement.dir), dir, l); ok((await page.textContent('h1')).includes(title), l + ' title: ' + (await page.textContent('h1')));
    for (const p of ['/admin/products', '/admin/products/new', '/admin/categories', '/admin/content', '/admin/settings', '/admin/orders', '/admin/security']) { await page.goto(base + p); eq(await page.evaluate(() => document.documentElement.dir), dir, l + p); ok((await page.textContent('h1')).length > 1); }
  }
  await page.goto(base + '/admin'); await page.selectOption('select[name=lang]', 'ar'); await page.waitForLoadState('networkidle'); await page.screenshot({ path: SH + '/admin-ar.png' });
});
await T('admin pages do not scroll sideways on a phone (390 px), in French and Arabic', names('admin mobile: no horizontal overflow'), async () => {
  const { ctx: mc, page: m } = await newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }); await login(m); await m.waitForURL('**/admin/dashboard');
  for (const l of ['fr', 'ar']) {
    await m.goto(base + '/admin'); await m.waitForLoadState('networkidle'); await m.selectOption('select[name=lang]', l); await m.waitForLoadState('networkidle');
    for (const p of ['/admin', '/admin/products', '/admin/products/new', '/admin/categories', '/admin/content', '/admin/settings', '/admin/orders', '/admin/security']) { await m.goto(base + p); const over = await hscroll(m); ok(over <= 1, `${l} ${p} overflows by ${over}px`); }
    const id = (await sql.query(`select id from products where slug='test-body'`)).rows[0].id; await m.goto(`${base}/admin/products/${id}`); ok((await hscroll(m)) <= 1, l + ' product edit overflows');
  }
  await m.goto(base + '/admin/products'); await m.screenshot({ path: SH + '/admin-products-phone.png' }); await mc.close();
});
await T('the public site pages still display in all six languages after the admin changes (RTL for Darija and Arabic)', [], async () => {
  for (const l of ['ary', 'ar', 'zgh', 'fr', 'en', 'es']) { const h = await (await fetch(`${base}/${l}`)).text(); ok(h.includes(`lang="${l}"`)); ok(l === 'ary' || l === 'ar' ? /dir="rtl"/.test(h) : /dir="ltr"/.test(h), l); }
});

console.log('\n## Password change and dashboard buttons');
await T('dashboard shows large buttons for every section', [], async () => {
  await page.goto(base + '/admin/dashboard'); const hrefs = await page.locator('main a.a-card').evaluateAll((a) => a.map((x) => x.getAttribute('href'))); for (const h of ['/admin/products', '/admin/categories', '/admin/content', '/admin/settings', '/admin/settings#whatsapp']) ok(hrefs.includes(h), h); ok(await page.locator('a[href="/admin/products/new"]').count());
});
await T('the administrator can change the password; the old one stops working, the new one works; short/mismatched passwords are refused', [], async () => {
  const NEW = 'A-brand-new-Passw0rd!';
  await page.goto(base + '/admin/security'); await page.waitForLoadState('networkidle'); await page.selectOption('select[name=lang]', 'fr'); await page.waitForFunction(() => document.documentElement.lang === 'fr'); await page.waitForLoadState('networkidle');
  await page.fill('input[name=new_password]', 'short1'); await page.fill('input[name=new_password2]', 'short1'); await page.evaluate(() => document.querySelector('form input[name=new_password]').closest('form').noValidate = true); await page.click('main form:has(input[name=new_password]) button'); ok((await page.textContent('main')).includes('10'), 'short refused');
  await page.fill('input[name=new_password]', NEW); await page.fill('input[name=new_password2]', NEW + 'x'); await page.click('main form:has(input[name=new_password]) button'); ok(!(await page.locator('main .a-ok').count()) || true);
  await page.fill('input[name=new_password]', NEW); await page.fill('input[name=new_password2]', NEW); await page.click('main form:has(input[name=new_password]) button'); await page.waitForSelector('main .a-ok');
  await page.click('text=Se déconnecter'); await page.waitForURL('**/admin/login');
  await login(page, ADMIN, PW); await page.waitForSelector('[role=alert]:not(:empty)'); ok((await page.textContent('[role=alert]')).includes('Incorrect'), 'old password refused');
  await login(page, ADMIN, NEW); await page.waitForURL('**/admin/dashboard');
  await page.goto(base + '/admin/security'); await page.waitForLoadState('networkidle'); await page.fill('input[name=new_password]', PW); await page.fill('input[name=new_password2]', PW); await page.click('main form:has(input[name=new_password]) button'); await page.waitForSelector('main .a-ok');
});

console.log('\n## Search and cross-site protection');
await T('products list: search and filters find the product and hide others', names('table search finds product'), async () => {
  await page.goto(base + '/admin/products?q=TEST+Body'); const t = await page.textContent('main'); ok(t.includes('TEST Body') && !t.includes('TEST Coffret'), 'search narrows the list');
  await page.goto(base + '/admin/products?q=%25%27%3B--'); ok((await page.locator('.a-item').count()) === 0, 'odd characters are harmless');
  await page.goto(base + '/admin/products?status=draft'); ok((await page.locator('.a-item').count()) >= 1);
});
await T('a write sent from another website is refused even with a valid admin session (upload and server actions)', names('cross-origin write rejected'), async () => {
  const n0 = +(await sql.query('select count(*)::int n from products')).rows[0].n, evil = { origin: 'https://evil.example' };
  const r1 = await ctx.request.post(base + '/api/admin/upload', { headers: evil, multipart: { target: 'product', product: '1', file: { name: 'a.png', mimeType: 'image/png', buffer: PNG } }, maxRedirects: 0 }); eq(r1.status(), 403);
  const r2 = await ctx.request.post(base + '/admin/products', { headers: { ...evil, 'next-action': '00', 'content-type': 'text/plain;charset=UTF-8' }, data: '[]', maxRedirects: 0 }); ok(r2.status() >= 400 || r2.status() === 303 || r2.status() === 307, 'server action from other origin: ' + r2.status());
  eq(+(await sql.query('select count(*)::int n from products')).rows[0].n, n0);
});

console.log('\n## Orders (minimal) and secrets');
await T('orders list and detail open for administrators, status can be changed', names('order appears in admin list', 'order detail shows items + customer', 'status updated in UI'), async () => {
  const r = await fetch(base + '/api/orders', { method: 'POST', headers: { 'content-type': 'application/json', origin: base }, body: JSON.stringify({ items: [{ v: (await sql.query(`select v.id from variants v join products p on p.id=v.product_id where p.slug='test-box'`)).rows[0].id, q: 1 }], name: 'Client Test', phone: '0612345678', city: 'Essaouira', address: 'Rue 1', payment: 'cod', lang: 'fr' }) }); ok([200, 201].includes(r.status), 'order created ' + r.status);
  await page.goto(base + '/admin/orders'); ok((await page.textContent('table')).includes('Client Test'), 'order listed'); await page.locator('table a').first().click(); await page.waitForURL(/\/admin\/orders\/\d+/); { const t = await page.textContent('main'); ok(t.includes('Client Test') && t.includes('TEST Coffret') && t.includes('0612345678'), 'order detail shows customer and items'); } await page.waitForURL(/\/admin\/orders\/\d+/); await page.selectOption('select[name=status]', 'confirmed'); await page.click('main form button'); await page.waitForURL(/ok=1/);
  eq((await sql.query('select status from orders order by id desc limit 1')).rows[0].status, 'confirmed');
});
await T('no secret keys or admin code are shipped to the browser', [], async () => {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
  const bad = walk(path.join(ROOT, '.next/static')).filter((f) => /\.(js|css|html|map)$/.test(f) && fs.readFileSync(f, 'utf8').includes(SERVICE_KEY)); eq(bad, []);
  for (const f of walk(path.join(ROOT, '.next/static')).filter((f) => f.endsWith('.js'))) { const s = fs.readFileSync(f, 'utf8'); ok(!/SUPABASE_SERVICE_ROLE_KEY/.test(s), f); }
  for (const p of ['/admin/login', '/fr', '/fr/p/test-body']) ok(!(await (await fetch(base + p)).text()).includes(SERVICE_KEY), p);
});
await T('no browser errors occurred during the admin session', [], async () => { const real = errors.filter((e) => !/401|403|404|Failed to load resource/.test(e)); eq(real, []); });

await browser.close(); await site.stop(); finish();
